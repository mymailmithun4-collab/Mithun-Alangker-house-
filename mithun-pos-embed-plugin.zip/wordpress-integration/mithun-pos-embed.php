<?php
/**
 * Plugin Name: Mithun Jewelry POS Embed
 * Description: Embeds the separately hosted Mithun Jewelry POS React app into a WordPress page using [mithun_pos].
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }

function mithun_pos_embed_register_settings() {
    register_setting('mithun_pos_embed_settings', 'mithun_pos_app_url', array(
        'type' => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default' => home_url('/pos-app/'),
    ));
    add_settings_section('mithun_pos_embed_section', 'POS App Location', function () {
        echo '<p>Enter the URL where the built POS app is uploaded. Example: ' . esc_html(home_url('/pos-app/')) . '</p>';
    }, 'mithun-pos-embed');
    add_settings_field('mithun_pos_app_url', 'POS App URL', function () {
        $value = get_option('mithun_pos_app_url', home_url('/pos-app/'));
        echo '<input type="url" class="regular-text" name="mithun_pos_app_url" value="' . esc_attr($value) . '" required />';
    }, 'mithun-pos-embed', 'mithun_pos_embed_section');
}
add_action('admin_init', 'mithun_pos_embed_register_settings');

function mithun_pos_embed_admin_menu() {
    add_options_page('Mithun POS Embed', 'Mithun POS Embed', 'manage_options', 'mithun-pos-embed', function () {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap"><h1>Mithun Jewelry POS Embed</h1><form method="post" action="options.php">';
        settings_fields('mithun_pos_embed_settings');
        do_settings_sections('mithun-pos-embed');
        submit_button('Save POS App URL');
        echo '</form><p>Put <code>[mithun_pos]</code> in a WordPress page to show the app.</p></div>';
    });
}
add_action('admin_menu', 'mithun_pos_embed_admin_menu');

function mithun_pos_embed_shortcode($atts = array()) {
    $url = get_option('mithun_pos_app_url', home_url('/pos-app/'));
    $url = esc_url($url);
    if (!$url) { return '<p>POS app URL is not configured. Go to Settings → Mithun POS Embed.</p>'; }
    return '<div class="mithun-pos-embed" style="width:100%;min-height:80vh;overflow:hidden"><iframe title="মেসার্স মিঠুন অলংকার হাউজ POS" src="' . $url . '" style="display:block;width:100%;height:85vh;min-height:680px;border:0;border-radius:8px;background:#0b0a08" loading="lazy" allow="clipboard-read; clipboard-write" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>';
}
add_shortcode('mithun_pos', 'mithun_pos_embed_shortcode');
