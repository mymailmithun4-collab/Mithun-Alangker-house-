মেসার্স মিঠুন অলংকার হাউজ POS - WordPress package

প্রথমে WORDPRESS_SETUP_BN.md পড়ুন।
এই ZIP-এ পুরো source code ও WordPress shortcode plugin আছে।
অ্যাপটি চালাতে আগে source ফোল্ডারে npm install এবং npm run build করে dist তৈরি করতে হবে।
তারপর dist-এর ফাইলগুলো hosting-এর public_html/pos-app/ ফোল্ডারে আপলোড করতে হবে।
WordPress plugin চালু করে পেজে [mithun_pos] shortcode দিন।
Firebase-এর নিজের config লাগবে; zip-এর placeholder config দিয়ে live database চলবে না।
