/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ============================================================================
 * 🔴 ফায়ারবেস কনফিগারেশন এর স্থান (INSERT YOUR FIREBASE WEB CONFIG HERE) 🔴
 * ============================================================================
 * নির্দেশিকা (বাংলায়):
 * ১. Firebase Console (https://console.firebase.google.com) এ যান।
 * ২. একটি নতুন প্রোজেক্ট তৈরি করুন (যেমন: mithun-jewelry-pos)।
 * ৩. Project Settings (গিয়ার আইকন) -> General -> Your apps -> Web App (</>) এ ক্লিক করুন।
 * ৪. নিচে দেওয়া অবজেক্টে আপনার প্রোজেক্টের আসল তথ্য বসান অথবা অ্যাপের ভেতরের
 *    "Firebase সেটিংস" বাটন থেকে সরাসরি পেস্ট করে সংরক্ষণ করুন।
 */

import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  type Auth,
  type User
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  runTransaction,
  query,
  orderBy,
  type Firestore
} from 'firebase/firestore';

export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId: string;
}

// ⚠️ এখানে আপনার ফায়ারবেস তথ্য বসাবেন:
export const DEFAULT_FIREBASE_CONFIG: FirebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "mithun-alankar-pos.firebaseapp.com",
  projectId: "mithun-alankar-pos",
  storageBucket: "mithun-alankar-pos.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890",
};

const STORAGE_KEY = 'mithun_alankar_firebase_config';

export function getActiveFirebaseConfig(): FirebaseConfig {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && parsed.apiKey && parsed.projectId) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('LocalStorage Firebase config read failed:', err);
  }
  return DEFAULT_FIREBASE_CONFIG;
}

export function saveFirebaseConfig(config: FirebaseConfig): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

export function clearCustomFirebaseConfig(): void {
  localStorage.removeItem(STORAGE_KEY);
}

/**
 * Checks if Firebase has valid keys supplied (not default placeholder)
 */
export function isFirebaseConfigured(config: FirebaseConfig = getActiveFirebaseConfig()): boolean {
  if (!config.apiKey || !config.projectId) return false;
  if (config.apiKey === 'YOUR_API_KEY_HERE' || config.projectId.includes('your-shop-app') || config.projectId === 'mithun-alankar-pos') {
    // Check if it's the default mock placeholder
    return false;
  }
  return true;
}

let appInstance: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

export function initializeFirebaseServices(customConfig?: FirebaseConfig): {
  app: FirebaseApp | null;
  auth: Auth | null;
  db: Firestore | null;
  configured: boolean;
  error?: string;
} {
  const config = customConfig || getActiveFirebaseConfig();
  const configured = isFirebaseConfigured(config);

  if (!configured) {
    return {
      app: null,
      auth: null,
      db: null,
      configured: false,
    };
  }

  try {
    if (getApps().length === 0) {
      appInstance = initializeApp(config);
    } else {
      appInstance = getApp();
    }
    authInstance = getAuth(appInstance);
    dbInstance = getFirestore(appInstance);

    return {
      app: appInstance,
      auth: authInstance,
      db: dbInstance,
      configured: true,
    };
  } catch (err: any) {
    console.error('Firebase initialization error:', err);
    return {
      app: null,
      auth: null,
      db: null,
      configured: false,
      error: err?.message || 'Firebase initialization failed',
    };
  }
}

export {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  runTransaction,
  query,
  orderBy,
  type Auth,
  type User,
  type Firestore,
};
