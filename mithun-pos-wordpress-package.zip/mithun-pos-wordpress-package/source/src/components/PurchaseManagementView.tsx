/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PurchaseRecord, KaratType, GoldWeightParts, PaymentMethod } from '../types';
import {
  partsToPoints,
  pointsToParts,
  partsToGrams,
  formatWeightPartsBn,
  toBengaliNumber,
  formatTaka,
  KARAT_INFO
} from '../utils/goldCalculator';
import {
  ArrowDownLeft,
  Plus,
  Search,
  Scale,
  Receipt,
  Printer,
  CheckCircle2,
  Calendar,
  X,
  User,
  Coins
} from 'lucide-react';

export const PurchaseManagementView: React.FC = () => {
  const { purchases, createPurchase, rates, shopProfile } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVoucher, setSelectedVoucher] = useState<PurchaseRecord | null>(null);

  // Form Fields
  const [sellerName, setSellerName] = useState('');
  const [sellerPhone, setSellerPhone] = useState('');
  const [sellerAddress, setSellerAddress] = useState('');
  const [purchaseType, setPurchaseType] = useState<'পুরাতন স্বর্ণ ক্রয়' | 'মহাজন হতে ক্রয়' | 'বিনিময়/এক্সচেঞ্জ'>('পুরাতন স্বর্ণ ক্রয়');
  const [itemName, setItemName] = useState('পুরাতন অলংকার / ভাঙ্গা সোনা');
  const [karat, setKarat] = useState<KaratType>('21K');

  // Gross Weight
  const [grossBhori, setGrossBhori] = useState('1');
  const [grossAna, setGrossAna] = useState('0');
  const [grossRoti, setGrossRoti] = useState('0');
  const [grossPoint, setGrossPoint] = useState('0');

  // Waste / Testing Deduction
  const [wastePoints, setWastePoints] = useState('40'); // খাদ বা খাদ বাদ (পয়েন্টে)
  const [purchaseRate, setPurchaseRate] = useState(rates['21K'] ? (rates['21K'] * 0.9).toString() : '110000');
  const [paidAmount, setPaidAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('নগদ');
  const [notes, setNotes] = useState('');

  // Calculate net weights and price
  const grossParts: GoldWeightParts = {
    bhori: parseFloat(grossBhori) || 0,
    ana: parseFloat(grossAna) || 0,
    roti: parseFloat(grossRoti) || 0,
    point: parseFloat(grossPoint) || 0,
  };
  const grossTotalPoints = partsToPoints(grossParts);
  const waste = parseFloat(wastePoints) || 0;
  const netTotalPoints = Math.max(0, grossTotalPoints - waste);
  const netParts = pointsToParts(netTotalPoints);
  const netWeightGrams = partsToGrams(netParts);

  const rateVal = parseFloat(purchaseRate) || 0;
  const calculatedTotalPrice = Math.round((netTotalPoints / 960) * rateVal);
  const paidVal = paidAmount === '' ? calculatedTotalPrice : parseFloat(paidAmount) || 0;
  const dueVal = Math.max(0, calculatedTotalPrice - paidVal);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sellerName.trim()) {
      alert('বিক্রেতার নাম আবশ্যক');
      return;
    }

    const voucherNumber = `PUR-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(100 + Math.random() * 900))}`;

    const newRecord: PurchaseRecord = {
      id: `pur-${Date.now()}`,
      voucherNumber,
      date: new Date().toISOString(),
      sellerName: sellerName.trim(),
      sellerPhone: sellerPhone.trim(),
      sellerAddress: sellerAddress.trim(),
      purchaseType,
      itemName: itemName.trim(),
      karat,
      grossWeightParts: grossParts,
      wastePoints: waste,
      netWeightParts: netParts,
      netWeightGrams,
      ratePerBhori: rateVal,
      totalPrice: calculatedTotalPrice,
      paidAmount: paidVal,
      dueAmount: dueVal,
      paymentMethod,
      notes: notes.trim(),
    };

    createPurchase(newRecord);
    setIsModalOpen(false);

    // Reset
    setSellerName('');
    setSellerPhone('');
    setPaidAmount('');
    setNotes('');
  };

  const filteredPurchases = purchases.filter(
    (p) =>
      p.sellerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.voucherNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sellerPhone.includes(searchQuery)
  );

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-800/30 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <ArrowDownLeft className="w-6 h-6 text-amber-400" />
            স্বর্ণ ক্রয় ও বিনিময় (Gold Purchase / Exchange)
          </h2>
          <p className="text-xs text-amber-400/70">
            গ্রাহক বা মহাজনের থেকে পুরাতন স্বর্ণ ক্রয়, খাদ বাদ, টেস্টেড ওজন ও পরিশোধের হিসাব
          </p>
        </div>

        <button
          onClick={() => {
            setPaidAmount(calculatedTotalPrice.toString());
            setIsModalOpen(true);
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-lg active:scale-95"
        >
          <Plus className="w-4 h-4" />
          নতুন ক্রয় ভাউচার
        </button>
      </div>

      {/* Search Input */}
      <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 flex items-center gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-amber-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="ভাউচার নং, বিক্রেতার নাম বা ফোন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-9 pr-3 py-1.5 text-xs text-amber-100 placeholder-neutral-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#12110c] rounded-2xl border border-amber-800/40 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-amber-950/40 text-amber-300/90 border-b border-amber-800/30">
              <tr>
                <th className="p-3">ভাউচার নং</th>
                <th className="p-3">তারিখ</th>
                <th className="p-3">বিক্রেতা / মহাজন</th>
                <th className="p-3">স্বর্ণের বিবরণ</th>
                <th className="p-3">নেট ওজন</th>
                <th className="p-3 text-right">দর (টাকা/ভরি)</th>
                <th className="p-3 text-right">মোট প্রদেয়</th>
                <th className="p-3 text-right">পরিশোধ</th>
                <th className="p-3 text-center">ভাউচার</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-950/60 text-amber-100">
              {filteredPurchases.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-10 text-neutral-500">
                    কোনো ক্রয়ের তথ্য পাওয়া যায়নি।
                  </td>
                </tr>
              ) : (
                filteredPurchases.map((pur) => (
                  <tr key={pur.id} className="hover:bg-amber-950/20">
                    <td className="p-3 font-mono font-bold text-amber-300">{pur.voucherNumber}</td>
                    <td className="p-3 text-amber-400/80 font-mono">
                      {new Date(pur.date).toLocaleDateString('bn-BD')}
                    </td>
                    <td className="p-3">
                      <div className="font-semibold text-amber-200">{pur.sellerName}</div>
                      <div className="text-[10px] text-amber-400/70 font-mono">{pur.sellerPhone}</div>
                    </td>
                    <td className="p-3">
                      <div>{pur.itemName}</div>
                      <span className="text-[10px] bg-amber-950 text-amber-300 px-1.5 py-0.2 rounded border border-amber-800/40">
                        {pur.karat} | {pur.purchaseType}
                      </span>
                    </td>
                    <td className="p-3">
                      <div>{formatWeightPartsBn(pur.netWeightParts)}</div>
                      <div className="text-[10px] text-neutral-400 font-mono">
                        {toBengaliNumber(pur.netWeightGrams)} গ্রাম (খাদ বাদ: {toBengaliNumber(pur.wastePoints)}pt)
                      </div>
                    </td>
                    <td className="p-3 text-right font-mono text-neutral-300">
                      ৳{toBengaliNumber(pur.ratePerBhori.toLocaleString('en-IN'))}
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-amber-300">
                      {formatTaka(pur.totalPrice)}
                    </td>
                    <td className="p-3 text-right font-mono text-emerald-400 font-bold">
                      {formatTaka(pur.paidAmount)}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => setSelectedVoucher(pur)}
                        className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-600/30 text-xs inline-flex items-center gap-1"
                      >
                        <Receipt className="w-3.5 h-3.5" /> ভাউচার
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Purchase Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-3">
              <h3 className="font-bold text-lg text-amber-200 flex items-center gap-2">
                <ArrowDownLeft className="w-5 h-5 text-amber-400" />
                নতুন স্বর্ণ ক্রয় ভাউচার তৈরি
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-amber-300 mb-1">বিক্রেতার নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="বিক্রেতা বা মহাজনের নাম"
                    value={sellerName}
                    onChange={(e) => setSellerName(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100"
                  />
                </div>
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">মোবাইল নম্বর</label>
                  <input
                    type="text"
                    placeholder="০১৭১১xxxxxx"
                    value={sellerPhone}
                    onChange={(e) => setSellerPhone(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs font-mono text-amber-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">ক্রয়ের ধরন</label>
                  <select
                    value={purchaseType}
                    onChange={(e) => setPurchaseType(e.target.value as any)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-2 py-1.5 text-xs text-amber-100"
                  >
                    <option value="পুরাতন স্বর্ণ ক্রয়">পুরাতন স্বর্ণ ক্রয়</option>
                    <option value="মহাজন হতে ক্রয়">মহাজন হতে ক্রয়</option>
                    <option value="বিনিময়/এক্সচেঞ্জ">বিনিময়/এক্সচেঞ্জ</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">ক্যারেট</label>
                  <select
                    value={karat}
                    onChange={(e) => {
                      const k = e.target.value as KaratType;
                      setKarat(k);
                      if (rates[k]) {
                        setPurchaseRate(Math.round(rates[k] * 0.9).toString());
                      }
                    }}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-2 py-1.5 text-xs text-amber-100 font-bold"
                  >
                    <option value="24K">24K</option>
                    <option value="22K">22K</option>
                    <option value="21K">21K</option>
                    <option value="18K">18K</option>
                    <option value="সনাতন">সনাতন</option>
                  </select>
                </div>
              </div>

              {/* Gross Weight System */}
              <div className="bg-black/50 p-3 rounded-xl border border-amber-800/40 space-y-2">
                <span className="text-xs font-semibold text-amber-300 block">মোট কাঁচা ওজন (Gross Weight):</span>
                <div className="grid grid-cols-4 gap-2">
                  <div>
                    <label className="text-[10px] text-amber-400/80">ভরি</label>
                    <input
                      type="number"
                      min="0"
                      value={grossBhori}
                      onChange={(e) => setGrossBhori(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-amber-400/80">আনা (&lt;16)</label>
                    <input
                      type="number"
                      min="0"
                      max="15"
                      value={grossAna}
                      onChange={(e) => setGrossAna(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-amber-400/80">রতি (&lt;6)</label>
                    <input
                      type="number"
                      min="0"
                      max="5"
                      value={grossRoti}
                      onChange={(e) => setGrossRoti(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-amber-400/80">পয়েন্ট</label>
                    <input
                      type="number"
                      min="0"
                      value={grossPoint}
                      onChange={(e) => setGrossPoint(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                </div>

                {/* Waste Deduction */}
                <div className="pt-2 border-t border-amber-900/40 flex items-center justify-between gap-4">
                  <label className="text-xs text-amber-300">খাদ / টেস্টেড ঘাটতি বাদ (পয়েন্ট):</label>
                  <input
                    type="number"
                    min="0"
                    value={wastePoints}
                    onChange={(e) => setWastePoints(e.target.value)}
                    className="w-24 bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                  />
                </div>

                <div className="text-[11px] text-amber-400 bg-amber-950/60 p-2 rounded flex justify-between">
                  <span>খাদ বাদে খাঁটি ওজন: <strong>{formatWeightPartsBn(netParts)}</strong></span>
                  <span>({toBengaliNumber(netWeightGrams)} গ্রাম)</span>
                </div>
              </div>

              {/* Purchase Rate & Total */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-amber-300 mb-1">ক্রয় দর (টাকা/ভরি)</label>
                  <input
                    type="number"
                    value={purchaseRate}
                    onChange={(e) => setPurchaseRate(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs font-mono text-amber-100"
                  />
                </div>
                <div>
                  <label className="block text-xs text-amber-300 mb-1">মোট মূল্য (৳)</label>
                  <div className="w-full bg-neutral-950 border border-amber-600/30 rounded-lg px-3 py-1.5 text-xs font-mono font-bold text-amber-300">
                    {formatTaka(calculatedTotalPrice)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-emerald-400 mb-1">নগদ প্রদান (৳)</label>
                  <input
                    type="number"
                    value={paidVal}
                    onChange={(e) => setPaidAmount(e.target.value)}
                    className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-3 py-1.5 text-xs font-mono text-emerald-300 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs text-red-400 mb-1">বকেয়া (৳)</label>
                  <div className="w-full bg-neutral-950 border border-red-800/50 rounded-lg px-3 py-1.5 text-xs font-mono font-bold text-red-300">
                    {formatTaka(dueVal)}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs shadow"
                >
                  ভাউচার তৈরি করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Voucher Detail Print Modal */}
      {selectedVoucher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-3">
              <h3 className="font-bold text-base text-amber-200">
                স্বর্ণ ক্রয়ের ভাউচার (#{selectedVoucher.voucherNumber})
              </h3>
              <button onClick={() => setSelectedVoucher(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-neutral-950 p-4 rounded-xl border border-amber-900/50 text-xs space-y-2">
              <div className="flex justify-between border-b border-neutral-800 pb-1">
                <span className="text-neutral-400">দোকান:</span>
                <span className="font-bold text-amber-200">{shopProfile.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">বিক্রেতার নাম:</span>
                <span className="font-semibold text-neutral-200">{selectedVoucher.sellerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">মোবাইল:</span>
                <span className="font-mono text-neutral-200">{selectedVoucher.sellerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">স্বর্ণের ধরন:</span>
                <span className="text-neutral-200">{selectedVoucher.itemName} ({selectedVoucher.karat})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">কাঁচা ওজন:</span>
                <span>{formatWeightPartsBn(selectedVoucher.grossWeightParts)}</span>
              </div>
              <div className="flex justify-between text-amber-400">
                <span>খাদ বাদে নিট ওজন:</span>
                <span className="font-bold">{formatWeightPartsBn(selectedVoucher.netWeightParts)} ({toBengaliNumber(selectedVoucher.netWeightGrams)} গ্রাম)</span>
              </div>
              <div className="flex justify-between border-t border-neutral-800 pt-1 font-bold text-sm text-amber-300">
                <span>মোট ক্রয়মূল্য:</span>
                <span className="font-mono">{formatTaka(selectedVoucher.totalPrice)}</span>
              </div>
              <div className="flex justify-between text-emerald-400 font-semibold">
                <span>প্রদত্ত টাকা:</span>
                <span className="font-mono">{formatTaka(selectedVoucher.paidAmount)}</span>
              </div>
              {selectedVoucher.dueAmount > 0 && (
                <div className="flex justify-between text-red-400 font-semibold">
                  <span>বকেয়া পাওনা:</span>
                  <span className="font-mono">{formatTaka(selectedVoucher.dueAmount)}</span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" /> প্রিন্ট ভাউচার
              </button>
              <button
                onClick={() => setSelectedVoucher(null)}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
              >
                বন্ধ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
