/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CustomerOrder, MetalType, KaratType, OrderStatus } from '../types';
import {
  partsToGrams,
  gramsToParts,
  formatWeightPartsBn,
  toBengaliNumber,
  formatTaka,
  partsToPoints,
} from '../utils/goldCalculator';
import {
  Sparkles,
  Plus,
  Search,
  Printer,
  Trash2,
  Edit2,
  Calendar,
  Clock,
  User,
  Phone,
  Camera,
  Upload,
  X,
  Coins,
  Gem,
  CheckCircle2,
  ArrowRight,
  Filter,
  RefreshCw,
  Eye,
  ReceiptText
} from 'lucide-react';

export const CustomerOrderView: React.FC = () => {
  const {
    orders,
    saveOrder,
    deleteOrder,
    rates,
    silverRates,
    shopProfile,
    transferCalculatorItemToPos,
    setActiveTab,
    showToast
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'gold' | 'silver' | 'pending' | 'delivered'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<CustomerOrder | null>(null);

  // Print Slip State
  const [printOrder, setPrintOrder] = useState<CustomerOrder | null>(null);

  // Form State
  const [metalType, setMetalType] = useState<MetalType>('স্বর্ণ');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [itemName, setItemName] = useState('');
  const [karat, setKarat] = useState<KaratType>('22K');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [bhori, setBhori] = useState('0');
  const [ana, setAna] = useState('0');
  const [roti, setRoti] = useState('0');
  const [point, setPoint] = useState('0');
  const [grams, setGrams] = useState('0');
  const [ratePerBhori, setRatePerBhori] = useState<number>(rates['22K'] || 130000);
  const [makingCharge, setMakingCharge] = useState<number>(2000);
  const [stonePrice, setStonePrice] = useState<number>(0);
  const [advancePaid, setAdvancePaid] = useState<number>(0);
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<OrderStatus>('অর্ডার গৃহীত');
  const [sampleImageUrl, setSampleImageUrl] = useState<string>('');

  // Camera capture states
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto-set rate when metal or karat changes
  useEffect(() => {
    if (metalType === 'স্বর্ণ') {
      const gRate = rates[karat] || rates['22K'] || 130000;
      setRatePerBhori(gRate);
    } else {
      const sKarat = karat === '24K' ? '22K' : karat;
      const sRate = Number(silverRates[sKarat as '22K' | '21K' | '18K' | 'সনাতন']) || 2100;
      setRatePerBhori(sRate);
    }
  }, [metalType, karat, rates, silverRates]);

  // Recalculate grams when parts change
  const handlePartChange = (field: 'bhori' | 'ana' | 'roti' | 'point', val: string) => {
    const num = Math.max(0, parseFloat(val) || 0);
    const newParts = {
      bhori: field === 'bhori' ? num : Math.max(0, parseFloat(bhori) || 0),
      ana: field === 'ana' ? num : Math.max(0, parseFloat(ana) || 0),
      roti: field === 'roti' ? num : Math.max(0, parseFloat(roti) || 0),
      point: field === 'point' ? num : Math.max(0, parseFloat(point) || 0),
    };
    if (field === 'bhori') setBhori(val);
    if (field === 'ana') setAna(val);
    if (field === 'roti') setRoti(val);
    if (field === 'point') setPoint(val);

    const calculatedGrams = partsToGrams(newParts);
    setGrams(calculatedGrams.toString());
  };

  const handleGramsChange = (val: string) => {
    setGrams(val);
    const g = Math.max(0, parseFloat(val) || 0);
    const p = gramsToParts(g);
    setBhori(p.bhori.toString());
    setAna(p.ana.toString());
    setRoti(p.roti.toString());
    setPoint(p.point.toString());
  };

  // Calculations
  const calculatedPoints = partsToPoints({
    bhori: parseFloat(bhori) || 0,
    ana: parseFloat(ana) || 0,
    roti: parseFloat(roti) || 0,
    point: parseFloat(point) || 0,
  });
  const metalPrice = Math.round((calculatedPoints / 960) * ratePerBhori);
  const totalPrice = Math.round(metalPrice + (Number(makingCharge) || 0) + (Number(stonePrice) || 0));
  const dueAmount = Math.max(0, totalPrice - (Number(advancePaid) || 0));

  // Camera stream handler
  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false,
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access error:', err);
      showToast('ক্যামেরা চালু করা যায়নি। অনুগ্রহ করে ফাইল আপলোড ব্যবহার করুন।', 'error');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setSampleImageUrl(dataUrl);
      stopCamera();
      showToast('ডিজাইনের ছবি ক্যাপচার সম্পন্ন!');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setSampleImageUrl(reader.result as string);
        showToast('ডিজাইনের ছবি আপলোড সম্পন্ন!');
      };
      reader.readAsDataURL(file);
    }
  };

  const openNewOrderModal = (presetMetal: MetalType = 'স্বর্ণ') => {
    setEditingOrder(null);
    setMetalType(presetMetal);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    setItemName('');
    setKarat('22K');
    const defaultDelivery = new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0];
    setDeliveryDate(defaultDelivery);
    setBhori('0');
    setAna('8');
    setRoti('0');
    setPoint('0');
    setGrams(partsToGrams({ bhori: 0, ana: 8, roti: 0, point: 0 }).toString());
    const initialRate = presetMetal === 'স্বর্ণ' ? rates['22K'] || 130000 : silverRates['22K'] || 2100;
    setRatePerBhori(initialRate);
    setMakingCharge(presetMetal === 'স্বর্ণ' ? 2500 : 500);
    setStonePrice(0);
    setAdvancePaid(5000);
    setNotes('');
    setStatus('অর্ডার গৃহীত');
    setSampleImageUrl('');
    setIsModalOpen(true);
  };

  const openEditOrderModal = (order: CustomerOrder) => {
    setEditingOrder(order);
    setMetalType(order.metalType);
    setCustomerName(order.customerName);
    setCustomerPhone(order.customerPhone);
    setCustomerAddress(order.customerAddress);
    setItemName(order.itemName);
    setKarat(order.karat);
    setDeliveryDate(order.deliveryDate);
    setBhori(order.weightParts.bhori.toString());
    setAna(order.weightParts.ana.toString());
    setRoti(order.weightParts.roti.toString());
    setPoint(order.weightParts.point.toString());
    setGrams(order.weightGrams.toString());
    setRatePerBhori(order.ratePerBhori);
    setMakingCharge(order.makingCharge);
    setStonePrice(order.stonePrice);
    setAdvancePaid(order.advancePaid);
    setNotes(order.notes || '');
    setStatus(order.status);
    setSampleImageUrl(order.sampleImageUrl || '');
    setIsModalOpen(true);
  };

  const handleSaveOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      showToast('দয়া করে গ্রাহকের নাম দিন।', 'error');
      return;
    }
    if (!itemName.trim()) {
      showToast('দয়া করে অলংকারের নাম দিন।', 'error');
      return;
    }

    const orderParts = {
      bhori: Math.max(0, parseFloat(bhori) || 0),
      ana: Math.max(0, parseFloat(ana) || 0),
      roti: Math.max(0, parseFloat(roti) || 0),
      point: Math.max(0, parseFloat(point) || 0),
    };

    const now = new Date();
    const timeStr = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });

    const orderData: CustomerOrder = {
      id: editingOrder ? editingOrder.id : `ord-${Date.now()}`,
      orderNumber: editingOrder ? editingOrder.orderNumber : `ORD-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${String(Math.floor(1000 + Math.random() * 9000))}`,
      date: editingOrder ? editingOrder.date : now.toISOString(),
      time: editingOrder ? editingOrder.time : timeStr,
      deliveryDate: deliveryDate || new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0],
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      metalType,
      itemName: itemName.trim(),
      karat,
      weightParts: orderParts,
      weightGrams: Math.max(0, parseFloat(grams) || partsToGrams(orderParts)),
      ratePerBhori,
      metalPrice,
      makingCharge: Number(makingCharge) || 0,
      stonePrice: Number(stonePrice) || 0,
      totalPrice,
      advancePaid: Number(advancePaid) || 0,
      dueAmount,
      sampleImageUrl: sampleImageUrl || undefined,
      notes: notes.trim() || undefined,
      status,
      createdAt: editingOrder ? editingOrder.createdAt : now.toISOString(),
    };

    saveOrder(orderData);
    setIsModalOpen(false);
    stopCamera();
    setPrintOrder(orderData);
  };

  const handleQuickStatusChange = (order: CustomerOrder, newStatus: OrderStatus) => {
    const updated = { ...order, status: newStatus };
    saveOrder(updated);
    showToast(`অর্ডার #${order.orderNumber} এর স্ট্যাটাস '${newStatus}' করা হয়েছে।`);
  };

  // Convert delivered order into POS invoice
  const handleConvertToPosMemo = (order: CustomerOrder) => {
    transferCalculatorItemToPos({
      productName: `${order.metalType}: ${order.itemName} (অর্ডার নং: ${order.orderNumber})`,
      productCode: order.orderNumber,
      karat: order.karat,
      metalType: order.metalType,
      weightParts: order.weightParts,
      weightGrams: order.weightGrams,
      ratePerBhori: order.ratePerBhori,
      goldBasePrice: order.metalPrice,
      makingCharge: order.makingCharge,
      stonePrice: order.stonePrice,
      itemTotal: order.totalPrice,
      quantity: 1,
      imageUrl: order.sampleImageUrl,
    });
    showToast(`অর্ডার #${order.orderNumber} এর তথ্য ক্যাশ মেমোতে নিয়ে যাওয়া হয়েছে।`);
  };

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    if (activeFilter === 'gold' && o.metalType !== 'স্বর্ণ') return false;
    if (activeFilter === 'silver' && o.metalType !== 'রূপা') return false;
    if (activeFilter === 'pending' && o.status === 'ডেলিভারি সম্পন্ন') return false;
    if (activeFilter === 'delivered' && o.status !== 'ডেলিভারি সম্পন্ন') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = o.customerName.toLowerCase().includes(q);
      const matchPhone = o.customerPhone.toLowerCase().includes(q);
      const matchItem = o.itemName.toLowerCase().includes(q);
      const matchNum = o.orderNumber.toLowerCase().includes(q);
      return matchName || matchPhone || matchItem || matchNum;
    }
    return true;
  });

  const goldOrdersCount = orders.filter(o => o.metalType === 'স্বর্ণ').length;
  const silverOrdersCount = orders.filter(o => o.metalType === 'রূপা').length;
  const pendingOrdersCount = orders.filter(o => o.status !== 'ডেলিভারি সম্পন্ন' && o.status !== 'বাতিল').length;
  const totalOrderAdvance = orders.reduce((sum, o) => sum + (o.advancePaid || 0), 0);
  const totalOrderDue = orders.reduce((sum, o) => sum + (o.dueAmount || 0), 0);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Top Header & Overview */}
      <div className="bg-gradient-to-r from-[#1c170e] via-[#14120c] to-[#0c0b08] p-4 sm:p-6 rounded-2xl border border-amber-600/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs bg-amber-500/20 text-amber-300 font-bold px-2.5 py-0.5 rounded border border-amber-600/30 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              কাস্টমার অর্ডার বুক
            </span>
            <span className="text-xs text-amber-400/80">
              স্বর্ণ ও রূপার নতুন অলংকার তৈরির অর্ডার
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-amber-100 flex items-center gap-2">
            <span>স্বর্ণ ও রূপার অর্ডার সেকশন</span>
          </h2>
          <p className="text-xs text-amber-300/70 mt-0.5">
            গ্রাহকের পছন্দ অনুযায়ী স্বর্ণ বা রূপা নির্বাচন করে মাপ, মজুরি, পাথর ও অগ্রিম গ্রহণপূর্বক অর্ডার রসিদ প্রিন্ট করুন।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => openNewOrderModal('স্বর্ণ')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-950/50 active:scale-95 transition-all"
          >
            <Gem className="w-4 h-4 text-black" />
            স্বর্ণের অর্ডার লিখুন
          </button>

          <button
            onClick={() => openNewOrderModal('রূপা')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-slate-200 to-slate-400 hover:from-white hover:to-slate-300 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
          >
            <Coins className="w-4 h-4 text-slate-900" />
            রূপার অর্ডার লিখুন
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-amber-400/80 mb-1">
            <span className="text-xs font-semibold">চলমান মোট অর্ডার</span>
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl sm:text-2xl font-black font-mono text-amber-200">
            {toBengaliNumber(pendingOrdersCount)} টি
          </p>
          <div className="flex items-center justify-between text-[11px] text-amber-400/70 mt-2 pt-2 border-t border-amber-950">
            <span>স্বর্ণ: {toBengaliNumber(goldOrdersCount)} টি</span>
            <span>রূপা: {toBengaliNumber(silverOrdersCount)} টি</span>
          </div>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-emerald-400/80 mb-1">
            <span className="text-xs font-semibold">মোট অগ্রিম গ্রহণ</span>
            <Coins className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-xl sm:text-2xl font-black font-mono text-emerald-300">
            {formatTaka(totalOrderAdvance)}
          </p>
          <p className="text-[11px] text-emerald-500/80 mt-2 pt-2 border-t border-amber-950">
            কাস্টমার কর্তৃক অগ্রিম প্রাপ্ত
          </p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-amber-400/80 mb-1">
            <span className="text-xs font-semibold">ডেলিভারির সময় পাওনা</span>
            <ReceiptText className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl sm:text-2xl font-black font-mono text-amber-300">
            {formatTaka(totalOrderDue)}
          </p>
          <p className="text-[11px] text-amber-400/70 mt-2 pt-2 border-t border-amber-950">
            মাল হস্তান্তরের সময় আদায়যোগ্য
          </p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-blue-400/80 mb-1">
            <span className="text-xs font-semibold">আজকের বাজার দর</span>
            <Gem className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xs font-bold text-amber-200">
            স্বর্ণ ২২K: ৳{toBengaliNumber(rates['22K'].toLocaleString('en-IN'))}
          </p>
          <div className="text-[11px] text-slate-300 mt-2 pt-2 border-t border-amber-950">
            রূপা ২২K: ৳{toBengaliNumber((silverRates['22K'] || 2100).toLocaleString('en-IN'))}
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="bg-[#12110c] p-3.5 rounded-xl border border-amber-900/40 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto scrollbar-none pb-1 sm:pb-0 text-xs">
          {[
            { id: 'all', label: 'সকল অর্ডার', count: orders.length },
            { id: 'gold', label: 'স্বর্ণের অর্ডার', count: goldOrdersCount },
            { id: 'silver', label: 'রূপার অর্ডার', count: silverOrdersCount },
            { id: 'pending', label: 'চলমান / প্রক্রিয়াধীন', count: pendingOrdersCount },
            { id: 'delivered', label: 'ডেলিভারি সম্পন্ন', count: orders.length - pendingOrdersCount },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                activeFilter === tab.id
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                  : 'text-amber-200/60 hover:text-amber-100 hover:bg-amber-950/40'
              }`}
            >
              <span>{tab.label}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/40 border border-amber-700/40 font-mono">
                {toBengaliNumber(tab.count)}
              </span>
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-amber-400/60" />
          <input
            type="text"
            placeholder="অর্ডার নং, নাম বা ফোন নম্বর দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#0b0a08] border border-amber-700/40 rounded-lg pl-9 pr-3 py-1.5 text-xs text-amber-100 placeholder-amber-400/40 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Orders List / Table */}
      {filteredOrders.length === 0 ? (
        <div className="bg-[#12110c] rounded-2xl border border-amber-900/40 p-12 text-center space-y-4">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400">
            <Sparkles className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-amber-200">বর্তমানে কোনো অর্ডার পাওয়া যায়নি</h3>
          <p className="text-xs text-amber-400/60 max-w-md mx-auto">
            কাস্টমার দোকানে এসে গহনা বানানোর বায়না দিলে উপরে "স্বর্ণের অর্ডার লিখুন" অথবা "রূপার অর্ডার লিখুন" বাটনে ক্লিক করে নতুন অর্ডার যুক্ত করুন।
          </p>
          <div className="flex justify-center gap-2 pt-2">
            <button
              onClick={() => openNewOrderModal('স্বর্ণ')}
              className="px-4 py-2 rounded-xl bg-amber-500 text-black font-bold text-xs"
            >
              + স্বর্ণের অর্ডার
            </button>
            <button
              onClick={() => openNewOrderModal('রূপা')}
              className="px-4 py-2 rounded-xl bg-slate-700 text-white font-bold text-xs"
            >
              + রূপার অর্ডার
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOrders.map((order) => {
            const isGold = order.metalType === 'স্বর্ণ';
            return (
              <div
                key={order.id}
                className="bg-[#12110c] rounded-2xl border border-amber-900/40 hover:border-amber-500/50 p-4 transition-all shadow-lg flex flex-col justify-between space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2 border-b border-amber-950 pb-2.5">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          isGold
                            ? 'bg-amber-950/80 text-amber-300 border-amber-600/50'
                            : 'bg-slate-800 text-slate-200 border-slate-600'
                        }`}
                      >
                        {isGold ? 'স্বর্ণ' : 'রূপা'} ({order.karat})
                      </span>
                      <span className="font-mono text-xs font-bold text-amber-400">
                        #{order.orderNumber}
                      </span>
                    </div>
                    <h4 className="font-bold text-sm text-amber-100 mt-1 flex items-center gap-1.5">
                      {order.itemName}
                    </h4>
                  </div>

                  {/* Status Dropdown */}
                  <select
                    value={order.status}
                    onChange={(e) => handleQuickStatusChange(order, e.target.value as OrderStatus)}
                    className={`text-[10px] font-bold px-2 py-1 rounded-lg border focus:outline-none ${
                      order.status === 'ডেলিভারি সম্পন্ন'
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/50'
                        : order.status === 'ডেলিভারির জন্য প্রস্তুত'
                        ? 'bg-blue-950/80 text-blue-300 border-blue-600/50'
                        : order.status === 'তৈরি হচ্ছে'
                        ? 'bg-amber-950/80 text-amber-300 border-amber-600/50'
                        : 'bg-neutral-900 text-neutral-300 border-neutral-700'
                    }`}
                  >
                    <option value="অর্ডার গৃহীত">অর্ডার গৃহীত</option>
                    <option value="তৈরি হচ্ছে">তৈরি হচ্ছে</option>
                    <option value="ডেলিভারির জন্য প্রস্তুত">প্রস্তুত</option>
                    <option value="ডেলিভারি সম্পন্ন">ডেলিভারি সম্পন্ন</option>
                    <option value="বাতিল">বাতিল</option>
                  </select>
                </div>

                {/* Sample Photo & Customer Info */}
                <div className="flex items-center gap-3">
                  {order.sampleImageUrl ? (
                    <img
                      src={order.sampleImageUrl}
                      alt={order.itemName}
                      className="w-16 h-16 rounded-xl object-cover border border-amber-700/50 shadow shrink-0"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-amber-950/30 border border-amber-900/40 flex flex-col items-center justify-center text-amber-500/40 shrink-0">
                      <Gem className="w-6 h-6" />
                      <span className="text-[9px] mt-0.5">ছবি নেই</span>
                    </div>
                  )}

                  <div className="space-y-0.5 text-xs text-amber-200/80 flex-1">
                    <p className="font-semibold text-amber-100 flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-amber-400" />
                      <span>{order.customerName}</span>
                    </p>
                    {order.customerPhone && (
                      <p className="text-[11px] text-amber-300/70 flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3 text-amber-400" />
                        <span>{order.customerPhone}</span>
                      </p>
                    )}
                    <p className="text-[11px] text-amber-400/60 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-amber-400" />
                      <span>ডেলিভারি: {new Date(order.deliveryDate).toLocaleDateString('bn-BD')}</span>
                    </p>
                  </div>
                </div>

                {/* Weight & Price Details */}
                <div className="bg-[#0b0a08] rounded-xl p-2.5 border border-amber-950 text-xs space-y-1">
                  <div className="flex items-center justify-between text-amber-300/80">
                    <span>ওজন:</span>
                    <span className="font-bold text-amber-200 font-mono">
                      {formatWeightPartsBn(order.weightParts)} ({toBengaliNumber(order.weightGrams)} গ্রাম)
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-amber-300/80">
                    <span>মজুরি:</span>
                    <span className="font-mono">{formatTaka(order.makingCharge)}</span>
                  </div>
                  <div className="flex items-center justify-between text-amber-300/80 pt-1 border-t border-amber-950/60">
                    <span className="font-bold text-amber-100">মোট মূল্য:</span>
                    <span className="font-bold text-amber-300 font-mono">{formatTaka(order.totalPrice)}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-amber-950/40">
                    <span className="text-emerald-400">অগ্রিম: {formatTaka(order.advancePaid)}</span>
                    <span className={`font-bold font-mono ${order.dueAmount > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                      বাকি: {formatTaka(order.dueAmount)}
                    </span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center justify-between gap-1.5 pt-1">
                  <button
                    onClick={() => setPrintOrder(order)}
                    className="flex-1 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-600/40 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>রসিদ</span>
                  </button>

                  <button
                    onClick={() => handleConvertToPosMemo(order)}
                    title="ক্যাশ মেমোতে রূপান্তর করুন"
                    className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-amber-700/40 text-xs flex items-center gap-1"
                  >
                    <ReceiptText className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">মেমো</span>
                  </button>

                  <button
                    onClick={() => openEditOrderModal(order)}
                    title="এডিট করুন"
                    className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-amber-700/40 text-xs"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm('আপনি কি নিশ্চিতভাবে এই অর্ডারটি মুছে ফেলতে চান?')) {
                        deleteOrder(order.id);
                      }
                    }}
                    title="মুছুন"
                    className="p-1.5 rounded-lg bg-red-950/30 hover:bg-red-900/40 text-red-400 border border-red-800/40 text-xs"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New / Edit Order Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-4 sm:p-6 max-w-2xl w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-amber-900/40 pb-3">
              <h3 className="font-bold text-base sm:text-lg text-amber-200 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                {editingOrder ? 'অর্ডার সম্পাদনা' : 'নতুন অলংকারের অর্ডার গ্রহণ'}
              </h3>
              <button
                onClick={() => {
                  stopCamera();
                  setIsModalOpen(false);
                }}
                className="p-1 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveOrder} className="space-y-4 text-xs">
              {/* Metal Selection Toggle: স্বর্ণ vs রূপা */}
              <div className="space-y-1.5">
                <label className="font-bold text-amber-300">ধাতুর প্রকার নির্বাচন করুন *</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMetalType('স্বর্ণ')}
                    className={`py-2.5 rounded-xl border font-bold flex items-center justify-center gap-2 transition-all ${
                      metalType === 'স্বর্ণ'
                        ? 'bg-amber-500 text-black border-amber-400 shadow-md font-extrabold'
                        : 'bg-neutral-900 text-amber-200/70 border-amber-800/40 hover:bg-neutral-800'
                    }`}
                  >
                    <Gem className="w-4 h-4" />
                    <span>স্বর্ণের অর্ডার (Gold)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMetalType('রূপা')}
                    className={`py-2.5 rounded-xl border font-bold flex items-center justify-center gap-2 transition-all ${
                      metalType === 'রূপা'
                        ? 'bg-slate-200 text-slate-950 border-white shadow-md font-extrabold'
                        : 'bg-neutral-900 text-slate-300/70 border-slate-700 hover:bg-neutral-800'
                    }`}
                  >
                    <Coins className="w-4 h-4" />
                    <span>রূপার অর্ডার (Silver)</span>
                  </button>
                </div>
              </div>

              {/* Customer Information */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#0d0c09] p-3 rounded-xl border border-amber-900/40">
                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">গ্রাহকের নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="উদাঃ মোঃ আবুল কালাম"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">মোবাইল নম্বর</label>
                  <input
                    type="tel"
                    placeholder="০১৭xxxxxxxx"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">ঠিকানা</label>
                  <input
                    type="text"
                    placeholder="গ্রাম/শহর"
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Jewelry Item Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-semibold text-amber-300">অলংকারের বিবরণ / নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder={metalType === 'স্বর্ণ' ? 'উদাঃ ২২ ক্যারেট রাজকীয় সীতা হার' : 'উদাঃ রূপার নূপুর / পায়েল (জোড়া)'}
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">ক্যারেট</label>
                  <select
                    value={karat}
                    onChange={(e) => setKarat(e.target.value as KaratType)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400 font-semibold"
                  >
                    <option value="22K">২২ ক্যারেট (হলমার্ক)</option>
                    <option value="21K">২১ ক্যারেট</option>
                    <option value="18K">১৮ ক্যারেট</option>
                    <option value="24K">২৪ ক্যারেট (পাকা)</option>
                    <option value="সনাতন">সনাতন</option>
                  </select>
                </div>
              </div>

              {/* Weight: Traditional Gold Parts + Grams */}
              <div className="bg-[#0e0c08] p-3 rounded-xl border border-amber-800/40 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-amber-300">অলংকারের ওজন নির্ধারণ</label>
                  <span className="text-[11px] text-amber-400/80 font-mono">
                    ১ ভরি = ১৬ আনা = ৯৬০ পয়েন্ট = ১১.৬৬৪ গ্রাম
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  <div>
                    <label className="text-[11px] text-amber-400/80">ভরি</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={bhori}
                      onChange={(e) => handlePartChange('bhori', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-amber-400/80">আনা</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      max="15.99"
                      value={ana}
                      onChange={(e) => handlePartChange('ana', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-amber-400/80">রতি</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      max="5.99"
                      value={roti}
                      onChange={(e) => handlePartChange('roti', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-amber-400/80">পয়েন্ট</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      max="9.99"
                      value={point}
                      onChange={(e) => handlePartChange('point', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="text-[11px] text-emerald-400 font-semibold">গ্রাম (স্বয়ংক্রিয়)</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={grams}
                      onChange={(e) => handleGramsChange(e.target.value)}
                      className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono font-bold focus:border-emerald-400"
                    />
                  </div>
                </div>
              </div>

              {/* Rates, Making Charge, Stone, Advance */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">
                    প্রতি ভরি দর (টাকা)
                  </label>
                  <input
                    type="number"
                    value={ratePerBhori}
                    onChange={(e) => setRatePerBhori(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">কারিগর মজুরি (টাকা)</label>
                  <input
                    type="number"
                    value={makingCharge}
                    onChange={(e) => setMakingCharge(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">পাথর / অতিরিক্ত</label>
                  <input
                    type="number"
                    value={stonePrice}
                    onChange={(e) => setStonePrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-emerald-400">অগ্রিম জমা (টাকা) *</label>
                  <input
                    type="number"
                    value={advancePaid}
                    onChange={(e) => setAdvancePaid(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-3 py-1.5 text-emerald-300 font-mono font-bold focus:border-emerald-400"
                  />
                </div>
              </div>

              {/* Delivery Date & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">ডেলিভারির সম্ভাব্য তারিখ *</label>
                  <input
                    type="date"
                    required
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">অর্ডার স্ট্যাটাস</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as OrderStatus)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400 font-semibold"
                  >
                    <option value="অর্ডার গৃহীত">অর্ডার গৃহীত</option>
                    <option value="তৈরি হচ্ছে">তৈরি হচ্ছে</option>
                    <option value="ডেলিভারির জন্য প্রস্তুত">ডেলিভারির জন্য প্রস্তুত</option>
                    <option value="ডেলিভারি সম্পন্ন">ডেলিভারি সম্পন্ন</option>
                    <option value="বাতিল">বাতিল</option>
                  </select>
                </div>
              </div>

              {/* Camera / Sample Design Photo */}
              <div className="bg-[#0d0c09] p-3 rounded-xl border border-amber-900/40 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-amber-300 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-amber-400" />
                    <span>অলংকারের নমুনা ডিজাইন / ছবি (ঐচ্ছিক)</span>
                  </label>
                  {sampleImageUrl && (
                    <button
                      type="button"
                      onClick={() => setSampleImageUrl('')}
                      className="text-red-400 hover:text-red-300 text-[11px] flex items-center gap-1"
                    >
                      <X className="w-3.5 h-3.5" /> ছবি সরান
                    </button>
                  )}
                </div>

                {isCameraActive ? (
                  <div className="space-y-2">
                    <div className="relative rounded-xl overflow-hidden bg-black aspect-video max-h-56 mx-auto border border-amber-600/50">
                      <video ref={videoRef} autoPlay playsInline className="w-full h-full object-contain" />
                    </div>
                    <div className="flex justify-center gap-2">
                      <button
                        type="button"
                        onClick={capturePhoto}
                        className="px-4 py-1.5 rounded-lg bg-emerald-500 text-black font-bold text-xs flex items-center gap-1"
                      >
                        <Camera className="w-3.5 h-3.5" /> ছবি তুলুন
                      </button>
                      <button
                        type="button"
                        onClick={stopCamera}
                        className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                      >
                        বাতিল
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-3">
                    {sampleImageUrl ? (
                      <img
                        src={sampleImageUrl}
                        alt="Sample Preview"
                        className="w-16 h-16 rounded-xl object-cover border border-amber-600"
                      />
                    ) : null}

                    <button
                      type="button"
                      onClick={startCamera}
                      className="px-3 py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-amber-700/50 flex items-center gap-1.5 font-medium"
                    >
                      <Camera className="w-4 h-4 text-amber-400" />
                      <span>ক্যামেরা দিয়ে ছবি তুলুন</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-amber-700/50 flex items-center gap-1.5 font-medium"
                    >
                      <Upload className="w-4 h-4 text-amber-400" />
                      <span>গ্যালারি থেকে আপলোড</span>
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </div>
                )}
              </div>

              {/* Order Special Notes */}
              <div className="space-y-1">
                <label className="font-semibold text-amber-300">বিশেষ কোনো নির্দেশনা / কারিগরের নোট</label>
                <input
                  type="text"
                  placeholder="যেমনঃ পেছনের চেইনে বিশেষ হুক, খোদাই করা নাম, ইত্যাদী..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Price Summary Banner */}
              <div className="bg-gradient-to-r from-amber-950/70 via-black to-amber-950/70 p-3.5 rounded-xl border border-amber-600/50 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div>
                  <span className="text-amber-400/80">ধাতুর মূল্য: </span>
                  <span className="font-bold text-amber-200 font-mono">{formatTaka(metalPrice)}</span>
                  <span className="text-neutral-500 mx-1.5">|</span>
                  <span className="text-amber-400/80">মজুরি: </span>
                  <span className="font-bold text-amber-200 font-mono">{formatTaka(Number(makingCharge) || 0)}</span>
                </div>

                <div className="flex items-center gap-4 text-sm">
                  <div>
                    <span className="text-amber-300 font-bold">সর্বমোট: </span>
                    <span className="font-black text-amber-400 font-mono">{formatTaka(totalPrice)}</span>
                  </div>
                  <div>
                    <span className="text-red-400 font-bold">বাকি: </span>
                    <span className="font-black text-red-300 font-mono">{formatTaka(dueAmount)}</span>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setIsModalOpen(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 hover:bg-neutral-700 font-semibold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold hover:from-amber-400 hover:to-amber-500 shadow-lg"
                >
                  {editingOrder ? 'হালনাগাদ ও সংরক্ষণ' : 'অর্ডার সংরক্ষণ ও রসিদ তৈরি'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Order Printable Slip Modal */}
      {printOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-4 sm:p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-900/40 pb-2 no-print">
              <h3 className="font-bold text-amber-200 flex items-center gap-2 text-sm">
                <Printer className="w-4 h-4 text-amber-400" />
                অর্ডার ভাউচার / স্লিপ প্রিভিউ
              </h3>
              <button
                onClick={() => setPrintOrder(null)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable Slip (Clean white paper style for print) */}
            <div
              id="order-slip-printable"
              className="bg-white text-black p-5 rounded-xl border border-neutral-300 shadow-inner font-['Hind_Siliguri',sans-serif] space-y-3"
            >
              {/* Shop Header */}
              <div className="text-center border-b border-dashed border-neutral-400 pb-2">
                <h2 className="text-lg font-black tracking-tight text-neutral-900">
                  {shopProfile.name}
                </h2>
                <p className="text-[11px] text-neutral-700">{shopProfile.slogan}</p>
                <p className="text-[10px] text-neutral-600">{shopProfile.address}</p>
                <p className="text-[10px] text-neutral-700 font-bold">ফোন: {shopProfile.phone}</p>
                <div className="mt-1 inline-block bg-neutral-900 text-white text-[10px] font-bold px-3 py-0.5 rounded-full">
                  অলংকার অর্ডার রসিদ (Customer Copy)
                </div>
              </div>

              {/* Order Info */}
              <div className="flex justify-between items-center text-[11px] border-b border-neutral-200 pb-1.5">
                <div>
                  <p><strong>অর্ডার নং:</strong> {printOrder.orderNumber}</p>
                  <p><strong>তারিখ:</strong> {new Date(printOrder.date).toLocaleDateString('bn-BD')}</p>
                  <p><strong>সময়:</strong> {printOrder.time || new Date().toLocaleTimeString('bn-BD')}</p>
                </div>
                <div className="text-right">
                  <p><strong>সম্ভাব্য ডেলিভারি:</strong> {new Date(printOrder.deliveryDate).toLocaleDateString('bn-BD')}</p>
                  <p><strong>ধাতু:</strong> {printOrder.metalType} ({printOrder.karat})</p>
                  <p><strong>স্ট্যাটাস:</strong> {printOrder.status}</p>
                </div>
              </div>

              {/* Customer Info */}
              <div className="bg-neutral-50 p-2 rounded border border-neutral-200 text-[11px]">
                <p><strong>গ্রাহকের নাম:</strong> {printOrder.customerName}</p>
                {printOrder.customerPhone && <p><strong>মোবাইল:</strong> {printOrder.customerPhone}</p>}
                {printOrder.customerAddress && <p><strong>ঠিকানা:</strong> {printOrder.customerAddress}</p>}
              </div>

              {/* Order Item Details */}
              <table className="w-full text-[11px] border-collapse border border-neutral-300">
                <thead>
                  <tr className="bg-neutral-100 text-neutral-800">
                    <th className="border border-neutral-300 p-1 text-left">বিবরণ</th>
                    <th className="border border-neutral-300 p-1 text-center">ওজন</th>
                    <th className="border border-neutral-300 p-1 text-right">মজুরি</th>
                    <th className="border border-neutral-300 p-1 text-right">মোট (৳)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-neutral-300 p-1.5 font-semibold">
                      {printOrder.itemName}
                      {printOrder.notes && (
                        <p className="text-[10px] text-neutral-500 italic mt-0.5">নোট: {printOrder.notes}</p>
                      )}
                    </td>
                    <td className="border border-neutral-300 p-1.5 text-center font-mono">
                      {formatWeightPartsBn(printOrder.weightParts)}
                      <br />
                      <span className="text-[10px] text-neutral-500">({toBengaliNumber(printOrder.weightGrams)}g)</span>
                    </td>
                    <td className="border border-neutral-300 p-1.5 text-right font-mono">
                      {formatTaka(printOrder.makingCharge)}
                    </td>
                    <td className="border border-neutral-300 p-1.5 text-right font-bold font-mono">
                      {formatTaka(printOrder.totalPrice)}
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Financial Breakdown */}
              <div className="space-y-1 text-[11px] border-t border-neutral-300 pt-1.5">
                <div className="flex justify-between">
                  <span>সর্বমোট প্রাক্কলিত মূল্য:</span>
                  <span className="font-bold font-mono">{formatTaka(printOrder.totalPrice)}</span>
                </div>
                <div className="flex justify-between text-emerald-800 font-semibold">
                  <span>অগ্রিম জমা:</span>
                  <span className="font-mono font-bold">{formatTaka(printOrder.advancePaid)}</span>
                </div>
                <div className="flex justify-between text-red-700 font-bold text-xs border-t border-dashed border-neutral-300 pt-1">
                  <span>ডেলিভারির সময় প্রদেয় বাকি:</span>
                  <span className="font-mono">{formatTaka(printOrder.dueAmount)}</span>
                </div>
              </div>

              {/* Terms & Signatures */}
              <div className="text-[9px] text-neutral-600 border-t border-dashed border-neutral-400 pt-2 space-y-1">
                <p>* ডেলিভারির সময় এই স্লিপ প্রদর্শন করে বাকি টাকা পরিশোধপূর্বক গহনা গ্রহণ করুন।</p>
                <div className="flex justify-between items-end pt-5 text-[10px] text-neutral-800">
                  <div className="border-t border-neutral-500 pt-0.5 text-center w-28">
                    গ্রাহকের স্বাক্ষর
                  </div>
                  <div className="border-t border-neutral-500 pt-0.5 text-center w-36 font-semibold">
                    মেসার্স মিঠুন অলংকার হাউজ
                  </div>
                </div>
              </div>
            </div>

            {/* Print Controls */}
            <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40 no-print">
              <button
                onClick={() => setPrintOrder(null)}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
              >
                বন্ধ করুন
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs flex items-center gap-1.5 shadow"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>প্রিন্ট করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
