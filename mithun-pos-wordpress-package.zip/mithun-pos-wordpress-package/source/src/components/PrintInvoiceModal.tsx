/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Invoice } from '../types';
import { formatTaka, toBengaliNumber, formatWeightPartsBn } from '../utils/goldCalculator';
import { BarcodeRenderer } from './BarcodeRenderer';
import { Printer, X, Download, Share2, CheckCircle2 } from 'lucide-react';

interface PrintInvoiceModalProps {
  invoice: Invoice | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PrintInvoiceModal: React.FC<PrintInvoiceModalProps> = ({
  invoice,
  isOpen,
  onClose,
}) => {
  const { shopProfile } = useApp();
  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-amber-600/50 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Toolbar (hidden on print) */}
        <div className="no-print bg-[#14120e] border-b border-amber-700/40 p-3 sm:px-6 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-amber-200 text-sm sm:text-base">
              ডিজিটাল ক্যাশ মেমো / চালান (#{invoice.memoNumber})
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              aria-label="প্রিন্ট করুন"
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs flex items-center gap-1.5 shadow"
            >
              <Printer className="w-4 h-4" />
              প্রিন্ট / PDF মেমো
            </button>
            <button
              onClick={onClose}
              aria-label="বন্ধ করুন"
              className="p-1.5 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Memo Container */}
        <div className="p-3 sm:p-6 overflow-y-auto bg-neutral-950 flex-1 flex justify-center">
          {/* Authentic Jewelry Cash Memo Design (White Paper for Clean Printing) */}
          <div
            ref={printAreaRef}
            className="print-area w-full max-w-xl bg-white text-neutral-900 p-6 rounded-lg shadow border border-amber-300 font-['Hind_Siliguri',sans-serif] space-y-4"
          >
            {/* Shop Header */}
            <div className="text-center border-b-2 border-amber-700 pb-3 space-y-1">
              <p className="text-[11px] text-amber-800 font-semibold tracking-widest">
                ॥ শ্রী শ্রী গণেশায় নমঃ ॥
              </p>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-amber-950 tracking-tight">
                {shopProfile.name}
              </h1>
              <p className="text-xs sm:text-sm font-bold text-amber-900 font-mono tracking-wide">
                মোবাইল: ০১৬২১৮৯৫৫৯০, ০১৭১৬১৪০৯৭২
              </p>
              <p className="text-xs text-neutral-800 font-semibold">
                দোকানের ঠিকানা: চালাকচর বাজার, স্বর্ণপট্টি, মনোহরদী, নরসিংদী।
              </p>
              <p className="text-[11px] text-neutral-600 font-medium">{shopProfile.slogan}</p>
            </div>

            {/* Memo Title & Meta */}
            <div className="flex flex-wrap items-center justify-between text-xs border-b border-neutral-300 pb-2">
              <div>
                <span className="font-bold text-neutral-800">ক্যাশ মেমো নং: </span>
                <span className="font-mono font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  {invoice.memoNumber}
                </span>
              </div>
              <div className="text-right">
                <div>
                  <span className="font-bold text-neutral-800">তারিখ: </span>
                  <span className="font-semibold">{new Date(invoice.date).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                </div>
                <div className="text-[11px] text-neutral-600">
                  <span className="font-bold text-neutral-800">সময়: </span>
                  <span className="font-mono font-bold text-amber-950">
                    {invoice.time || new Date(invoice.date).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true })}
                  </span>
                </div>
              </div>
            </div>

            {/* Customer Details */}
            <div className="bg-amber-50/50 p-2.5 rounded border border-amber-200/60 text-xs grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <p className="text-neutral-600">ক্রেতার নাম:</p>
                <p className="font-bold text-neutral-900 text-sm">{invoice.customerName || 'সম্মানিত ক্রেতা'}</p>
              </div>
              <div>
                <p className="text-neutral-600">মোবাইল নং:</p>
                <p className="font-bold text-neutral-900 font-mono">{invoice.customerPhone || 'প্রযোজ্য নয়'}</p>
              </div>
              {invoice.customerAddress && (
                <div className="sm:col-span-2">
                  <p className="text-neutral-600">ঠিকানা:</p>
                  <p className="text-neutral-800">{invoice.customerAddress}</p>
                </div>
              )}
            </div>

            {/* Items Table */}
            <div className="border border-neutral-300 rounded overflow-hidden">
              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-amber-100/70 border-b border-neutral-300 text-amber-950 font-bold">
                  <tr>
                    <th className="p-2 border-r border-neutral-300 text-center w-8">নং</th>
                    <th className="p-2 border-r border-neutral-300">বিবরণ / গহনার নাম</th>
                    <th className="p-2 border-r border-neutral-300 text-center">ক্যারেট</th>
                    <th className="p-2 border-r border-neutral-300 text-right">ওজন (গ্রাম)</th>
                    <th className="p-2 border-r border-neutral-300 text-right">মজুরি</th>
                    <th className="p-2 text-right">মোট মূল্য</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 text-neutral-800">
                  {invoice.items.map((item, idx) => (
                    <tr key={item.id} className="hover:bg-amber-50/30">
                      <td className="p-2 border-r border-neutral-200 text-center font-bold">{toBengaliNumber(idx + 1)}</td>
                      <td className="p-2 border-r border-neutral-200">
                        <div className="font-semibold text-neutral-900">{item.productName}</div>
                        <div className="text-[10px] text-neutral-500">
                          {formatWeightPartsBn(item.weightParts)}
                        </div>
                      </td>
                      <td className="p-2 border-r border-neutral-200 text-center font-bold text-amber-900">
                        {item.metalType === 'রূপা' ? `${item.karat} (রূপা)` : item.karat}
                      </td>
                      <td className="p-2 border-r border-neutral-200 text-right font-mono">
                        {toBengaliNumber(item.weightGrams)} গ্রাম
                      </td>
                      <td className="p-2 border-r border-neutral-200 text-right font-mono">
                        {formatTaka(item.makingCharge)}
                      </td>
                      <td className="p-2 text-right font-mono font-bold text-neutral-900">
                        {formatTaka(item.itemTotal)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Calculations Breakdown */}
            <div className="flex flex-col sm:flex-row justify-between gap-4 pt-2 border-t border-neutral-300">
              <div className="text-xs space-y-2 flex-1">
                <div className="bg-neutral-50 p-2 rounded border border-neutral-200">
                  <p className="font-bold text-neutral-800 mb-1">মোট ওজন সারসংক্ষেপ:</p>
                  <p className="text-neutral-700">{formatWeightPartsBn(invoice.totalWeightParts)}</p>
                  <p className="text-neutral-600 font-mono text-[11px]">মেট্রিক: {toBengaliNumber(invoice.totalWeightGrams)} গ্রাম</p>
                </div>
                <div className="text-[11px] text-neutral-600 space-y-0.5">
                  <p>পেমেন্ট মাধ্যম: <strong>{invoice.paymentMethod}</strong></p>
                  {invoice.notes && <p>মন্তব্য: {invoice.notes}</p>}
                </div>
                {/* Barcode on memo */}
                <div className="pt-1">
                  <BarcodeRenderer code={invoice.memoNumber} height={32} />
                </div>
              </div>

              {/* Totals Box */}
              <div className="w-full sm:w-60 text-xs space-y-1.5 border border-neutral-300 p-2.5 rounded bg-amber-50/40">
                <div className="flex justify-between text-neutral-700">
                  <span>উপমোট:</span>
                  <span className="font-mono font-bold">{formatTaka(invoice.subtotal)}</span>
                </div>
                {invoice.discount > 0 && (
                  <div className="flex justify-between text-emerald-800 font-semibold">
                    <span>বিশেষ ছাড়:</span>
                    <span className="font-mono">-{formatTaka(invoice.discount)}</span>
                  </div>
                )}
                {invoice.vatAmount > 0 && (
                  <div className="flex justify-between text-neutral-700">
                    <span>ভ্যাট:</span>
                    <span className="font-mono">+{formatTaka(invoice.vatAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-amber-950 font-extrabold text-sm border-t border-neutral-300 pt-1">
                  <span>সর্বমোট:</span>
                  <span className="font-mono">{formatTaka(invoice.grandTotal)}</span>
                </div>
                <div className="flex justify-between text-emerald-800 font-bold border-t border-dashed border-neutral-300 pt-1">
                  <span>জমা / পরিশোধ:</span>
                  <span className="font-mono">{formatTaka(invoice.paidAmount)}</span>
                </div>
                <div className={`flex justify-between font-bold pt-1 border-t border-neutral-300 ${invoice.dueAmount > 0 ? 'text-red-700 text-sm' : 'text-emerald-700'}`}>
                  <span>বকেয়া:</span>
                  <span className="font-mono">{formatTaka(invoice.dueAmount)}</span>
                </div>
              </div>
            </div>

            {/* Terms and Conditions & Signatures */}
            <div className="pt-4 border-t border-neutral-300 space-y-4">
              <p className="text-[10px] text-neutral-500 leading-tight">
                * শর্তাবলী: বিক্রিত গহনা ফেরত নেওয়া হয় না, তবে কার্টিস পরিবর্তনের ক্ষেত্রে বাজুস-এর নিয়ম প্রযোজ্য। যেকোনো প্রয়োজনে ক্যাশ মেমো সাথে আনুন।
              </p>

              <div className="flex justify-between items-end pt-8 text-xs text-neutral-700">
                <div className="text-center">
                  <div className="w-28 border-t border-neutral-400 mb-1" />
                  <p>ক্রেতার স্বাক্ষর</p>
                </div>
                <div className="text-center">
                  <div className="w-36 border-t border-neutral-800 mb-1 font-bold" />
                  <p className="font-bold text-neutral-900">কর্তৃপক্ষের স্বাক্ষর</p>
                  <p className="text-[10px] text-neutral-500">{shopProfile.name}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
