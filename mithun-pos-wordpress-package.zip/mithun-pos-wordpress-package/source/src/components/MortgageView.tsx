/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { MortgageRecord, MetalType, KaratType, MortgageStatus, PaymentMethod } from '../types';
import {
  partsToGrams,
  gramsToParts,
  formatWeightPartsBn,
  toBengaliNumber,
  formatTaka,
  partsToPoints,
} from '../utils/goldCalculator';
import {
  ShieldCheck,
  Plus,
  Search,
  Printer,
  Trash2,
  Calendar,
  Clock,
  User,
  Phone,
  Camera,
  Upload,
  X,
  Coins,
  Gem,
  CheckCircle2,
  AlertTriangle,
  History,
  DollarSign,
  FileText,
  BadgePercent,
  Check
} from 'lucide-react';

export const MortgageView: React.FC = () => {
  const {
    mortgages,
    saveMortgage,
    deleteMortgage,
    rates,
    silverRates,
    shopProfile,
    showToast,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'active' | 'overdue' | 'redeemed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMortgage, setEditingMortgage] = useState<MortgageRecord | null>(null);

  // Interest Payment Modal
  const [interestModalMortgage, setInterestModalMortgage] = useState<MortgageRecord | null>(null);
  const [interestAmount, setInterestAmount] = useState<number>(0);
  const [interestMonthsCount, setInterestMonthsCount] = useState<number>(1);
  const [interestNotes, setInterestNotes] = useState('');

  // Redeem Item Modal
  const [redeemModalMortgage, setRedeemModalMortgage] = useState<MortgageRecord | null>(null);
  const [redeemPrincipalPaid, setRedeemPrincipalPaid] = useState<number>(0);
  const [redeemInterestPaid, setRedeemInterestPaid] = useState<number>(0);

  // Print Slip
  const [printMortgage, setPrintMortgage] = useState<MortgageRecord | null>(null);

  // Form State
  const [metalType, setMetalType] = useState<MetalType>('স্বর্ণ');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [nidOrIdNumber, setNidOrIdNumber] = useState('');
  const [itemName, setItemName] = useState('');
  const [karat, setKarat] = useState<KaratType>('22K');

  // Weights
  const [bhori, setBhori] = useState('0');
  const [ana, setAna] = useState('8');
  const [roti, setRoti] = useState('0');
  const [point, setPoint] = useState('0');
  const [grams, setGrams] = useState(partsToGrams({ bhori: 0, ana: 8, roti: 0, point: 0 }).toString());

  // Loan & Interest
  const [loanAmount, setLoanAmount] = useState<number>(20000);
  const [monthlyInterestRate, setMonthlyInterestRate] = useState<number>(2.5); // 2.5%
  const [durationMonths, setDurationMonths] = useState<number>(6);
  const [estimatedValue, setEstimatedValue] = useState<number>(35000);
  const [notes, setNotes] = useState('');
  const [itemImageUrl, setItemImageUrl] = useState<string>('');

  // Camera
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto estimate market value
  const handlePartChange = (field: 'bhori' | 'ana' | 'roti' | 'point', val: string) => {
    const num = Math.max(0, parseFloat(val) || 0);
    const newParts = {
      bhori: field === 'bhori' ? num : Math.max(0, parseFloat(bhori) || 0),
      ana: field === 'ana' ? num : Math.max(0, parseFloat(ana) || 0),
      roti: field === 'roti' ? num : Math.max(0, parseFloat(roti) || 0),
      point: field === 'point' ? num : Math.max(0, parseFloat(point) || 0),
    };
    if (field === 'bhori') setBhori(val);
    if (field === 'ana') setAna(val);
    if (field === 'roti') setRoti(val);
    if (field === 'point') setPoint(val);

    const calculatedGrams = partsToGrams(newParts);
    setGrams(calculatedGrams.toString());

    // Auto calculate estimated valuation
    const rate = metalType === 'স্বর্ণ' ? rates[karat] || 130000 : silverRates['22K'] || 2100;
    const pts = partsToPoints(newParts);
    const est = Math.round((pts / 960) * rate);
    setEstimatedValue(est);
    setLoanAmount(Math.round(est * 0.7)); // Safe loan 70% of market value
  };

  const handleGramsChange = (val: string) => {
    setGrams(val);
    const g = Math.max(0, parseFloat(val) || 0);
    const p = gramsToParts(g);
    setBhori(p.bhori.toString());
    setAna(p.ana.toString());
    setRoti(p.roti.toString());
    setPoint(p.point.toString());

    const rate = metalType === 'স্বর্ণ' ? rates[karat] || 130000 : silverRates['22K'] || 2100;
    const pts = partsToPoints(p);
    const est = Math.round((pts / 960) * rate);
    setEstimatedValue(est);
    setLoanAmount(Math.round(est * 0.7));
  };

  // Camera
  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false,
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access error:', err);
      showToast('ক্যামেরা চালু করা যায়নি। অনুগ্রহ করে ফাইল আপলোড ব্যবহার করুন।', 'error');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setItemImageUrl(dataUrl);
      stopCamera();
      showToast('অলংকারের ছবি ক্যাপচার সম্পন্ন!');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setItemImageUrl(reader.result as string);
        showToast('অলংকারের ছবি আপলোড সম্পন্ন!');
      };
      reader.readAsDataURL(file);
    }
  };

  const openNewMortgageModal = () => {
    setEditingMortgage(null);
    setMetalType('স্বর্ণ');
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    setNidOrIdNumber('');
    setItemName('');
    setKarat('22K');
    setBhori('0');
    setAna('8');
    setRoti('0');
    setPoint('0');
    const g = partsToGrams({ bhori: 0, ana: 8, roti: 0, point: 0 });
    setGrams(g.toString());
    const est = Math.round((240 / 960) * (rates['22K'] || 130000));
    setEstimatedValue(est);
    setLoanAmount(Math.round(est * 0.7));
    setMonthlyInterestRate(2.5);
    setDurationMonths(6);
    setNotes('');
    setItemImageUrl('');
    setIsModalOpen(true);
  };

  const handleSaveMortgage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      showToast('দয়া করে গ্রাহকের নাম দিন।', 'error');
      return;
    }
    if (!itemName.trim()) {
      showToast('দয়া করে অলংকারের বিবরণ দিন।', 'error');
      return;
    }
    if (loanAmount <= 0) {
      showToast('দয়া করে প্রদত্ত ঋণের পরিমাণ দিন।', 'error');
      return;
    }

    const weightParts = {
      bhori: Math.max(0, parseFloat(bhori) || 0),
      ana: Math.max(0, parseFloat(ana) || 0),
      roti: Math.max(0, parseFloat(roti) || 0),
      point: Math.max(0, parseFloat(point) || 0),
    };

    const now = new Date();
    const expiryDate = new Date(now.getTime() + (durationMonths || 6) * 30 * 86400000).toISOString().split('T')[0];
    const timeStr = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });

    const newRecord: MortgageRecord = {
      id: editingMortgage ? editingMortgage.id : `mort-${Date.now()}`,
      mortgageNumber: editingMortgage ? editingMortgage.mortgageNumber : `MORT-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${String(Math.floor(1000 + Math.random() * 9000))}`,
      date: editingMortgage ? editingMortgage.date : now.toISOString(),
      time: editingMortgage ? editingMortgage.time : timeStr,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      nidOrIdNumber: nidOrIdNumber.trim() || undefined,
      metalType,
      itemName: itemName.trim(),
      karat,
      grossWeightParts: weightParts,
      grossWeightGrams: Math.max(0, parseFloat(grams) || partsToGrams(weightParts)),
      netWeightParts: weightParts,
      netWeightGrams: Math.max(0, parseFloat(grams) || partsToGrams(weightParts)),
      estimatedItemValue: Number(estimatedValue) || 0,
      loanAmount: Number(loanAmount) || 0,
      monthlyInterestRatePercent: Number(monthlyInterestRate) || 0,
      durationMonths: Number(durationMonths) || 6,
      expiryDate,
      itemImageUrl: itemImageUrl || undefined,
      status: 'চলমান',
      interestPayments: editingMortgage ? editingMortgage.interestPayments : [],
      notes: notes.trim() || undefined,
      createdAt: editingMortgage ? editingMortgage.createdAt : now.toISOString(),
    };

    saveMortgage(newRecord);
    setIsModalOpen(false);
    stopCamera();
    setPrintMortgage(newRecord);
  };

  // Record Interest Payment
  const openInterestModal = (m: MortgageRecord) => {
    setInterestModalMortgage(m);
    // 1 month interest = (loanAmount * rate) / 100
    const oneMonthInterest = Math.round((m.loanAmount * m.monthlyInterestRatePercent) / 100);
    setInterestAmount(oneMonthInterest);
    setInterestMonthsCount(1);
    setInterestNotes('মাসিক সুদ জমা');
  };

  const handleSaveInterestPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!interestModalMortgage) return;
    if (interestAmount <= 0) {
      showToast('সুদের পরিমাণ দিন।', 'error');
      return;
    }

    const now = new Date();
    const payment = {
      id: `int-${Date.now()}`,
      date: now.toISOString(),
      time: now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true }),
      amount: Number(interestAmount),
      monthsCount: Number(interestMonthsCount) || 1,
      paymentMethod: 'নগদ' as PaymentMethod,
      notes: interestNotes.trim() || undefined,
    };

    const updated: MortgageRecord = {
      ...interestModalMortgage,
      interestPayments: [payment, ...(interestModalMortgage.interestPayments || [])],
    };

    saveMortgage(updated);
    setInterestModalMortgage(null);
    showToast(`৳ ${interestAmount} সুদ সফলভাবে জমা নেওয়া হয়েছে।`);
  };

  // Full Redemption (খালাস)
  const openRedeemModal = (m: MortgageRecord) => {
    setRedeemModalMortgage(m);
    setRedeemPrincipalPaid(m.loanAmount);
    setRedeemInterestPaid(0);
  };

  const handleConfirmRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!redeemModalMortgage) return;

    const totalPaid = (Number(redeemPrincipalPaid) || 0) + (Number(redeemInterestPaid) || 0);
    const updated: MortgageRecord = {
      ...redeemModalMortgage,
      status: 'খালাসকৃত',
      redeemedDate: new Date().toISOString(),
      redeemedAmount: totalPaid,
    };

    saveMortgage(updated);
    setRedeemModalMortgage(null);
    showToast(`বন্ধকী অলংকার সফলভাবে খালাস সম্পন্ন করা হয়েছে!`);
  };

  // Filtered List
  const todayTime = Date.now();
  const filteredMortgages = mortgages.filter((m) => {
    const isOverdue = m.status === 'চলমান' && new Date(m.expiryDate).getTime() < todayTime;
    if (activeFilter === 'active' && m.status !== 'চলমান') return false;
    if (activeFilter === 'overdue' && !isOverdue) return false;
    if (activeFilter === 'redeemed' && m.status !== 'খালাসকৃত') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = m.customerName.toLowerCase().includes(q);
      const matchPhone = m.customerPhone.toLowerCase().includes(q);
      const matchNum = m.mortgageNumber.toLowerCase().includes(q);
      const matchItem = m.itemName.toLowerCase().includes(q);
      return matchName || matchPhone || matchNum || matchItem;
    }
    return true;
  });

  // KPI Metrics
  const activeMortgages = mortgages.filter((m) => m.status === 'চলমান');
  const totalLoanOutstanding = activeMortgages.reduce((acc, m) => acc + m.loanAmount, 0);
  const totalGoldWeightGrams = activeMortgages
    .filter((m) => m.metalType === 'স্বর্ণ')
    .reduce((acc, m) => acc + m.netWeightGrams, 0);
  const totalSilverWeightGrams = activeMortgages
    .filter((m) => m.metalType === 'রূপা')
    .reduce((acc, m) => acc + m.netWeightGrams, 0);
  const monthlyExpectedInterest = activeMortgages.reduce(
    (acc, m) => acc + (m.loanAmount * m.monthlyInterestRatePercent) / 100,
    0
  );

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#19150d] via-[#14120c] to-[#0c0b08] p-4 sm:p-6 rounded-2xl border border-amber-600/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs bg-amber-500/20 text-amber-300 font-bold px-2.5 py-0.5 rounded border border-amber-600/30 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              বন্ধকী ঋণ খতিয়ান
            </span>
            <span className="text-xs text-amber-400/80">
              সোনার ও রূপার অলংকার বন্ধক ও মাসিক সুদ ব্যবস্থাপনা
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-amber-100 flex items-center gap-2">
            <span>কাস্টমার বন্ধকী হিসাব সেকশন</span>
          </h2>
          <p className="text-xs text-amber-300/70 mt-0.5">
            কাস্টমারের নিকট থেকে স্বর্ণ বা রূপা বন্ধক রেখে ঋণ প্রদান, ছবি সংরক্ষণ, মাসিক সুদ জমা এবং খালাস হিসাব সংরক্ষণ।
          </p>
        </div>

        <button
          onClick={openNewMortgageModal}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-amber-950/60 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন বন্ধক এন্ট্রি</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-amber-400/80 mb-1">
            <span className="text-xs font-semibold">মোট প্রদত্ত মূল ঋণ</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl sm:text-2xl font-black font-mono text-amber-200">
            {formatTaka(totalLoanOutstanding)}
          </p>
          <p className="text-[11px] text-amber-400/70 mt-2 pt-2 border-t border-amber-950">
            চলমান বন্ধক: {toBengaliNumber(activeMortgages.length)} জন
          </p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-emerald-400/80 mb-1">
            <span className="text-xs font-semibold">মাসিক সম্ভাব্য সুদ আয়</span>
            <BadgePercent className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-xl sm:text-2xl font-black font-mono text-emerald-300">
            {formatTaka(Math.round(monthlyExpectedInterest))}
          </p>
          <p className="text-[11px] text-emerald-400/70 mt-2 pt-2 border-t border-amber-950">
            প্রতি মাসে মোট সুদ পাওনা
          </p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-amber-400/80 mb-1">
            <span className="text-xs font-semibold">দোকানে বন্ধকী স্বর্ণের ওজন</span>
            <Gem className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-lg sm:text-xl font-black font-mono text-amber-200">
            {toBengaliNumber((totalGoldWeightGrams / 11.664).toFixed(2))} ভরি
          </p>
          <p className="text-[11px] text-amber-400/70 mt-2 pt-2 border-t border-amber-950">
            ({toBengaliNumber(totalGoldWeightGrams.toFixed(2))} গ্রাম স্বর্ণ)
          </p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <div className="flex items-center justify-between text-slate-300 mb-1">
            <span className="text-xs font-semibold">বন্ধকী রূপার ওজন</span>
            <Coins className="w-4 h-4 text-slate-300" />
          </div>
          <p className="text-lg sm:text-xl font-black font-mono text-slate-200">
            {toBengaliNumber((totalSilverWeightGrams / 11.664).toFixed(2))} ভরি
          </p>
          <p className="text-[11px] text-slate-400 mt-2 pt-2 border-t border-amber-950">
            ({toBengaliNumber(totalSilverWeightGrams.toFixed(2))} গ্রাম রূপা)
          </p>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="bg-[#12110c] p-3.5 rounded-xl border border-amber-900/40 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto scrollbar-none pb-1 sm:pb-0 text-xs">
          {[
            { id: 'all', label: 'সকল রেকর্ড', count: mortgages.length },
            { id: 'active', label: 'চলমান বন্ধক (Active)', count: activeMortgages.length },
            {
              id: 'overdue',
              label: 'মেয়াদোত্তীর্ণ',
              count: mortgages.filter((m) => m.status === 'চলমান' && new Date(m.expiryDate).getTime() < todayTime).length,
            },
            {
              id: 'redeemed',
              label: 'খালাসকৃত (Redeemed)',
              count: mortgages.filter((m) => m.status === 'খালাসকৃত').length,
            },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                activeFilter === tab.id
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                  : 'text-amber-200/60 hover:text-amber-100 hover:bg-amber-950/40'
              }`}
            >
              <span>{tab.label}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/40 border border-amber-700/40 font-mono">
                {toBengaliNumber(tab.count)}
              </span>
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-amber-400/60" />
          <input
            type="text"
            placeholder="বন্ধক নং, নাম বা ফোন নম্বর দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#0b0a08] border border-amber-700/40 rounded-lg pl-9 pr-3 py-1.5 text-xs text-amber-100 placeholder-amber-400/40 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Mortgages List / Cards */}
      {filteredMortgages.length === 0 ? (
        <div className="bg-[#12110c] rounded-2xl border border-amber-900/40 p-12 text-center space-y-4">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-amber-200">বর্তমানে কোনো বন্ধকী রেকর্ড নেই</h3>
          <p className="text-xs text-amber-400/60 max-w-md mx-auto">
            কাস্টমার অলংকার বন্ধক রেখে টাকা নিলে "নতুন বন্ধক এন্ট্রি" বাটনে ক্লিক করে হিসাব যুক্ত করুন।
          </p>
          <button
            onClick={openNewMortgageModal}
            className="px-4 py-2 rounded-xl bg-amber-500 text-black font-bold text-xs"
          >
            + নতুন বন্ধক যুক্ত করুন
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMortgages.map((m) => {
            const isGold = m.metalType === 'স্বর্ণ';
            const isOverdue = m.status === 'চলমান' && new Date(m.expiryDate).getTime() < todayTime;
            const totalInterestCollected = (m.interestPayments || []).reduce((acc, p) => acc + p.amount, 0);

            return (
              <div
                key={m.id}
                className="bg-[#12110c] rounded-2xl border border-amber-900/40 hover:border-amber-500/50 p-4 transition-all shadow-lg flex flex-col justify-between space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2 border-b border-amber-950 pb-2.5">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          isGold
                            ? 'bg-amber-950/80 text-amber-300 border-amber-600/50'
                            : 'bg-slate-800 text-slate-200 border-slate-600'
                        }`}
                      >
                        {isGold ? 'স্বর্ণ' : 'রূপা'} ({m.karat})
                      </span>
                      <span className="font-mono text-xs font-bold text-amber-400">
                        #{m.mortgageNumber}
                      </span>
                    </div>
                    <h4 className="font-bold text-sm text-amber-100 mt-1">
                      {m.itemName}
                    </h4>
                  </div>

                  {/* Status Badge */}
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      m.status === 'খালাসকৃত'
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-600/50'
                        : isOverdue
                        ? 'bg-red-950 text-red-300 border-red-600/50 animate-pulse'
                        : 'bg-amber-950 text-amber-300 border-amber-600/50'
                    }`}
                  >
                    {m.status === 'খালাসকৃত' ? 'খালাসকৃত' : isOverdue ? 'মেয়াদোত্তীর্ণ' : 'চলমান'}
                  </span>
                </div>

                {/* Picture & Customer Details */}
                <div className="flex items-center gap-3">
                  {m.itemImageUrl ? (
                    <img
                      src={m.itemImageUrl}
                      alt={m.itemName}
                      className="w-16 h-16 rounded-xl object-cover border border-amber-700/50 shadow shrink-0"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-amber-950/30 border border-amber-900/40 flex flex-col items-center justify-center text-amber-500/40 shrink-0">
                      <ShieldCheck className="w-6 h-6" />
                      <span className="text-[9px] mt-0.5">ছবি নেই</span>
                    </div>
                  )}

                  <div className="space-y-0.5 text-xs text-amber-200/80 flex-1">
                    <p className="font-semibold text-amber-100 flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-amber-400" />
                      <span>{m.customerName}</span>
                    </p>
                    {m.customerPhone && (
                      <p className="text-[11px] text-amber-300/70 font-mono flex items-center gap-1">
                        <Phone className="w-3 h-3 text-amber-400" />
                        <span>{m.customerPhone}</span>
                      </p>
                    )}
                    <p className="text-[11px] text-amber-400/60 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-amber-400" />
                      <span>তারিখ: {new Date(m.date).toLocaleDateString('bn-BD')}</span>
                    </p>
                    <p className="text-[10px] text-red-400/80 font-mono">
                      মেয়াদ: {new Date(m.expiryDate).toLocaleDateString('bn-BD')} ({toBengaliNumber(m.durationMonths)} মাস)
                    </p>
                  </div>
                </div>

                {/* Loan & Weight Breakdown */}
                <div className="bg-[#0b0a08] rounded-xl p-2.5 border border-amber-950 text-xs space-y-1">
                  <div className="flex items-center justify-between text-amber-300/80">
                    <span>ওজন:</span>
                    <span className="font-bold text-amber-200 font-mono">
                      {formatWeightPartsBn(m.netWeightParts)} ({toBengaliNumber(m.netWeightGrams)}g)
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-amber-300/80">
                    <span>প্রদত্ত ঋণ (আসল):</span>
                    <span className="font-bold text-amber-400 font-mono text-sm">{formatTaka(m.loanAmount)}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-amber-400/70">
                    <span>মাসিক সুদ ({toBengaliNumber(m.monthlyInterestRatePercent)}%):</span>
                    <span className="font-mono">
                      {formatTaka(Math.round((m.loanAmount * m.monthlyInterestRatePercent) / 100))}/মাস
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-amber-950/60 text-emerald-400">
                    <span>মোট সংগৃহীত সুদ:</span>
                    <span className="font-mono font-bold">{formatTaka(totalInterestCollected)}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between gap-1.5 pt-1">
                  {m.status === 'চলমান' ? (
                    <>
                      <button
                        onClick={() => openInterestModal(m)}
                        className="flex-1 py-1.5 rounded-lg bg-emerald-950/70 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-600/40 text-xs font-semibold flex items-center justify-center gap-1"
                      >
                        <BadgePercent className="w-3.5 h-3.5" />
                        <span>সুদ গ্রহণ</span>
                      </button>

                      <button
                        onClick={() => openRedeemModal(m)}
                        className="flex-1 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold flex items-center justify-center gap-1 shadow"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>খালাস</span>
                      </button>
                    </>
                  ) : (
                    <div className="flex-1 py-1 text-center text-xs font-bold text-emerald-400 bg-emerald-950/40 rounded-lg border border-emerald-800/40">
                      খালাস সম্পন্ন: {m.redeemedDate ? new Date(m.redeemedDate).toLocaleDateString('bn-BD') : ''}
                    </div>
                  )}

                  <button
                    onClick={() => setPrintMortgage(m)}
                    title="রসিদ প্রিন্ট করুন"
                    className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-amber-700/40 text-xs"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm('আপনি কি নিশ্চিতভাবে এই বন্ধকী রেকর্ড মুছে ফেলতে চান?')) {
                        deleteMortgage(m.id);
                      }
                    }}
                    title="মুছুন"
                    className="p-1.5 rounded-lg bg-red-950/30 hover:bg-red-900/40 text-red-400 border border-red-800/40 text-xs"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New Mortgage Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-4 sm:p-6 max-w-2xl w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-amber-900/40 pb-3">
              <h3 className="font-bold text-base sm:text-lg text-amber-200 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                নতুন বন্ধকী এন্ট্রি (অলংকার জমা ও ঋণ প্রদান)
              </h3>
              <button
                onClick={() => {
                  stopCamera();
                  setIsModalOpen(false);
                }}
                className="p-1 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMortgage} className="space-y-4 text-xs">
              {/* Metal Selection */}
              <div className="space-y-1.5">
                <label className="font-bold text-amber-300">বন্ধকী অলংকারের ধাতু নির্বাচন করুন *</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMetalType('স্বর্ণ')}
                    className={`py-2 rounded-xl border font-bold flex items-center justify-center gap-2 transition-all ${
                      metalType === 'স্বর্ণ'
                        ? 'bg-amber-500 text-black border-amber-400 shadow font-extrabold'
                        : 'bg-neutral-900 text-amber-200/70 border-amber-800/40'
                    }`}
                  >
                    <Gem className="w-4 h-4" />
                    <span>স্বর্ণালংকার বন্ধক</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMetalType('রূপা')}
                    className={`py-2 rounded-xl border font-bold flex items-center justify-center gap-2 transition-all ${
                      metalType === 'রূপা'
                        ? 'bg-slate-200 text-slate-950 border-white shadow font-extrabold'
                        : 'bg-neutral-900 text-slate-300/70 border-slate-700'
                    }`}
                  >
                    <Coins className="w-4 h-4" />
                    <span>রূপার অলংকার বন্ধক</span>
                  </button>
                </div>
              </div>

              {/* Customer Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5 bg-[#0d0c09] p-3 rounded-xl border border-amber-900/40">
                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">গ্রাহকের নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="নাম লিখুন"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">মোবাইল নম্বর *</label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">ঠিকানা</label>
                  <input
                    type="text"
                    placeholder="গ্রাম/শহর"
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">এনআইডি / আইডি</label>
                  <input
                    type="text"
                    placeholder="জাতীয় পরিচয়পত্র নং"
                    value={nidOrIdNumber}
                    onChange={(e) => setNidOrIdNumber(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Jewelry Item Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-semibold text-amber-300">অলংকারের বিবরণ *</label>
                  <input
                    type="text"
                    required
                    placeholder={metalType === 'স্বর্ণ' ? 'উদাঃ ২১ ক্যারেট চেইন ও আংটি' : 'উদাঃ রূপার ভারী পায়েল ও ব্রেসলেট'}
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">ক্যারেট</label>
                  <select
                    value={karat}
                    onChange={(e) => setKarat(e.target.value as KaratType)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400 font-semibold"
                  >
                    <option value="22K">২২ ক্যারেট</option>
                    <option value="21K">২১ ক্যারেট</option>
                    <option value="18K">১৮ ক্যারেট</option>
                    <option value="সনাতন">সনাতন</option>
                    <option value="24K">২৪ ক্যারেট</option>
                  </select>
                </div>
              </div>

              {/* Weight Parts */}
              <div className="bg-[#0e0c08] p-3 rounded-xl border border-amber-800/40 space-y-2">
                <label className="font-bold text-amber-300">অলংকারের সঠিক ওজন (খাঁটি)</label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  <div>
                    <label className="text-[11px] text-amber-400/80">ভরি</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={bhori}
                      onChange={(e) => handlePartChange('bhori', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-amber-400/80">আনা</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      max="15.99"
                      value={ana}
                      onChange={(e) => handlePartChange('ana', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-amber-400/80">রতি</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      max="5.99"
                      value={roti}
                      onChange={(e) => handlePartChange('roti', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-amber-400/80">পয়েন্ট</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      max="9.99"
                      value={point}
                      onChange={(e) => handlePartChange('point', e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-2.5 py-1.5 text-amber-100 font-mono focus:border-amber-400"
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="text-[11px] text-emerald-400 font-semibold">গ্রাম</label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={grams}
                      onChange={(e) => handleGramsChange(e.target.value)}
                      className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono font-bold focus:border-emerald-400"
                    />
                  </div>
                </div>
              </div>

              {/* Loan Details & Interest */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">আনুমানিক বাজারমূল্য (৳)</label>
                  <input
                    type="number"
                    value={estimatedValue}
                    onChange={(e) => setEstimatedValue(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-emerald-400">প্রদত্ত ঋণ (টাকা) *</label>
                  <input
                    type="number"
                    required
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-3 py-1.5 text-emerald-300 font-mono font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">মাসিক সুদ (%) *</label>
                  <input
                    type="number"
                    step="0.1"
                    value={monthlyInterestRate}
                    onChange={(e) => setMonthlyInterestRate(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-amber-300">মেয়াদ (মাস) *</label>
                  <input
                    type="number"
                    min="1"
                    max="36"
                    value={durationMonths}
                    onChange={(e) => setDurationMonths(parseInt(e.target.value) || 6)}
                    className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono"
                  />
                </div>
              </div>

              {/* Camera Photo for Mortgaged Item */}
              <div className="bg-[#0d0c09] p-3 rounded-xl border border-amber-900/40 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-amber-300 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-amber-400" />
                    <span>বন্ধকী অলংকারের ছবি (প্রমাণ ও নিরাপত্তার জন্য)</span>
                  </label>
                  {itemImageUrl && (
                    <button
                      type="button"
                      onClick={() => setItemImageUrl('')}
                      className="text-red-400 hover:text-red-300 text-[11px] flex items-center gap-1"
                    >
                      <X className="w-3.5 h-3.5" /> ছবি সরান
                    </button>
                  )}
                </div>

                {isCameraActive ? (
                  <div className="space-y-2">
                    <div className="relative rounded-xl overflow-hidden bg-black aspect-video max-h-52 mx-auto border border-amber-600/50">
                      <video ref={videoRef} autoPlay playsInline className="w-full h-full object-contain" />
                    </div>
                    <div className="flex justify-center gap-2">
                      <button
                        type="button"
                        onClick={capturePhoto}
                        className="px-4 py-1.5 rounded-lg bg-emerald-500 text-black font-bold text-xs flex items-center gap-1"
                      >
                        <Camera className="w-3.5 h-3.5" /> ছবি তুলুন
                      </button>
                      <button
                        type="button"
                        onClick={stopCamera}
                        className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                      >
                        বাতিল
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-3">
                    {itemImageUrl ? (
                      <img
                        src={itemImageUrl}
                        alt="Mortgage Item Preview"
                        className="w-16 h-16 rounded-xl object-cover border border-amber-600"
                      />
                    ) : null}

                    <button
                      type="button"
                      onClick={startCamera}
                      className="px-3 py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-amber-700/50 flex items-center gap-1.5 font-medium"
                    >
                      <Camera className="w-4 h-4 text-amber-400" />
                      <span>ক্যামেরা দিয়ে ছবি তুলুন</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-amber-700/50 flex items-center gap-1.5 font-medium"
                    >
                      <Upload className="w-4 h-4 text-amber-400" />
                      <span>ফাইল আপলোড</span>
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </div>
                )}
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="font-semibold text-amber-300">লকার / বক্স নম্বর ও বিশেষ মন্তব্য</label>
                <input
                  type="text"
                  placeholder="উদাঃ লকার নং বি-১২, লাল ভেলভেট বক্সে রক্ষিত"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Calculation Preview */}
              <div className="bg-amber-950/40 p-3 rounded-xl border border-amber-700/40 flex justify-between items-center text-xs">
                <div>
                  <span className="text-amber-300">ঋণ প্রদান: </span>
                  <span className="font-bold text-amber-100 font-mono">{formatTaka(loanAmount)}</span>
                </div>
                <div>
                  <span className="text-amber-300">মাসিক সুদ: </span>
                  <span className="font-bold text-emerald-400 font-mono">
                    {formatTaka(Math.round((loanAmount * monthlyInterestRate) / 100))}/মাস
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setIsModalOpen(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 hover:bg-neutral-700 font-semibold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold hover:from-amber-400 hover:to-amber-500 shadow-lg"
                >
                  সংরক্ষণ ও স্লিপ প্রিন্ট
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Interest Payment Modal */}
      {interestModalMortgage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-5 max-w-md w-full shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-amber-900/40 pb-2">
              <h3 className="font-bold text-base text-amber-200 flex items-center gap-2">
                <BadgePercent className="w-4 h-4 text-emerald-400" />
                সুদ গ্রহণ - #{interestModalMortgage.mortgageNumber}
              </h3>
              <button onClick={() => setInterestModalMortgage(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-neutral-900/80 p-3 rounded-xl border border-amber-900/40 space-y-1">
              <p><strong>গ্রাহক:</strong> {interestModalMortgage.customerName} ({interestModalMortgage.customerPhone})</p>
              <p><strong>অলংকার:</strong> {interestModalMortgage.itemName}</p>
              <p><strong>মূল ঋণ:</strong> {formatTaka(interestModalMortgage.loanAmount)}</p>
              <p><strong>মাসিক সুদের হার:</strong> {toBengaliNumber(interestModalMortgage.monthlyInterestRatePercent)}%</p>
            </div>

            <form onSubmit={handleSaveInterestPayment} className="space-y-3">
              <div className="space-y-1">
                <label className="font-semibold text-amber-300">কয় মাসের সুদ?</label>
                <input
                  type="number"
                  min="1"
                  max="24"
                  value={interestMonthsCount}
                  onChange={(e) => {
                    const m = parseInt(e.target.value) || 1;
                    setInterestMonthsCount(m);
                    const oneM = Math.round((interestModalMortgage.loanAmount * interestModalMortgage.monthlyInterestRatePercent) / 100);
                    setInterestAmount(oneM * m);
                  }}
                  className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-emerald-400">গৃহীত সুদের পরিমাণ (টাকা) *</label>
                <input
                  type="number"
                  required
                  value={interestAmount}
                  onChange={(e) => setInterestAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-3 py-1.5 text-emerald-300 font-mono font-bold text-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-amber-300">মন্তব্য</label>
                <input
                  type="text"
                  value={interestNotes}
                  onChange={(e) => setInterestNotes(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => setInterestModalMortgage(null)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-black font-bold shadow"
                >
                  সুদ জমা সংরক্ষণ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Redeem Item Modal */}
      {redeemModalMortgage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-5 max-w-md w-full shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-amber-900/40 pb-2">
              <h3 className="font-bold text-base text-amber-200 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                অলংকার খালাস সম্পন্ন করুন
              </h3>
              <button onClick={() => setRedeemModalMortgage(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-neutral-300">
              কাস্টমার মূল ঋণ ও যাবতীয় বকেয়া পরিশোধ করে অলংকার বুঝে নিয়েছেন। খালাস সম্পন্ন করলে এই রেকর্ডটি 'খালাসকৃত' হিসেবে সংরক্ষিত হবে।
            </p>

            <form onSubmit={handleConfirmRedeem} className="space-y-3">
              <div className="space-y-1">
                <label className="font-semibold text-amber-300">মূল ঋণ পরিশোধ (আসল):</label>
                <input
                  type="number"
                  value={redeemPrincipalPaid}
                  onChange={(e) => setRedeemPrincipalPaid(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-amber-300">বকেয়া সুদ বাবদ গ্রহণ:</label>
                <input
                  type="number"
                  value={redeemInterestPaid}
                  onChange={(e) => setRedeemInterestPaid(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-900 border border-amber-700/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono"
                />
              </div>

              <div className="p-3 bg-emerald-950/40 border border-emerald-600/40 rounded-xl font-bold text-emerald-300 flex justify-between">
                <span>সর্বমোট আদায়:</span>
                <span className="font-mono text-sm">
                  {formatTaka((Number(redeemPrincipalPaid) || 0) + (Number(redeemInterestPaid) || 0))}
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => setRedeemModalMortgage(null)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold shadow"
                >
                  খালাস নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Print Mortgage Slip Modal */}
      {printMortgage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-4 sm:p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-900/40 pb-2 no-print">
              <h3 className="font-bold text-amber-200 flex items-center gap-2 text-sm">
                <Printer className="w-4 h-4 text-amber-400" />
                বন্ধকী রসিদ স্লিপ প্রিভিউ
              </h3>
              <button onClick={() => setPrintMortgage(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable White Paper Slip */}
            <div
              id="mortgage-slip-printable"
              className="bg-white text-black p-5 rounded-xl border border-neutral-300 shadow-inner font-['Hind_Siliguri',sans-serif] space-y-3"
            >
              {/* Header */}
              <div className="text-center border-b border-dashed border-neutral-400 pb-2">
                <h2 className="text-lg font-black tracking-tight text-neutral-900">
                  {shopProfile.name}
                </h2>
                <p className="text-[11px] text-neutral-700">{shopProfile.slogan}</p>
                <p className="text-[10px] text-neutral-600">{shopProfile.address}</p>
                <p className="text-[10px] text-neutral-700 font-bold">ফোন: {shopProfile.phone}</p>
                <div className="mt-1 inline-block bg-neutral-900 text-white text-[10px] font-bold px-3 py-0.5 rounded-full">
                  বন্ধকী চুক্তি ও রসিদ পত্র
                </div>
              </div>

              {/* Record Meta */}
              <div className="flex justify-between items-center text-[11px] border-b border-neutral-200 pb-1.5">
                <div>
                  <p><strong>বন্ধক নং:</strong> {printMortgage.mortgageNumber}</p>
                  <p><strong>তারিখ:</strong> {new Date(printMortgage.date).toLocaleDateString('bn-BD')}</p>
                  <p><strong>সময়:</strong> {printMortgage.time || new Date().toLocaleTimeString('bn-BD')}</p>
                </div>
                <div className="text-right">
                  <p><strong>মেয়াদ শেষ:</strong> {new Date(printMortgage.expiryDate).toLocaleDateString('bn-BD')}</p>
                  <p><strong>ধাতু:</strong> {printMortgage.metalType} ({printMortgage.karat})</p>
                  <p><strong>মাসিক সুদ:</strong> {toBengaliNumber(printMortgage.monthlyInterestRatePercent)}%</p>
                </div>
              </div>

              {/* Customer Info */}
              <div className="bg-neutral-50 p-2 rounded border border-neutral-200 text-[11px]">
                <p><strong>গ্রাহকের নাম:</strong> {printMortgage.customerName}</p>
                {printMortgage.customerPhone && <p><strong>মোবাইল:</strong> {printMortgage.customerPhone}</p>}
                {printMortgage.customerAddress && <p><strong>ঠিকানা:</strong> {printMortgage.customerAddress}</p>}
                {printMortgage.nidOrIdNumber && <p><strong>এনআইডি / আইডি:</strong> {printMortgage.nidOrIdNumber}</p>}
              </div>

              {/* Pledged Item Details */}
              <table className="w-full text-[11px] border-collapse border border-neutral-300">
                <thead>
                  <tr className="bg-neutral-100 text-neutral-800">
                    <th className="border border-neutral-300 p-1 text-left">অলংকারের বিবরণ</th>
                    <th className="border border-neutral-300 p-1 text-center">খাঁটি ওজন</th>
                    <th className="border border-neutral-300 p-1 text-right">ঋণের পরিমাণ</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-neutral-300 p-1.5 font-semibold">
                      {printMortgage.itemName}
                      {printMortgage.notes && (
                        <p className="text-[10px] text-neutral-500 italic mt-0.5">নোট: {printMortgage.notes}</p>
                      )}
                    </td>
                    <td className="border border-neutral-300 p-1.5 text-center font-mono">
                      {formatWeightPartsBn(printMortgage.netWeightParts)}
                      <br />
                      <span className="text-[10px] text-neutral-500">({toBengaliNumber(printMortgage.netWeightGrams)} গ্রাম)</span>
                    </td>
                    <td className="border border-neutral-300 p-1.5 text-right font-bold font-mono">
                      {formatTaka(printMortgage.loanAmount)}
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Terms */}
              <div className="text-[9px] text-neutral-600 border-t border-dashed border-neutral-400 pt-2 space-y-1">
                <p>১. প্রতি মাসে নিয়মিত ধার্যকৃত সুদ পরিশোধ করিতে হইবে।</p>
                <p>২. মেয়াদ উত্তীর্ণের পূর্বে আসল ও যাবতীয় সুদ পরিশোধ করিয়া অলংকার খালাস করিতে হইবে।</p>
                <p>৩. অলংকার খালাস করিবার সময় মূল রসিদ প্রদর্শন বাধ্যতামূলক।</p>

                <div className="flex justify-between items-end pt-5 text-[10px] text-neutral-800">
                  <div className="border-t border-neutral-500 pt-0.5 text-center w-28">
                    ঋণগ্রহীতার স্বাক্ষর
                  </div>
                  <div className="border-t border-neutral-500 pt-0.5 text-center w-36 font-semibold">
                    মেসার্স মিঠুন অলংকার হাউজ
                  </div>
                </div>
              </div>
            </div>

            {/* Print Controls */}
            <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40 no-print">
              <button
                onClick={() => setPrintMortgage(null)}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
              >
                বন্ধ করুন
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs flex items-center gap-1.5 shadow"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>প্রিন্ট করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
