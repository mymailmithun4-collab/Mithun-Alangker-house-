/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { DataService } from '../services/dataService';
import {
  Database,
  Download,
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  ShieldAlert
} from 'lucide-react';

export const BackupExportView: React.FC = () => {
  const { showToast, refreshData } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Download JSON Backup
  const handleDownloadJsonBackup = () => {
    const jsonStr = DataService.exportCompleteBackupJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    link.href = url;
    link.download = `mithun_jewelry_pos_backup_${dateStr}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('সম্পূর্ণ ডাটাবেসের JSON ব্যাকআপ সফলভাবে ডাউনলোড হয়েছে।');
  };

  // Download CSV
  const handleDownloadCsv = (type: 'sales' | 'products' | 'customers' | 'orders' | 'mortgages') => {
    const csvStr = DataService.exportCsv(type);
    const blob = new Blob(['\uFEFF' + csvStr], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    link.href = url;
    link.download = `mithun_jewelry_${type}_${dateStr}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    showToast(`${type} এর CSV ফাইল এক্সপোর্ট সম্পন্ন হয়েছে।`);
  };

  // File Upload / Restore
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const ok = DataService.restoreFromBackupJson(content);
        if (ok) {
          refreshData();
          showToast('ডাটাবেস ব্যাকআপ থেকে সফলভাবে রিস্টোর করা হয়েছে!');
          setImportStatus('সফলভাবে ডাটা প্রতিস্থাপন সম্পন্ন হয়েছে।');
        } else {
          showToast('ব্যাকআপ ফাইলটি সঠিক নয়।', 'error');
          setImportStatus('ত্রুটি: ফাইলের ফরম্যাট অবৈধ।');
        }
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="border-b border-amber-800/30 pb-4">
        <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
          <Database className="w-6 h-6 text-amber-400" />
          ডাটা ব্যাকআপ ও এক্সপোর্ট (Data Backup & Export)
        </h2>
        <p className="text-xs text-amber-400/70">
          দোকানের সকল বিক্রয়, মজুদ ও গ্রাহক খাতার হিসাব নিরাপদ রাখতে নিয়মিত ব্যাকআপ ডাউনলোড করে রাখুন
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Full JSON Backup & Restore Card */}
        <div className="bg-[#12110c] p-6 rounded-2xl border border-amber-600/40 space-y-4 shadow-xl">
          <div className="flex items-center gap-3 border-b border-amber-900/40 pb-3">
            <div className="p-2 rounded-xl bg-amber-950/90 text-amber-400 border border-amber-700/40">
              <FileCode className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-200">সম্পূর্ণ সিস্টেম ব্যাকআপ (JSON)</h3>
              <p className="text-[11px] text-amber-400/70">এক ক্লিকে সমস্ত তথ্য সংরক্ষণ ও পুনরুদ্ধার</p>
            </div>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed">
            এই ব্যাকআপ ফাইলে গহনার স্টক, বিক্রির সকল ক্যাশ মেমো, গ্রাহকদের বকেয়া খাতা, স্বর্ণের রেট ও প্রোফাইলের সমস্ত ডাটা সংরক্ষিত থাকে।
          </p>

          <div className="pt-2 space-y-3">
            <button
              onClick={handleDownloadJsonBackup}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg active:scale-95"
            >
              <Download className="w-4 h-4" />
              JSON ব্যাকআপ ফাইল ডাউনলোড করুন
            </button>

            <div className="relative pt-2">
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
                id="restore-file-input"
              />
              <label
                htmlFor="restore-file-input"
                className="w-full py-2.5 px-4 rounded-xl bg-neutral-900 border border-amber-700/50 hover:bg-neutral-800 text-amber-300 font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4 text-amber-400" />
                পূর্বের ব্যাকআপ থেকে রিস্টোর (Restore) করুন
              </label>
            </div>

            {importStatus && (
              <p className="text-xs text-emerald-400 text-center font-medium bg-emerald-950/60 p-2 rounded border border-emerald-800/40">
                {importStatus}
              </p>
            )}
          </div>
        </div>

        {/* CSV Export Card */}
        <div className="bg-[#12110c] p-6 rounded-2xl border border-amber-600/40 space-y-4 shadow-xl">
          <div className="flex items-center gap-3 border-b border-amber-900/40 pb-3">
            <div className="p-2 rounded-xl bg-emerald-950/90 text-emerald-400 border border-emerald-700/40">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-200">এক্সেল / CSV এক্সপোর্ট</h3>
              <p className="text-[11px] text-amber-400/70">Microsoft Excel বা Google Sheets এ খোলার জন্য</p>
            </div>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed">
            হিসাব নিরীক্ষা ও প্রিন্ট করার জন্য এক্সেল স্প্রেডশীট ফরম্যাটে তালিকা আলাদা আলাদাভাবে ডাউনলোড করুন।
          </p>

          <div className="space-y-2.5 pt-2">
            <button
              onClick={() => handleDownloadCsv('sales')}
              className="w-full py-2.5 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-amber-800/50 text-amber-200 text-xs font-semibold flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                সকল বিক্রয় মেমো তালিকা (Sales CSV)
              </span>
              <Download className="w-4 h-4 text-neutral-400" />
            </button>

            <button
              onClick={() => handleDownloadCsv('products')}
              className="w-full py-2.5 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-amber-800/50 text-amber-200 text-xs font-semibold flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                গহনা পণ্য ও স্টক তালিকা (Stock CSV)
              </span>
              <Download className="w-4 h-4 text-neutral-400" />
            </button>

            <button
              onClick={() => handleDownloadCsv('customers')}
              className="w-full py-2.5 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-amber-800/50 text-amber-200 text-xs font-semibold flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                গ্রাহক ও বকেয়ার তালিকা (Customers CSV)
              </span>
              <Download className="w-4 h-4 text-neutral-400" />
            </button>

            <button
              onClick={() => handleDownloadCsv('orders')}
              className="w-full py-2.5 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-amber-800/50 text-amber-200 text-xs font-semibold flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                স্বর্ণ ও রূপার কাস্টমার অর্ডার তালিকা (Orders CSV)
              </span>
              <Download className="w-4 h-4 text-neutral-400" />
            </button>

            <button
              onClick={() => handleDownloadCsv('mortgages')}
              className="w-full py-2.5 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-amber-800/50 text-amber-200 text-xs font-semibold flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                কাস্টমার বন্ধকী ঋণ খতিয়ান (Mortgages CSV)
              </span>
              <Download className="w-4 h-4 text-neutral-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
