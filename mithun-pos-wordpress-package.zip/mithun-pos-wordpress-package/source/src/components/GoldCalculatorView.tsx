/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  KaratType,
  GoldWeightParts,
  partsToPoints,
  pointsToParts,
  partsToGrams,
  gramsToParts,
  calculateGoldPrice,
  formatTaka,
  toBengaliNumber,
  formatWeightPartsBn,
  KARAT_INFO
} from '../utils/goldCalculator';
import {
  Calculator,
  RefreshCw,
  ArrowRightCircle,
  Gem,
  Coins,
  Scale,
  Sparkles,
  Info
} from 'lucide-react';

export const GoldCalculatorView: React.FC = () => {
  const { rates, transferCalculatorItemToPos } = useApp();

  const [karat, setKarat] = useState<KaratType>('22K');
  const [ratePerBhori, setRatePerBhori] = useState<number>(rates['22K'] || 130000);

  // Input states
  const [bhori, setBhori] = useState<string>('1');
  const [ana, setAna] = useState<string>('0');
  const [roti, setRoti] = useState<string>('0');
  const [point, setPoint] = useState<string>('0');
  const [grams, setGrams] = useState<string>('11.664');

  // Making & extras
  const [makingCharge, setMakingCharge] = useState<string>('3500');
  const [stonePrice, setStonePrice] = useState<string>('0');
  const [discount, setDiscount] = useState<string>('0');
  const [vatPercent, setVatPercent] = useState<string>('0');

  // Sync rate when karat changes
  useEffect(() => {
    if (rates[karat]) {
      setRatePerBhori(rates[karat]);
    }
  }, [karat, rates]);

  // Handle weight parts change -> sync grams
  const handlePartsChange = (
    newBhori: string,
    newAna: string,
    newRoti: string,
    newPoint: string
  ) => {
    setBhori(newBhori);
    setAna(newAna);
    setRoti(newRoti);
    setPoint(newPoint);

    const parts: GoldWeightParts = {
      bhori: parseFloat(newBhori) || 0,
      ana: parseFloat(newAna) || 0,
      roti: parseFloat(newRoti) || 0,
      point: parseFloat(newPoint) || 0,
    };
    const calculatedGrams = partsToGrams(parts);
    setGrams(calculatedGrams.toString());
  };

  // Handle grams change -> sync weight parts
  const handleGramsChange = (newGrams: string) => {
    setGrams(newGrams);
    const gVal = parseFloat(newGrams) || 0;
    const parts = gramsToParts(gVal);
    setBhori(parts.bhori.toString());
    setAna(parts.ana.toString());
    setRoti(parts.roti.toString());
    setPoint(parts.point.toString());
  };

  // Reset inputs
  const handleReset = () => {
    setBhori('1');
    setAna('0');
    setRoti('0');
    setPoint('0');
    setGrams('11.664');
    setMakingCharge('3500');
    setStonePrice('0');
    setDiscount('0');
  };

  const currentParts: GoldWeightParts = {
    bhori: parseFloat(bhori) || 0,
    ana: parseFloat(ana) || 0,
    roti: parseFloat(roti) || 0,
    point: parseFloat(point) || 0,
  };

  const calcResult = calculateGoldPrice({
    weightParts: currentParts,
    ratePerBhori: ratePerBhori,
    makingChargeFixed: parseFloat(makingCharge) || 0,
    stonePrice: parseFloat(stonePrice) || 0,
    discount: parseFloat(discount) || 0,
    vatPercent: parseFloat(vatPercent) || 0,
  });

  const handleSendToInvoice = () => {
    transferCalculatorItemToPos({
      productName: `${karat} কাস্টম স্বর্ণালংকার`,
      productCode: `CST-${karat}-${Date.now().toString().slice(-4)}`,
      karat: karat,
      weightParts: currentParts,
      weightGrams: calcResult.totalGrams,
      ratePerBhori: ratePerBhori,
      goldBasePrice: calcResult.goldBasePrice,
      makingCharge: calcResult.totalMakingCharge,
      stonePrice: calcResult.stonePrice,
      itemTotal: calcResult.grandTotal,
      quantity: 1,
    });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-800/30 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <Scale className="w-6 h-6 text-amber-400" />
            স্বর্ণের ভরি-আনা-রতি ও মূল্য ক্যালকুলেটর
          </h2>
          <p className="text-xs text-amber-400/70">
            ১ ভরি = ১৬ আনা | ১ আনা = ৬ রতি | ১ রতি = ১০ পয়েন্ট | ১ ভরি = ৯৬০ পয়েন্ট = ১১.৬৬৪ গ্রাম
          </p>
        </div>
        <button
          onClick={handleReset}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 border border-amber-700/40 text-amber-300 hover:bg-neutral-800 text-xs"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          পুনরায় সেট করুন
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Weight & Rate Inputs */}
        <div className="lg:col-span-7 space-y-5">
          {/* Karat Selection */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 space-y-3">
            <label className="text-xs font-semibold text-amber-300 block">
              স্বর্ণের ক্যারেট (Karat) নির্বাচন করুন:
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {(Object.keys(KARAT_INFO) as KaratType[]).map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setKarat(k)}
                  className={`py-2 px-3 rounded-lg text-xs font-bold transition-all border ${
                    karat === k
                      ? 'bg-gradient-to-b from-amber-400 to-amber-600 text-black border-amber-300 shadow-md scale-[1.02]'
                      : 'bg-neutral-900/90 text-amber-200/80 border-amber-900/50 hover:bg-amber-950/40'
                  }`}
                >
                  {k}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-amber-400/80 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              {KARAT_INFO[karat].name} ({KARAT_INFO[karat].description})
            </p>
          </div>

          {/* Rate per Bhori */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30">
            <div className="flex items-center justify-between gap-2 mb-2">
              <label htmlFor="gold-rate-input" className="text-xs font-semibold text-amber-300">
                প্রতি ভরি দর (টাকা):
              </label>
              <span className="text-[11px] text-amber-400/70">
                বাজুস দর: ৳{toBengaliNumber((rates[karat] || 0).toLocaleString('en-IN'))}
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-amber-500 font-bold">৳</span>
              <input
                id="gold-rate-input"
                type="number"
                value={ratePerBhori}
                onChange={(e) => setRatePerBhori(parseFloat(e.target.value) || 0)}
                className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-8 pr-4 py-2 text-amber-100 font-mono text-base focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          {/* Traditional Weight System Inputs (Bhori, Ana, Roti, Point) */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-amber-300 flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-amber-400" />
                ঐতিহ্যবাহী স্বর্ণের ওজন (ভরি - আনা - রতি - পয়েন্ট)
              </h3>
              <span className="text-[11px] text-amber-400/80 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40">
                মোট {toBengaliNumber(calcResult.totalPoints)} পয়েন্ট
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label htmlFor="bhori-input" className="block text-xs text-amber-400/80 mb-1">ভরি (Bhori):</label>
                <input
                  id="bhori-input"
                  type="number"
                  min="0"
                  step="1"
                  value={bhori}
                  onChange={(e) => handlePartsChange(e.target.value, ana, roti, point)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-2 text-amber-100 font-mono text-center text-lg focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="ana-input" className="block text-xs text-amber-400/80 mb-1">আনা (Ana &lt; 16):</label>
                <input
                  id="ana-input"
                  type="number"
                  min="0"
                  max="15"
                  step="1"
                  value={ana}
                  onChange={(e) => handlePartsChange(bhori, e.target.value, roti, point)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-2 text-amber-100 font-mono text-center text-lg focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="roti-input" className="block text-xs text-amber-400/80 mb-1">রতি (Roti &lt; 6):</label>
                <input
                  id="roti-input"
                  type="number"
                  min="0"
                  max="5"
                  step="1"
                  value={roti}
                  onChange={(e) => handlePartsChange(bhori, ana, e.target.value, point)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-2 text-amber-100 font-mono text-center text-lg focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="point-input" className="block text-xs text-amber-400/80 mb-1">পয়েন্ট (Point &lt; 10):</label>
                <input
                  id="point-input"
                  type="number"
                  min="0"
                  step="0.1"
                  value={point}
                  onChange={(e) => handlePartsChange(bhori, ana, roti, e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-2 text-amber-100 font-mono text-center text-lg focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            {/* Metric Gram Input (Automatic 2-way sync) */}
            <div className="pt-2 border-t border-amber-900/40">
              <label htmlFor="grams-input" className="block text-xs font-semibold text-amber-300 mb-1">
                অথবা গ্রাম (Grams) হিসেবে ইনপুট দিন:
              </label>
              <div className="relative">
                <input
                  id="grams-input"
                  type="number"
                  step="0.001"
                  value={grams}
                  onChange={(e) => handleGramsChange(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-500/50 rounded-lg px-4 py-2 text-amber-200 font-mono text-base focus:border-amber-400 focus:outline-none"
                />
                <span className="absolute right-3 top-2.5 text-xs text-amber-400/80">গ্রাম (g)</span>
              </div>
            </div>
          </div>

          {/* Making Charge & Extras */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="making-charge-input" className="block text-xs text-amber-400/80 mb-1">মজুরি (Making Charge ৳):</label>
              <input
                id="making-charge-input"
                type="number"
                value={makingCharge}
                onChange={(e) => setMakingCharge(e.target.value)}
                className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono text-sm focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="stone-price-input" className="block text-xs text-amber-400/80 mb-1">পাথর / মুক্তা মূল্য (৳):</label>
              <input
                id="stone-price-input"
                type="number"
                value={stonePrice}
                onChange={(e) => setStonePrice(e.target.value)}
                className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono text-sm focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="discount-input" className="block text-xs text-amber-400/80 mb-1">বিশেষ ছাড় / ডিসকাউন্ট (৳):</label>
              <input
                id="discount-input"
                type="number"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-amber-100 font-mono text-sm focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Complete Price Breakdown Card */}
        <div className="lg:col-span-5 flex flex-col justify-between bg-gradient-to-br from-[#1c1810] via-[#14120c] to-[#0d0c0a] p-5 rounded-2xl border-2 border-amber-500/40 shadow-xl shadow-amber-950/40 space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-amber-600/30 pb-3">
              <div className="flex items-center gap-2">
                <Gem className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base text-amber-200">মূল্য হিসাব বিবরণী</h3>
              </div>
              <span className="text-xs bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded border border-amber-500/30">
                {karat}
              </span>
            </div>

            {/* Weight Summary Banner */}
            <div className="bg-black/60 p-3 rounded-xl border border-amber-700/30 space-y-1">
              <p className="text-xs text-amber-400/70">মোট ওজন (ঐতিহ্যবাহী পরিমাপ):</p>
              <p className="text-sm font-bold text-amber-200">
                {formatWeightPartsBn(currentParts)}
              </p>
              <div className="flex justify-between text-xs text-amber-400/80 pt-1 border-t border-amber-900/40">
                <span>মেট্রিক ওজন: <strong>{toBengaliNumber(calcResult.totalGrams)} গ্রাম</strong></span>
                <span>ভরি ভগ্নাংশ: <strong>{toBengaliNumber(calcResult.totalBhori.toFixed(4))} ভরি</strong></span>
              </div>
            </div>

            {/* Line Items */}
            <div className="space-y-2 text-xs sm:text-sm">
              <div className="flex justify-between text-amber-300/80">
                <span>স্বর্ণের মূল দাম ({toBengaliNumber(calcResult.totalBhori.toFixed(3))} ভরি × ৳{toBengaliNumber(ratePerBhori.toLocaleString('en-IN'))}):</span>
                <span className="font-mono font-semibold text-amber-200">{formatTaka(calcResult.goldBasePrice)}</span>
              </div>

              <div className="flex justify-between text-amber-300/80">
                <span>কারিগর মজুরি:</span>
                <span className="font-mono font-semibold text-amber-200">{formatTaka(calcResult.totalMakingCharge)}</span>
              </div>

              {calcResult.stonePrice > 0 && (
                <div className="flex justify-between text-amber-300/80">
                  <span>পাথর / রত্ন মূল্য:</span>
                  <span className="font-mono font-semibold text-amber-200">{formatTaka(calcResult.stonePrice)}</span>
                </div>
              )}

              <div className="flex justify-between text-amber-400 font-semibold pt-1 border-t border-amber-900/40">
                <span>উপমোট (Subtotal):</span>
                <span className="font-mono">{formatTaka(calcResult.subtotal)}</span>
              </div>

              {calcResult.discount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>বিশেষ ছাড় (-):</span>
                  <span className="font-mono">-{formatTaka(calcResult.discount)}</span>
                </div>
              )}

              {calcResult.vatAmount > 0 && (
                <div className="flex justify-between text-amber-400/80">
                  <span>ভ্যাট ({vatPercent}%):</span>
                  <span className="font-mono">+{formatTaka(calcResult.vatAmount)}</span>
                </div>
              )}
            </div>

            {/* Grand Total */}
            <div className="bg-gradient-to-r from-amber-950/80 to-amber-900/50 p-4 rounded-xl border border-amber-500/50 shadow-inner">
              <div className="flex items-baseline justify-between">
                <span className="text-sm font-bold text-amber-200">সর্বমোট প্রদেয় মূল্য:</span>
                <span className="text-xl sm:text-2xl font-bold font-mono text-amber-300">
                  {formatTaka(calcResult.grandTotal)}
                </span>
              </div>
            </div>
          </div>

          {/* Action button: Send directly to POS Invoice */}
          <button
            type="button"
            onClick={handleSendToInvoice}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-amber-950/70 transition-transform active:scale-[0.98]"
          >
            <ArrowRightCircle className="w-5 h-5" />
            বিক্রয় ক্যাশ মেমোতে যোগ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
