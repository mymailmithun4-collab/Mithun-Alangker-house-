/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  getActiveFirebaseConfig,
  saveFirebaseConfig,
  clearCustomFirebaseConfig,
  isFirebaseConfigured,
  DEFAULT_FIREBASE_CONFIG,
  FirebaseConfig
} from '../firebase/config';
import {
  Flame,
  X,
  CheckCircle2,
  AlertTriangle,
  Copy,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  KeyRound,
  FileCode
} from 'lucide-react';

interface FirebaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FirebaseConfigModal: React.FC<FirebaseConfigModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { firebaseStatus, showToast } = useApp();
  const currentConfig = getActiveFirebaseConfig();

  const [apiKey, setApiKey] = useState(currentConfig.apiKey || '');
  const [authDomain, setAuthDomain] = useState(currentConfig.authDomain || '');
  const [projectId, setProjectId] = useState(currentConfig.projectId || '');
  const [storageBucket, setStorageBucket] = useState(currentConfig.storageBucket || '');
  const [messagingSenderId, setMessagingSenderId] = useState(currentConfig.messagingSenderId || '');
  const [appId, setAppId] = useState(currentConfig.appId || '');

  const [showJsonPaste, setShowJsonPaste] = useState(false);
  const [rawJson, setRawJson] = useState('');

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const newConfig: FirebaseConfig = {
      apiKey: apiKey.trim(),
      authDomain: authDomain.trim(),
      projectId: projectId.trim(),
      storageBucket: storageBucket.trim(),
      messagingSenderId: messagingSenderId.trim(),
      appId: appId.trim(),
    };
    saveFirebaseConfig(newConfig);
    showToast('ফায়ারবেস কনফিগারেশন সংরক্ষণ করা হয়েছে! পৃষ্ঠা রিফ্রেশ করুন।');
    setTimeout(() => {
      window.location.reload();
    }, 1200);
  };

  const handleParseJson = () => {
    try {
      // Find object inside json if pasted with const firebaseConfig = { ... }
      let clean = rawJson.trim();
      if (clean.includes('{') && clean.includes('}')) {
        clean = clean.substring(clean.indexOf('{'), clean.lastIndexOf('}') + 1);
      }
      // Relaxed JSON parsing for js object literals
      const parsed = new Function(`return ${clean}`)();
      if (parsed.apiKey) setApiKey(parsed.apiKey);
      if (parsed.authDomain) setAuthDomain(parsed.authDomain);
      if (parsed.projectId) setProjectId(parsed.projectId);
      if (parsed.storageBucket) setStorageBucket(parsed.storageBucket);
      if (parsed.messagingSenderId) setMessagingSenderId(parsed.messagingSenderId);
      if (parsed.appId) setAppId(parsed.appId);
      setShowJsonPaste(false);
      showToast('Firebase কনফিগ কোড থেকে ফিল্ডগুলো স্বয়ংক্রিয়ভাবে পূরণ করা হয়েছে!');
    } catch (e) {
      alert('কোড পার্স করা যায়নি। অনুগ্রহ করে ফিল্ডগুলোতে একটি একটি করে মান বসান।');
    }
  };

  const handleResetToDemo = () => {
    clearCustomFirebaseConfig();
    showToast('ডেমো / অফলাইন মোড সক্রিয় করা হয়েছে।');
    setTimeout(() => {
      window.location.reload();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:px-6 bg-[#1a1710] border-b border-amber-800/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-500 animate-pulse" />
            <h3 className="font-bold text-base text-amber-200">
              ফায়ারবেস (Firebase Cloud) সেটআপ ও সংযোগ
            </h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs text-neutral-300">
          {/* Connection Status Banner */}
          <div className={`p-3.5 rounded-xl border flex items-center gap-3 ${
            firebaseStatus === 'connected'
              ? 'bg-emerald-950/60 border-emerald-600/50 text-emerald-300'
              : 'bg-amber-950/60 border-amber-600/40 text-amber-300'
          }`}>
            <span className={`w-3 h-3 rounded-full ${firebaseStatus === 'connected' ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
            <div className="flex-1">
              <p className="font-bold text-sm">
                {firebaseStatus === 'connected'
                  ? 'গুগল ফায়ারবেস ক্লাউড সক্রিয় ও সংযুক্ত!'
                  : 'অফলাইন / ডেমো লোকাল স্টোরেজ মোড সক্রিয়'}
              </p>
              <p className="text-[11px] opacity-90 mt-0.5">
                {firebaseStatus === 'connected'
                  ? 'আপনার সকল সেলস মেমো, স্টক ও গ্রাহক হিসাব ফায়ারবেস ফায়ারস্টোর ক্লাউডে নিরাপদে সেভ হচ্ছে।'
                  : 'আসল ফায়ারবেস প্রোজেক্ট কানেক্ট না করা পর্যন্ত ডাটা আপনার ব্রাউজারের মেমরিতে নিরাপদে থাকবে। নিচে আপনার কী বসিয়ে ক্লাউড চালু করুন।'}
              </p>
            </div>
          </div>

          {/* Bengali Setup Guide Steps */}
          <div className="bg-black/60 p-4 rounded-xl border border-amber-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                ফায়ারবেস চালু করার সহজ বাংলা নিয়ম:
              </h4>
              <a
                href="/firebase_setup.html"
                target="_blank"
                className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-600/40 text-[11px] font-bold inline-flex items-center gap-1"
              >
                <span>🔥 সম্পূর্ণ সেটআপ HTML পেজ</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-neutral-300 text-[11px] leading-relaxed">
              <li>
                <a
                  href="https://console.firebase.google.com/"
                  target="_blank"
                  rel="noreferrer"
                  className="text-amber-400 underline inline-flex items-center gap-0.5"
                >
                  Firebase Console <ExternalLink className="w-2.5 h-2.5" />
                </a>{' '}
                এ গিয়ে একটি বিনামূল্যে প্রোজেক্ট তৈরি করুন।
              </li>
              <li>
                <strong>Build &gt; Authentication</strong> এ গিয়ে <strong>Email/Password</strong> সাইন-ইন পদ্ধতি <strong>Enable</strong> করুন।
              </li>
              <li>
                <strong>Build &gt; Firestore Database</strong> এ গিয়ে ডাটাবেস তৈরি করুন এবং <strong>Rules</strong> ট্যাবে আমাদের সুরক্ষিত <code className="text-amber-300 font-mono">firestore.rules</code> কোড পেস্ট করুন।
              </li>
              <li>
                প্রোজেক্টের <strong>Project Settings (গিয়ার আইকন) &gt; Web ( &lt;/&gt; )</strong> এ গিয়ে প্রাপ্ত <code className="text-amber-300 font-mono">firebaseConfig</code> এর মানগুলো নিচের বক্সে পেস্ট করুন।
              </li>
            </ol>
          </div>

          {/* Quick Paste Code Button */}
          <div className="flex justify-between items-center">
            <span className="font-semibold text-amber-200">আপনার ফায়ারবেস কনফিগ কী (Web Config Keys):</span>
            <button
              type="button"
              onClick={() => setShowJsonPaste(!showJsonPaste)}
              className="text-[11px] text-amber-400 underline hover:text-amber-300"
            >
              {showJsonPaste ? 'সাধারণ ফর্ম দেখুন' : 'সম্পূর্ণ কোড একবারে পেস্ট করুন'}
            </button>
          </div>

          {showJsonPaste ? (
            <div className="space-y-2 bg-neutral-950 p-3 rounded-xl border border-amber-700/40">
              <label className="text-[11px] text-amber-300 block">
                Firebase Console থেকে প্রাপ্ত সম্পূর্ণ firebaseConfig কোডটি এখানে পেস্ট করুন:
              </label>
              <textarea
                rows={4}
                value={rawJson}
                onChange={(e) => setRawJson(e.target.value)}
                placeholder={'const firebaseConfig = {\n  apiKey: "AIzaSy...",\n  authDomain: "...",\n  projectId: "...",\n  ...\n};'}
                className="w-full bg-black border border-amber-900/60 rounded p-2 text-xs font-mono text-amber-100 focus:outline-none"
              />
              <button
                type="button"
                onClick={handleParseJson}
                className="px-3 py-1.5 rounded bg-amber-500 text-black font-bold text-xs"
              >
                স্বয়ংক্রিয়ভাবে ফর্ম ফিল্ডে বসান
              </button>
            </div>
          ) : (
            <form onSubmit={handleSave} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-amber-300/80 mb-1">apiKey *</label>
                  <input
                    type="text"
                    required
                    placeholder="AIzaSy..."
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2.5 py-1.5 text-xs font-mono text-amber-100 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-amber-300/80 mb-1">projectId *</label>
                  <input
                    type="text"
                    required
                    placeholder="mithun-jewelry-pos"
                    value={projectId}
                    onChange={(e) => setProjectId(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2.5 py-1.5 text-xs font-mono text-amber-100 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-amber-300/80 mb-1">authDomain</label>
                  <input
                    type="text"
                    placeholder="mithun-jewelry-pos.firebaseapp.com"
                    value={authDomain}
                    onChange={(e) => setAuthDomain(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2.5 py-1.5 text-xs font-mono text-amber-100 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-amber-300/80 mb-1">appId</label>
                  <input
                    type="text"
                    placeholder="1:1234567890:web:abcdef..."
                    value={appId}
                    onChange={(e) => setAppId(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2.5 py-1.5 text-xs font-mono text-amber-100 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={handleResetToDemo}
                  className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-amber-800/40 text-amber-300 hover:bg-neutral-800 text-xs flex items-center gap-1"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  ডেমো / লোকাল মোডে ফেরত যান
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                  >
                    বন্ধ
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs shadow"
                  >
                    সংরক্ষণ ও সংযোগ করুন
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
