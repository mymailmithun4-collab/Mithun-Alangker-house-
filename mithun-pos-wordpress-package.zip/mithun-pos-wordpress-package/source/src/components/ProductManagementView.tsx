/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Product, KaratType, GoldWeightParts, MetalType } from '../types';
import {
  partsToGrams,
  formatWeightPartsBn,
  toBengaliNumber,
  formatTaka,
} from '../utils/goldCalculator';
import { BarcodeRenderer } from './BarcodeRenderer';
import { BarcodePrintModal } from './BarcodePrintModal';
import {
  Gem,
  Plus,
  Search,
  Edit2,
  Trash2,
  Barcode,
  Printer,
  Camera,
  Upload,
  X,
  RefreshCw,
  Image as ImageIcon,
  CheckCircle2,
  Coins,
  Sparkles
} from 'lucide-react';

const CATEGORIES = [
  'সকল ক্যাটাগরি',
  'নেকলেস',
  'চুড়ি / বালা',
  'কানের দুল / ঝুমকা',
  'আংটি',
  'চেইন',
  'নূপুর / পায়েল',
  'টিকলি / সীতাহার',
  'লকেট',
  'নাকফুল',
  'ব্রেসলেট',
  'রূপার কয়েন / বার'
];

export const ProductManagementView: React.FC = () => {
  const { products, saveProduct, deleteProduct, shopProfile } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMetal, setSelectedMetal] = useState<'all' | 'স্বর্ণ' | 'রূপা'>('all');
  const [selectedCategory, setSelectedCategory] = useState('সকল ক্যাটাগরি');
  const [selectedKarat, setSelectedKarat] = useState<string>('all');

  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Barcode Printing State
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [printSelectedProductId, setPrintSelectedProductId] = useState<string | undefined>(undefined);

  // Form Fields
  const [metalType, setMetalType] = useState<MetalType>('স্বর্ণ');
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('নেকলেস');
  const [karat, setKarat] = useState<KaratType>('22K');
  const [bhori, setBhori] = useState('1');
  const [ana, setAna] = useState('0');
  const [roti, setRoti] = useState('0');
  const [point, setPoint] = useState('0');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [stockQuantity, setStockQuantity] = useState('1');
  const [imageUrl, setImageUrl] = useState<string>('');

  // Image Preview Modal
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Live WebCam State
  const [isLiveCameraActive, setIsLiveCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Stop camera stream safely
  const stopLiveCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setIsLiveCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopLiveCamera();
    };
  }, []);

  // Start live webcam
  const startLiveCamera = async () => {
    try {
      stopLiveCamera();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      mediaStreamRef.current = stream;
      setIsLiveCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(console.error);
        }
      }, 100);
    } catch (err) {
      console.warn('Live camera access error, falling back to camera input:', err);
      if (cameraInputRef.current) {
        cameraInputRef.current.click();
      }
    }
  };

  const capturePhotoFromLiveStream = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = Math.min(video.videoWidth || 640, 600);
    canvas.height = Math.round((canvas.width * (video.videoHeight || 480)) / (video.videoWidth || 640));
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      setImageUrl(dataUrl);
    }
    stopLiveCamera();
  };

  // Process file upload / camera capture and resize to base64
  const handleProcessImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 500;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
          setImageUrl(dataUrl);
        }
      };
      if (e.target?.result) {
        img.src = e.target.result as string;
      }
    };
    reader.readAsDataURL(file);
  };

  // Generate unique barcode guaranteed not to conflict with existing products
  const generateUniqueBarcode = (): string => {
    let candidate = '';
    let exists = true;
    let attempts = 0;
    while (exists && attempts < 100) {
      attempts++;
      const timePart = Date.now().toString().slice(-7);
      const randPart = Math.floor(10 + Math.random() * 90);
      candidate = `890${timePart}${randPart}`;
      exists = products.some((p) => p.barcode === candidate);
    }
    return candidate;
  };

  const openAddModal = (presetMetal: MetalType = 'স্বর্ণ') => {
    setEditingProduct(null);
    setMetalType(presetMetal);
    setName('');
    const genCode = `${presetMetal === 'স্বর্ণ' ? 'GLD' : 'SLV'}-${Math.floor(1000 + Math.random() * 9000)}`;
    setCode(genCode);
    setBarcode(generateUniqueBarcode());
    setCategory(presetMetal === 'স্বর্ণ' ? 'নেকলেস' : 'নূপুর / পায়েল');
    setKarat('22K');
    setBhori('1');
    setAna('0');
    setRoti('0');
    setPoint('0');
    setPurchasePrice(presetMetal === 'স্বর্ণ' ? '120000' : '2200');
    setSellingPrice(presetMetal === 'স্বর্ণ' ? '135000' : '2800');
    setStockQuantity('1');
    setImageUrl('');
    setIsModalOpen(true);
  };

  const openEditModal = (prod: Product) => {
    setEditingProduct(prod);
    setMetalType(prod.metalType || 'স্বর্ণ');
    setName(prod.name);
    setCode(prod.code);
    setBarcode(prod.barcode);
    setCategory(prod.category);
    setKarat(prod.karat);
    setBhori(prod.weightParts.bhori.toString());
    setAna(prod.weightParts.ana.toString());
    setRoti(prod.weightParts.roti.toString());
    setPoint(prod.weightParts.point.toString());
    setPurchasePrice(prod.purchasePrice.toString());
    setSellingPrice(prod.sellingPrice.toString());
    setStockQuantity(prod.stockQuantity.toString());
    setImageUrl(prod.imageUrl || '');
    setIsModalOpen(true);
  };

  const openBarcodePrint = (productId?: string) => {
    setPrintSelectedProductId(productId);
    setIsPrintModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('গহনার নাম আবশ্যক');
      return;
    }

    const weightParts: GoldWeightParts = {
      bhori: parseFloat(bhori) || 0,
      ana: parseFloat(ana) || 0,
      roti: parseFloat(roti) || 0,
      point: parseFloat(point) || 0,
    };
    const weightGrams = partsToGrams(weightParts);

    const product: Product = {
      id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
      name: name.trim(),
      code: code.trim(),
      barcode: barcode.trim() || generateUniqueBarcode(),
      category,
      metalType,
      karat,
      weightParts,
      weightGrams,
      purchasePrice: parseFloat(purchasePrice) || 0,
      sellingPrice: parseFloat(sellingPrice) || 0,
      stockQuantity: parseInt(stockQuantity, 10) || 0,
      imageUrl: imageUrl || undefined,
      createdAt: editingProduct ? editingProduct.createdAt : new Date().toISOString(),
    };

    saveProduct(product);
    setIsModalOpen(false);
  };

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchQuery =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.barcode.includes(searchQuery);

    const matchMetal = selectedMetal === 'all' || (p.metalType || 'স্বর্ণ') === selectedMetal;
    const matchCategory = selectedCategory === 'সকল ক্যাটাগরি' || p.category === selectedCategory;
    const matchKarat = selectedKarat === 'all' || p.karat === selectedKarat;

    return matchQuery && matchMetal && matchCategory && matchKarat;
  });

  const goldCount = products.filter(p => (p.metalType || 'স্বর্ণ') === 'স্বর্ণ').length;
  const silverCount = products.filter(p => p.metalType === 'রূপা').length;

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Hidden Native Camera & File Pickers */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files[0]) {
            handleProcessImage(e.target.files[0]);
          }
        }}
      />
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files[0]) {
            handleProcessImage(e.target.files[0]);
          }
        }}
      />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-800/30 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <Gem className="w-6 h-6 text-amber-400" />
            গহনা স্টক ব্যবস্থাপনা (স্বর্ণ ও রূপা উভয় স্টক)
          </h2>
          <p className="text-xs text-amber-400/70">
            দোকানের স্বর্ণ ও রূপা অলংকারের বিস্তারিত স্টক, ছবি, বারকোড এবং ভরি-আনা ও গ্রাম পরিমাপ
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Batch Print Barcode Button */}
          <button
            onClick={() => openBarcodePrint(undefined)}
            className="px-3.5 py-2 rounded-xl bg-neutral-900 border border-amber-500/50 hover:bg-amber-950/40 text-amber-300 font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow active:scale-95 transition-all"
            title="সকল বা নির্বাচিত পণ্যের বারকোড স্টিকার প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            বারকোড ট্যাগ প্রিন্ট
          </button>

          {/* Add Gold Product Button */}
          <button
            onClick={() => openAddModal('স্বর্ণ')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-lg active:scale-95"
          >
            <Plus className="w-4 h-4" />
            + স্বর্ণের গহনা যোগ
          </button>

          {/* Add Silver Product Button */}
          <button
            onClick={() => openAddModal('রূপা')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-slate-200 to-slate-400 hover:from-white hover:to-slate-300 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-lg active:scale-95"
          >
            <Coins className="w-4 h-4 text-slate-900" />
            + রূপার গহনা যোগ
          </button>
        </div>
      </div>

      {/* Metal Filter Tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setSelectedMetal('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
            selectedMetal === 'all'
              ? 'bg-amber-500 text-black border-amber-400 shadow'
              : 'bg-neutral-900 text-amber-200/70 border-amber-900/40 hover:bg-neutral-800'
          }`}
        >
          <span>সকল গহনা</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-black/30">
            {toBengaliNumber(products.length)}
          </span>
        </button>

        <button
          onClick={() => setSelectedMetal('স্বর্ণ')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
            selectedMetal === 'স্বর্ণ'
              ? 'bg-amber-500 text-black border-amber-400 shadow'
              : 'bg-amber-950/40 text-amber-300 border-amber-700/50 hover:bg-amber-950/70'
          }`}
        >
          <Gem className="w-3.5 h-3.5 text-amber-400" />
          <span>স্বর্ণের স্টক (Gold)</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-black/40">
            {toBengaliNumber(goldCount)}
          </span>
        </button>

        <button
          onClick={() => setSelectedMetal('রূপা')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
            selectedMetal === 'রূপা'
              ? 'bg-slate-200 text-slate-950 border-white shadow'
              : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
          }`}
        >
          <Coins className="w-3.5 h-3.5 text-slate-300" />
          <span>রূপার স্টক (Silver)</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-black/40">
            {toBengaliNumber(silverCount)}
          </span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-amber-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="নাম, কোড বা বারকোড দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-9 pr-3 py-1.5 text-xs text-amber-100 placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto py-1 scrollbar-none">
          {CATEGORIES.slice(0, 6).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-xs whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-black font-bold'
                  : 'bg-neutral-900 text-amber-300/80 hover:bg-neutral-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Karat Filter Dropdown */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <span className="text-xs text-amber-400/80">ক্যারেট:</span>
          <select
            value={selectedKarat}
            onChange={(e) => setSelectedKarat(e.target.value)}
            className="bg-neutral-900 border border-amber-600/40 text-amber-100 text-xs rounded-lg px-2 py-1.5 focus:outline-none"
          >
            <option value="all">সকল ক্যারেট</option>
            <option value="24K">24K</option>
            <option value="22K">22K</option>
            <option value="21K">21K</option>
            <option value="18K">18K</option>
            <option value="সনাতন">সনাতন</option>
          </select>
        </div>
      </div>

      {/* Product Table */}
      <div className="bg-[#12110c] rounded-2xl border border-amber-800/40 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-amber-950/40 text-amber-300/90 border-b border-amber-800/30">
              <tr>
                <th className="p-3">গহনা ও ছবি</th>
                <th className="p-3">ধাতু ও ক্যারেট</th>
                <th className="p-3">কোড ও বারকোড</th>
                <th className="p-3">ওজন (ভরি / গ্রাম)</th>
                <th className="p-3 text-right">ক্রয়মূল্য</th>
                <th className="p-3 text-right">বিক্রয়মূল্য</th>
                <th className="p-3 text-center">মজুদ</th>
                <th className="p-3 text-right">বারকোড ও অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-950/60 text-amber-100">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-neutral-400 space-y-2">
                    <div className="w-10 h-10 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto text-amber-400 mb-2">
                      <Gem className="w-5 h-5" />
                    </div>
                    <p className="font-semibold text-amber-200">বর্তমানে কোনো গহনা স্টকে নেই</p>
                    <p className="text-[11px] text-amber-400/60">
                      উপরে "+ স্বর্ণের গহনা যোগ" অথবা "+ রূপার গহনা যোগ" বাটনে ক্লিক করে নতুন গহনা যোগ করুন।
                    </p>
                  </td>
                </tr>
              ) : (
                filteredProducts.map((prod) => {
                  const isSilver = prod.metalType === 'রূপা';
                  return (
                    <tr key={prod.id} className="hover:bg-amber-950/20">
                      {/* Name and Photo */}
                      <td className="p-3">
                        <div className="flex items-center gap-2.5">
                          {prod.imageUrl ? (
                            <div
                              onClick={() => setPreviewImage(prod.imageUrl || null)}
                              className="w-11 h-11 rounded-lg overflow-hidden border border-amber-500/50 bg-black shrink-0 cursor-pointer hover:border-amber-400 group relative"
                              title="বড় করে ছবি দেখতে ক্লিক করুন"
                            >
                              <img
                                src={prod.imageUrl}
                                alt={prod.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              />
                            </div>
                          ) : (
                            <div className={`w-11 h-11 rounded-lg border flex items-center justify-center shrink-0 ${
                              isSilver ? 'border-slate-700 bg-slate-900 text-slate-400' : 'border-amber-900/60 bg-neutral-900 text-amber-500'
                            }`}>
                              {isSilver ? <Coins className="w-5 h-5" /> : <Gem className="w-5 h-5" />}
                            </div>
                          )}
                          <div>
                            <div className="font-bold text-amber-200 text-sm">{prod.name}</div>
                            <span className="text-[10px] bg-amber-950 px-1.5 py-0.5 rounded text-amber-400 border border-amber-800/40">
                              {prod.category}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Metal & Karat */}
                      <td className="p-3">
                        <span
                          className={`font-bold text-[11px] px-2 py-0.5 rounded-full border inline-flex items-center gap-1 ${
                            isSilver
                              ? 'bg-slate-800 text-slate-200 border-slate-600'
                              : 'bg-amber-500/20 text-amber-300 border-amber-600/40'
                          }`}
                        >
                          {isSilver ? 'রূপা' : 'স্বর্ণ'} - {prod.karat}
                        </span>
                      </td>

                      {/* Code and Barcode with print trigger */}
                      <td className="p-3">
                        <div className="font-mono text-amber-300 font-bold">{prod.code}</div>
                        <button
                          onClick={() => openBarcodePrint(prod.id)}
                          className="text-[11px] text-amber-400/90 hover:text-amber-200 underline font-mono flex items-center gap-1 mt-0.5"
                          title="এই বারকোডটি প্রিন্ট করতে ক্লিক করুন"
                        >
                          <Barcode className="w-3.5 h-3.5 text-amber-400" />
                          <span>{prod.barcode}</span>
                        </button>
                      </td>

                      {/* Weights */}
                      <td className="p-3">
                        <div className="text-amber-200 font-medium">{formatWeightPartsBn(prod.weightParts)}</div>
                        <div className="text-[10px] text-amber-400/70 font-mono">
                          {toBengaliNumber(prod.weightGrams)} গ্রাম
                        </div>
                      </td>

                      {/* Prices */}
                      <td className="p-3 text-right font-mono text-neutral-400">
                        {formatTaka(prod.purchasePrice)}
                      </td>

                      <td className="p-3 text-right font-mono font-bold text-amber-300">
                        {formatTaka(prod.sellingPrice)}
                      </td>

                      {/* Stock */}
                      <td className="p-3 text-center">
                        <span
                          className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                            prod.stockQuantity > 0
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/50'
                              : 'bg-red-950/80 text-red-300 border border-red-700/50'
                          }`}
                        >
                          {toBengaliNumber(prod.stockQuantity)} টি
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => openBarcodePrint(prod.id)}
                          aria-label="বারকোড ট্যাগ প্রিন্ট করুন"
                          title="বারকোড ট্যাগ প্রিন্ট করুন"
                          className="p-1.5 rounded-lg bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-700/60 inline-flex items-center gap-1 font-semibold text-[11px]"
                        >
                          <Printer className="w-3.5 h-3.5 text-amber-400" />
                          <span className="hidden sm:inline">ট্যাগ প্রিন্ট</span>
                        </button>
                        <button
                          onClick={() => openEditModal(prod)}
                          aria-label="সম্পাদনা করুন"
                          title="সম্পাদনা করুন"
                          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-300"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`আপনি কি "${prod.name}" মুছে ফেলতে চান?`)) {
                              deleteProduct(prod.id);
                            }
                          }}
                          aria-label="মুছে ফেলুন"
                          title="মুছে ফেলুন"
                          className="p-1.5 rounded-lg bg-red-950/50 hover:bg-red-900/50 text-red-400 border border-red-800/40"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-5 sm:p-6 max-w-lg w-full shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-3">
              <h3 className="font-bold text-lg text-amber-200 flex items-center gap-2">
                <Gem className="w-5 h-5 text-amber-400" />
                {editingProduct ? 'গহনার তথ্য পরিবর্তন' : 'নতুন গহনা যোগ (স্বর্ণ / রূপা)'}
              </h3>
              <button
                onClick={() => {
                  stopLiveCamera();
                  setIsModalOpen(false);
                }}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              {/* Metal Selection Toggle: স্বর্ণ vs রূপা */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-amber-300">ধাতুর প্রকার নির্বাচন করুন *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setMetalType('স্বর্ণ');
                      if (!editingProduct) {
                        setCode(`GLD-${Math.floor(1000 + Math.random() * 9000)}`);
                        setCategory('নেকলেস');
                        setPurchasePrice('120000');
                        setSellingPrice('135000');
                      }
                    }}
                    className={`py-2 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                      metalType === 'স্বর্ণ'
                        ? 'bg-amber-500 text-black border-amber-400 shadow font-extrabold'
                        : 'bg-neutral-900 text-amber-200/70 border-amber-800/40'
                    }`}
                  >
                    <Gem className="w-3.5 h-3.5" />
                    <span>স্বর্ণের গহনা (Gold)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setMetalType('রূপা');
                      if (!editingProduct) {
                        setCode(`SLV-${Math.floor(1000 + Math.random() * 9000)}`);
                        setCategory('নূপুর / পায়েল');
                        setPurchasePrice('2200');
                        setSellingPrice('2800');
                      }
                    }}
                    className={`py-2 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                      metalType === 'রূপা'
                        ? 'bg-slate-200 text-slate-950 border-white shadow font-extrabold'
                        : 'bg-neutral-900 text-slate-300/70 border-slate-700'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>রূপার গহনা (Silver)</span>
                  </button>
                </div>
              </div>

              {/* Product Photo Capture Section */}
              <div className="bg-black/60 p-3.5 rounded-xl border border-amber-800/50 space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-amber-400" />
                    প্রোডাক্টের ছবি (চেনার জন্য ছবি তুলুন বা আপলোড করুন)
                  </label>
                  {imageUrl && (
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1"
                    >
                      <X className="w-3 h-3" /> ছবি বাদ দিন
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  {/* Photo Preview Box */}
                  <div className="w-20 h-20 rounded-xl border-2 border-dashed border-amber-700/60 bg-neutral-900 flex items-center justify-center overflow-hidden shrink-0 relative">
                    {imageUrl ? (
                      <img
                        src={imageUrl}
                        alt="Product Preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex flex-col items-center justify-center text-amber-500/50">
                        <ImageIcon className="w-7 h-7" />
                        <span className="text-[9px] mt-0.5">ছবি নেই</span>
                      </div>
                    )}
                  </div>

                  {/* Buttons for Camera and Gallery */}
                  <div className="flex-1 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={startLiveCamera}
                        className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center justify-center gap-1.5 shadow active:scale-95 transition-all"
                      >
                        <Camera className="w-3.5 h-3.5" />
                        ক্যামেরা ছবি
                      </button>

                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-200 font-medium text-xs flex items-center justify-center gap-1.5 border border-amber-700/40 active:scale-95 transition-all"
                      >
                        <Upload className="w-3.5 h-3.5 text-amber-400" />
                        গ্যালারি / ফাইল
                      </button>
                    </div>

                    <p className="text-[10px] text-amber-400/60">
                      ক্যামেরা দিয়ে ছবি তুলে রাখলে পণ্য বিক্রি বা খোঁজার সময় ছবি দেখে সহজেই চেনা যাবে।
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-amber-300 mb-1">গহনার নাম *</label>
                <input
                  type="text"
                  required
                  placeholder={metalType === 'স্বর্ণ' ? 'যেমন: ২২ ক্যারেট সীতা হার' : 'যেমন: রূপার পায়েল / নূপুর'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">ক্যাটাগরি</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-2 py-1.5 text-xs text-amber-100"
                  >
                    {CATEGORIES.slice(1).map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">ক্যারেট</label>
                  <select
                    value={karat}
                    onChange={(e) => setKarat(e.target.value as KaratType)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-2 py-1.5 text-xs text-amber-100 font-bold"
                  >
                    <option value="22K">22K</option>
                    <option value="21K">21K</option>
                    <option value="18K">18K</option>
                    <option value="24K">24K</option>
                    <option value="সনাতন">সনাতন</option>
                  </select>
                </div>
              </div>

              {/* Product Code and Unique Barcode */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">প্রোডাক্ট কোড</label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs font-mono text-amber-100"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs text-amber-300/80">বারকোড (আলাদা ও ইউনিক)</label>
                    <button
                      type="button"
                      onClick={() => setBarcode(generateUniqueBarcode())}
                      className="text-[10px] text-amber-400 hover:text-amber-200 flex items-center gap-0.5"
                      title="নতুন ইউনিক বারকোড তৈরি করুন"
                    >
                      <RefreshCw className="w-2.5 h-2.5" /> নতুন
                    </button>
                  </div>
                  <input
                    type="text"
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs font-mono text-amber-100"
                  />
                </div>
              </div>

              {/* Weight Parts */}
              <div className="bg-black/50 p-3 rounded-xl border border-amber-800/40 space-y-2">
                <span className="text-xs font-semibold text-amber-300 block">ওজন (ভরি - আনা - রতি - পয়েন্ট):</span>
                <div className="grid grid-cols-4 gap-2">
                  <div>
                    <label className="text-[10px] text-amber-400/80">ভরি</label>
                    <input
                      type="number"
                      min="0"
                      value={bhori}
                      onChange={(e) => setBhori(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-amber-400/80">আনা (&lt;16)</label>
                    <input
                      type="number"
                      min="0"
                      max="15"
                      value={ana}
                      onChange={(e) => setAna(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-amber-400/80">রতি (&lt;6)</label>
                    <input
                      type="number"
                      min="0"
                      max="5"
                      value={roti}
                      onChange={(e) => setRoti(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-amber-400/80">পয়েন্ট</label>
                    <input
                      type="number"
                      min="0"
                      value={point}
                      onChange={(e) => setPoint(e.target.value)}
                      className="w-full bg-neutral-900 border border-amber-600/30 rounded px-2 py-1 text-xs text-center font-mono text-amber-100"
                    />
                  </div>
                </div>
              </div>

              {/* Pricing & Stock */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">ক্রয়মূল্য (৳)</label>
                  <input
                    type="number"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-2.5 py-1.5 text-xs font-mono text-amber-100"
                  />
                </div>
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">বিক্রয়মূল্য (৳)</label>
                  <input
                    type="number"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-2.5 py-1.5 text-xs font-mono text-amber-100 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1">মজুদ সংখ্যা</label>
                  <input
                    type="number"
                    min="0"
                    value={stockQuantity}
                    onChange={(e) => setStockQuantity(e.target.value)}
                    className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-2.5 py-1.5 text-xs font-mono text-amber-100 font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => {
                    stopLiveCamera();
                    setIsModalOpen(false);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs shadow"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Live Camera Feed Modal */}
      {isLiveCameraActive && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="bg-[#14120e] border border-amber-500 rounded-2xl p-4 max-w-md w-full shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-2">
              <h4 className="font-bold text-sm text-amber-200 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-amber-400" />
                লাইভ ক্যামেরা দিয়ে অলংকারের ছবি তুলুন
              </h4>
              <button
                onClick={stopLiveCamera}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center border border-amber-700/50">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  stopLiveCamera();
                  if (cameraInputRef.current) cameraInputRef.current.click();
                }}
                className="px-3 py-2 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-semibold"
              >
                ডিভাইস ক্যামেরা অ্যাপ
              </button>
              <button
                type="button"
                onClick={capturePhotoFromLiveStream}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs flex items-center gap-1.5 shadow-lg active:scale-95"
              >
                <Camera className="w-4 h-4" />
                ছবি তুলুন (Capture)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Enlarged Photo Preview Modal */}
      {previewImage && (
        <div
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm cursor-pointer"
        >
          <div className="relative max-w-lg w-full max-h-[85vh] bg-[#14120e] rounded-2xl overflow-hidden border border-amber-500/60 p-2 shadow-2xl">
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-black/70 text-white hover:bg-black"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewImage}
              alt="Jewelry Preview"
              className="w-full h-auto max-h-[75vh] object-contain rounded-xl"
            />
          </div>
        </div>
      )}

      {/* Jewelry Barcode Print Modal */}
      {isPrintModalOpen && (
        <BarcodePrintModal
          products={products}
          initialSelectedId={printSelectedProductId}
          shopName={shopProfile?.name || 'মেসার্স মিঠুন অলংকার হাউজ'}
          onClose={() => {
            setIsPrintModalOpen(false);
            setPrintSelectedProductId(undefined);
          }}
        />
      )}
    </div>
  );
};
