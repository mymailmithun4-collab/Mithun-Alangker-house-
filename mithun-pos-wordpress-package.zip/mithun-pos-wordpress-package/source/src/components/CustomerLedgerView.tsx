/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Customer, DuePayment, PaymentMethod } from '../types';
import { formatTaka, toBengaliNumber } from '../utils/goldCalculator';
import {
  Users,
  Search,
  Plus,
  Coins,
  Receipt,
  Phone,
  MapPin,
  CheckCircle2,
  Calendar,
  X,
  CreditCard
} from 'lucide-react';

export const CustomerLedgerView: React.FC = () => {
  const { customers, saveCustomer, duePayments, collectDuePayment, user } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterDueOnly, setFilterDueOnly] = useState(false);

  // Modals
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [dueCollectionCustomer, setDueCollectionCustomer] = useState<Customer | null>(null);

  // Add Customer Form
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [initialDue, setInitialDue] = useState('0');

  // Due Payment Form
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('নগদ');
  const [paymentNotes, setPaymentNotes] = useState('');

  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newCust: Customer = {
      id: `cust-${Date.now()}`,
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      totalPurchasesCount: 0,
      totalSpent: parseFloat(initialDue) || 0,
      totalPaid: 0,
      currentDue: parseFloat(initialDue) || 0,
      createdAt: new Date().toISOString(),
    };

    saveCustomer(newCust);
    setIsAddCustomerOpen(false);
    setName('');
    setPhone('');
    setAddress('');
    setInitialDue('0');
  };

  const handleCollectDue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dueCollectionCustomer) return;

    const amt = parseFloat(paymentAmount) || 0;
    if (amt <= 0) {
      alert('সঠিক টাকার পরিমাণ দিন');
      return;
    }

    const receiptNo: string = `DUE-${Date.now().toString().slice(-6)}`;
    const payment: DuePayment = {
      id: `dp-${Date.now()}`,
      receiptNo,
      customerId: dueCollectionCustomer.id,
      customerName: dueCollectionCustomer.name,
      customerPhone: dueCollectionCustomer.phone,
      amount: amt,
      date: new Date().toISOString(),
      paymentMethod,
      previousDue: dueCollectionCustomer.currentDue,
      remainingDue: Math.max(0, dueCollectionCustomer.currentDue - amt),
      notes: paymentNotes,
    };

    collectDuePayment(payment);
    setDueCollectionCustomer(null);
    setPaymentAmount('');
    setPaymentNotes('');
  };

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      c.address.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDue = filterDueOnly ? c.currentDue > 0 : true;
    return matchesSearch && matchesDue;
  });

  const totalOutstandingDue = customers.reduce((acc, c) => acc + c.currentDue, 0);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-800/30 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <Users className="w-6 h-6 text-amber-400" />
            গ্রাহক খাতা ও বকেয়া হিসাব (Customer Ledger & Dues)
          </h2>
          <p className="text-xs text-amber-400/70">
            গ্রাহকদের লেনদেন ইতিহাস, মোট বাকি ও বকেয়া আদায়ের রসিদ
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-red-950/80 border border-red-700/50 px-3 py-1.5 rounded-xl text-xs font-bold text-red-300">
            সর্বমোট বকেয়া: {formatTaka(totalOutstandingDue)}
          </div>
          <button
            onClick={() => setIsAddCustomerOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            নতুন গ্রাহক
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-amber-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="গ্রাহকের নাম বা মোবাইল নম্বর দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-9 pr-3 py-1.5 text-xs text-amber-100 placeholder-neutral-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 text-xs text-amber-300 cursor-pointer">
            <input
              type="checkbox"
              checked={filterDueOnly}
              onChange={(e) => setFilterDueOnly(e.target.checked)}
              className="accent-amber-500 w-4 h-4 rounded"
            />
            শুধু বকেয়া গ্রাহকদের দেখান ({toBengaliNumber(customers.filter(c => c.currentDue > 0).length)} জন)
          </label>
        </div>
      </div>

      {/* Customer List Table */}
      <div className="bg-[#12110c] rounded-2xl border border-amber-800/40 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-amber-950/40 text-amber-300/90 border-b border-amber-800/30">
              <tr>
                <th className="p-3">গ্রাহকের নাম</th>
                <th className="p-3">মোবাইল নম্বর</th>
                <th className="p-3">ঠিকানা</th>
                <th className="p-3 text-center">কেনাকাটা</th>
                <th className="p-3 text-right">মোট কেনাকাটা</th>
                <th className="p-3 text-right">মোট পরিশোধ</th>
                <th className="p-3 text-right">বর্তমান বকেয়া</th>
                <th className="p-3 text-center">বকেয়া আদায়</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-950/60 text-amber-100">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-10 text-neutral-500">
                    কোনো গ্রাহক পাওয়া যায়নি।
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => (
                  <tr key={cust.id} className="hover:bg-amber-950/20">
                    <td className="p-3">
                      <div className="font-bold text-amber-200 text-sm">{cust.name}</div>
                      {cust.lastPurchaseDate && (
                        <div className="text-[10px] text-neutral-400">
                          সর্বশেষ: {new Date(cust.lastPurchaseDate).toLocaleDateString('bn-BD')}
                        </div>
                      )}
                    </td>
                    <td className="p-3 font-mono font-semibold text-amber-300">{cust.phone}</td>
                    <td className="p-3 text-neutral-300">{cust.address || '—'}</td>
                    <td className="p-3 text-center font-mono">
                      {toBengaliNumber(cust.totalPurchasesCount)} বার
                    </td>
                    <td className="p-3 text-right font-mono text-neutral-400">
                      {formatTaka(cust.totalSpent)}
                    </td>
                    <td className="p-3 text-right font-mono text-emerald-400">
                      {formatTaka(cust.totalPaid)}
                    </td>
                    <td className="p-3 text-right font-mono font-bold">
                      <span className={cust.currentDue > 0 ? 'text-red-400 text-sm' : 'text-emerald-400'}>
                        {formatTaka(cust.currentDue)}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      {cust.currentDue > 0 ? (
                        <button
                          onClick={() => {
                            setDueCollectionCustomer(cust);
                            setPaymentAmount(cust.currentDue.toString());
                          }}
                          className="px-2.5 py-1 rounded bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold text-[11px] shadow inline-flex items-center gap-1"
                        >
                          <Coins className="w-3 h-3" /> টাকা জমা
                        </button>
                      ) : (
                        <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
                          পরিশোধিত
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Due Collection Modal */}
      {dueCollectionCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-3">
              <h3 className="font-bold text-base text-amber-200 flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-400" />
                বকেয়া কিস্তি / টাকা আদায়
              </h3>
              <button onClick={() => setDueCollectionCustomer(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-neutral-950 p-3 rounded-xl border border-amber-900/50 text-xs space-y-1">
              <p className="text-neutral-300">গ্রাহকের নাম: <strong className="text-amber-200">{dueCollectionCustomer.name}</strong></p>
              <p className="text-neutral-300">মোবাইল: <strong className="text-amber-200 font-mono">{dueCollectionCustomer.phone}</strong></p>
              <p className="text-red-400 font-bold text-sm pt-1 border-t border-neutral-800">
                বর্তমান মোট বকেয়া: {formatTaka(dueCollectionCustomer.currentDue)}
              </p>
            </div>

            <form onSubmit={handleCollectDue} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-emerald-400 mb-1">
                  জমা টাকার পরিমাণ (৳) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max={dueCollectionCustomer.currentDue}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-3 py-2 text-base font-mono text-emerald-300 font-bold focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-amber-300 mb-1">পেমেন্ট মাধ্যম</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['নগদ', 'বিকাশ', 'নগদ/রকেট'] as PaymentMethod[]).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPaymentMethod(m)}
                      className={`py-1 px-2 rounded text-xs font-semibold border ${
                        paymentMethod === m
                          ? 'bg-amber-500 text-black border-amber-400'
                          : 'bg-neutral-900 text-amber-200 border-amber-900/50'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs text-amber-300 mb-1">রশিদ নোট / মন্তব্য</label>
                <input
                  type="text"
                  placeholder="যেমন: মাসিক কিস্তির অংশ"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => setDueCollectionCustomer(null)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-black font-bold text-xs shadow"
                >
                  জমা নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Customer Modal */}
      {isAddCustomerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-3">
              <h3 className="font-bold text-base text-amber-200">নতুন গ্রাহক যোগ করুন</h3>
              <button onClick={() => setIsAddCustomerOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-amber-300 mb-1">গ্রাহকের নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="নাম লিখুন"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100"
                />
              </div>

              <div>
                <label className="block text-xs text-amber-300/80 mb-1">মোবাইল নম্বর</label>
                <input
                  type="text"
                  placeholder="০১৭১১xxxxxx"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs font-mono text-amber-100"
                />
              </div>

              <div>
                <label className="block text-xs text-amber-300/80 mb-1">ঠিকানা</label>
                <input
                  type="text"
                  placeholder="এলাকা বা জেলা"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100"
                />
              </div>

              <div>
                <label className="block text-xs text-amber-300/80 mb-1">পূর্বের কোনো বকেয়া থাকলে (৳)</label>
                <input
                  type="number"
                  min="0"
                  value={initialDue}
                  onChange={(e) => setInitialDue(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs font-mono text-amber-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => setIsAddCustomerOpen(false)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-amber-500 text-black font-bold text-xs"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
