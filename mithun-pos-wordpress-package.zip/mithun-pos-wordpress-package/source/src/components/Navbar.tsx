/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp, ActiveTab } from '../context/AppContext';
import {
  LayoutDashboard,
  ReceiptText,
  Calculator,
  Gem,
  Coins,
  ArrowDownLeft,
  Users,
  BarChart3,
  Database,
  Smartphone,
  Flame,
  ShieldCheck,
  LogOut,
  LogIn,
  Download,
  Settings2,
  Sparkles
} from 'lucide-react';
import { toBengaliNumber } from '../utils/goldCalculator';

export const Navbar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    user,
    firebaseStatus,
    rates,
    setIsAuthModalOpen,
    setIsFirebaseModalOpen,
    setIsAndroidModalOpen,
    logout,
    shopProfile
  } = useApp();

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'pos', label: 'ক্যাশ মেমো (POS)', icon: <ReceiptText className="w-4 h-4" /> },
    { id: 'orders', label: 'স্বর্ণ ও রূপার অর্ডার', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'mortgage', label: 'বন্ধকী হিসাব', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 'calculator', label: 'স্বর্ণ ক্যালকুলেটর', icon: <Calculator className="w-4 h-4" /> },
    { id: 'products', label: 'গহনা স্টক', icon: <Gem className="w-4 h-4" /> },
    { id: 'purchases', label: 'স্বর্ণ ক্রয়/বিনিময়', icon: <ArrowDownLeft className="w-4 h-4" /> },
    { id: 'customers', label: 'গ্রাহক ও বকেয়া', icon: <Users className="w-4 h-4" /> },
    { id: 'reports', label: 'রিপোর্ট ও লাভ', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'backup', label: 'ব্যাকআপ', icon: <Database className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0d0c09]/95 backdrop-blur-md border-b border-amber-600/30 text-amber-50 no-print">
      {/* Live Gold & Silver Rate Ticker */}
      <div className="bg-gradient-to-r from-amber-950/80 via-black to-slate-950/90 border-b border-amber-800/20 px-3 py-1 text-xs text-amber-300/90 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 overflow-x-auto py-0.5 scrollbar-none text-[11px] sm:text-xs">
          {/* Gold rates */}
          <span className="inline-flex items-center gap-1 font-bold text-amber-400 bg-amber-950/90 px-2 py-0.5 rounded border border-amber-600/40">
            <Flame className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
            স্বর্ণ (ভরি):
          </span>
          <span className="whitespace-nowrap">২২K: <strong>৳{toBengaliNumber(rates['22K'].toLocaleString('en-IN'))}</strong></span>
          <span className="text-amber-700">|</span>
          <span className="whitespace-nowrap">২১K: <strong>৳{toBengaliNumber(rates['21K'].toLocaleString('en-IN'))}</strong></span>
          <span className="text-amber-700">|</span>
          <span className="whitespace-nowrap">সনাতন: <strong>৳{toBengaliNumber(rates['সনাতন'].toLocaleString('en-IN'))}</strong></span>
        </div>

        <div className="flex items-center gap-2 text-xs">
          {/* Android APK & Install Button */}
          <button
            onClick={() => setIsAndroidModalOpen(true)}
            aria-label="Android APK Download & Install"
            className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold px-3 py-1 rounded-full text-xs shadow-md shadow-amber-950/60 active:scale-95 transition-all"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>APK ডাউনলোড</span>
          </button>

          {/* Firebase Status Badge */}
          <button
            onClick={() => setIsFirebaseModalOpen(true)}
            aria-label="Firebase status and settings"
            className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium border transition-colors ${
              firebaseStatus === 'connected'
                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/40 hover:bg-emerald-900/60'
                : 'bg-amber-950/70 text-amber-300 border-amber-600/40 hover:bg-amber-900/50'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${firebaseStatus === 'connected' ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
            <span className="hidden sm:inline">{firebaseStatus === 'connected' ? 'ফায়ারবেস ক্লাউড' : 'ফায়ারবেস'}</span>
            <Settings2 className="w-3 h-3 ml-0.5 opacity-80" />
          </button>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Shop Branding */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 via-amber-600 to-amber-800 p-0.5 shadow-lg shadow-amber-950/50 flex items-center justify-center">
            <div className="w-full h-full bg-[#0d0c09] rounded-[7px] flex items-center justify-center">
              <Gem className="w-5 h-5 text-amber-400" />
            </div>
          </div>
          <div>
            <h1 className="font-bold text-lg sm:text-xl tracking-tight text-amber-100 flex items-center gap-2">
              <span>{shopProfile.name}</span>
              <span className="hidden md:inline-block text-[10px] font-normal uppercase tracking-widest text-amber-400/90 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-700/50">
                জুয়েলারি POS
              </span>
            </h1>
            <p className="text-[11px] text-amber-300/70 hidden sm:block">
              {shopProfile.slogan}
            </p>
          </div>
        </div>

        {/* User Account & Actions */}
        <div className="flex items-center gap-2">
          {user ? (
            <div className="flex items-center gap-2">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-semibold text-amber-200">{user.displayName}</p>
                <p className="text-[10px] text-amber-400/80">{user.isDemo ? 'ডেমো এডমিন' : user.email}</p>
              </div>
              <button
                onClick={logout}
                aria-label="লগআউট"
                title="লগআউট"
                className="p-2 rounded-lg bg-red-950/30 border border-red-800/40 text-red-300 hover:bg-red-900/40 text-xs flex items-center gap-1"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">লগআউট</span>
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              aria-label="লগইন বা রেজিস্ট্রেশন"
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs hover:from-amber-400 hover:to-amber-500 shadow-md flex items-center gap-1.5"
            >
              <LogIn className="w-4 h-4" />
              লগইন / রেজিস্টার
            </button>
          )}
        </div>
      </div>

      {/* Desktop / Tablet Nav Bar */}
      <nav className="hidden md:block bg-[#12110c] border-t border-amber-900/30 px-4" aria-label="Main Navigation">
        <div className="max-w-7xl mx-auto flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                aria-label={item.label}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500/20 via-amber-500/10 to-transparent text-amber-300 border-b-2 border-amber-400 shadow-sm'
                    : 'text-amber-200/70 hover:text-amber-100 hover:bg-amber-950/40'
                }`}
              >
                <span className={isActive ? 'text-amber-400' : 'text-amber-300/60'}>
                  {item.icon}
                </span>
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile Bottom Navigation Bar (Persistent for single-thumb mobile operation) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0d0c0a]/95 backdrop-blur-lg border-t border-amber-800/40 py-1 px-1 flex justify-between items-center"
      >
        {[
          { id: 'dashboard' as ActiveTab, label: 'ড্যাশবোর্ড', icon: <LayoutDashboard className="w-4 h-4" /> },
          { id: 'pos' as ActiveTab, label: 'মেমো', icon: <ReceiptText className="w-4 h-4" /> },
          { id: 'orders' as ActiveTab, label: 'অর্ডার', icon: <Sparkles className="w-4 h-4" /> },
          { id: 'mortgage' as ActiveTab, label: 'বন্ধক', icon: <ShieldCheck className="w-4 h-4" /> },
          { id: 'products' as ActiveTab, label: 'স্টক', icon: <Gem className="w-4 h-4" /> },
        ].map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              aria-label={item.label}
              className={`flex flex-col items-center justify-center p-1 rounded-lg text-[10px] min-w-[50px] transition-colors ${
                isActive
                  ? 'text-amber-400 font-bold bg-amber-950/60'
                  : 'text-amber-300/60 hover:text-amber-100'
              }`}
            >
              <div className={`p-1 rounded-md ${isActive ? 'bg-amber-500/20' : ''}`}>
                {item.icon}
              </div>
              <span className="mt-0.5 leading-none text-center">
                {item.label}
              </span>
            </button>
          );
        })}
        {/* More Menu Item for mobile */}
        <button
          onClick={() => setActiveTab(activeTab === 'reports' ? 'customers' : 'reports')}
          aria-label="অতিরিক্ত মেনু"
          className={`flex flex-col items-center justify-center p-1 rounded-lg text-[10px] min-w-[50px] ${
            activeTab === 'reports' || activeTab === 'customers' || activeTab === 'backup'
              ? 'text-amber-400 font-bold bg-amber-950/60'
              : 'text-amber-300/60'
          }`}
        >
          <div className="p-1 rounded-md">
            <BarChart3 className="w-4 h-4" />
          </div>
          <span className="mt-0.5 leading-none">বাকি/রিপোর্ট</span>
        </button>
      </nav>
    </header>
  );
};
