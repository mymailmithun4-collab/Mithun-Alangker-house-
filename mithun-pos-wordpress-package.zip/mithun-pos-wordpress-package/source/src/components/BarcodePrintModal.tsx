/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Product } from '../types';
import { formatWeightPartsBn, toBengaliNumber, formatTaka } from '../utils/goldCalculator';
import { BarcodeRenderer } from './BarcodeRenderer';
import { Printer, X, Tag, Copy, Sliders, Check, Eye } from 'lucide-react';

interface BarcodePrintModalProps {
  products: Product[]; // can be single product or multiple
  initialSelectedId?: string;
  onClose: () => void;
  shopName?: string;
}

type LabelSize = 'jewelry-50x25' | 'mini-40x20' | 'standard-60x30' | 'sheet-a4';

export const BarcodePrintModal: React.FC<BarcodePrintModalProps> = ({
  products,
  initialSelectedId,
  onClose,
  shopName = 'মেসার্স মিঠুন অলংকার হাউজ',
}) => {
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(
    initialSelectedId ? [initialSelectedId] : products.map(p => p.id)
  );
  const [copiesPerItem, setCopiesPerItem] = useState<number>(1);
  const [labelSize, setLabelSize] = useState<LabelSize>('jewelry-50x25');
  const [showPrice, setShowPrice] = useState<boolean>(true);
  const [showWeight, setShowWeight] = useState<boolean>(true);
  const [showKarat, setShowKarat] = useState<boolean>(true);

  const selectedProducts = products.filter(p => selectedProductIds.includes(p.id));

  const toggleSelect = (id: string) => {
    setSelectedProductIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    setSelectedProductIds(products.map(p => p.id));
  };

  const handlePrint = () => {
    window.print();
  };

  // Dimensions based on selection
  const getSizeStyles = () => {
    switch (labelSize) {
      case 'mini-40x20':
        return {
          container: 'w-[150px] min-h-[85px] p-1.5 text-[9px]',
          barcodeHeight: 26,
          barcodeUnit: 1.1,
        };
      case 'standard-60x30':
        return {
          container: 'w-[230px] min-h-[125px] p-2.5 text-[11px]',
          barcodeHeight: 38,
          barcodeUnit: 1.5,
        };
      case 'sheet-a4':
        return {
          container: 'w-[190px] min-h-[105px] p-2 text-[10px]',
          barcodeHeight: 32,
          barcodeUnit: 1.3,
        };
      case 'jewelry-50x25':
      default:
        return {
          container: 'w-[195px] min-h-[100px] p-2 text-[10px]',
          barcodeHeight: 30,
          barcodeUnit: 1.3,
        };
    }
  };

  const sizeStyle = getSizeStyles();

  // Create flat list of labels based on copiesPerItem
  const labelsToRender: Product[] = [];
  selectedProducts.forEach(prod => {
    const count = Math.max(1, copiesPerItem);
    for (let i = 0; i < count; i++) {
      labelsToRender.push(prod);
    }
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-sm overflow-y-auto print:bg-white print:p-0 print:static print:overflow-visible">
      <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl max-w-4xl w-full shadow-2xl my-6 flex flex-col max-h-[92vh] print:max-h-none print:border-none print:shadow-none print:bg-white print:w-full print:m-0 print:rounded-none">
        
        {/* Header - Hidden on Print */}
        <div className="flex items-center justify-between border-b border-amber-800/40 p-4 print:hidden">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-amber-200">
                জুয়েলারি বারকোড ট্যাগ ও স্টিকার প্রিন্টার
              </h3>
              <p className="text-xs text-amber-400/70">
                বারকোড প্রিন্টার দিয়ে প্রিন্ট করে অলংকারে ট্যাগ লাগানোর উপযোগী
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={labelsToRender.length === 0}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-lg active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              প্রিন্ট দিন ({labelsToRender.length})
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Configuration Bar - Hidden on Print */}
        <div className="bg-neutral-900/90 border-b border-amber-900/40 p-3 sm:p-4 grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs print:hidden">
          {/* Label Format */}
          <div className="sm:col-span-4">
            <label className="block text-[11px] font-semibold text-amber-300 mb-1">
              লেবেল / ট্যাগ সাইজ:
            </label>
            <select
              value={labelSize}
              onChange={(e) => setLabelSize(e.target.value as LabelSize)}
              className="w-full bg-[#18150e] border border-amber-600/40 rounded-lg px-2.5 py-1.5 text-amber-100 text-xs focus:outline-none"
            >
              <option value="jewelry-50x25">জুয়েলারি ট্যাগ (৫০ × ২৫ মিমি / রোল)</option>
              <option value="mini-40x20">মিনি ট্যাগ / আংটি (৪০ × ২০ মিমি)</option>
              <option value="standard-60x30">স্ট্যান্ডার্ড স্টিকার (৬০ × ৩০ মিমি)</option>
              <option value="sheet-a4">এ৪ শীট (A4 Sticker Sheet ২৪টি/পেজ)</option>
            </select>
          </div>

          {/* Copies */}
          <div className="sm:col-span-3">
            <label className="block text-[11px] font-semibold text-amber-300 mb-1">
              প্রতিটি আইটেমের কপি:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="50"
                value={copiesPerItem}
                onChange={(e) => setCopiesPerItem(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-20 bg-[#18150e] border border-amber-600/40 rounded-lg px-2 py-1.5 text-center text-amber-100 font-mono font-bold"
              />
              <span className="text-[11px] text-amber-400/80">কপি প্রতি পণ্য</span>
            </div>
          </div>

          {/* Toggle Fields */}
          <div className="sm:col-span-5 flex flex-wrap items-center gap-3 pt-4 sm:pt-5">
            <label className="inline-flex items-center gap-1.5 text-amber-300/90 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={showKarat}
                onChange={(e) => setShowKarat(e.target.checked)}
                className="rounded accent-amber-500"
              />
              ক্যারেট
            </label>
            <label className="inline-flex items-center gap-1.5 text-amber-300/90 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={showWeight}
                onChange={(e) => setShowWeight(e.target.checked)}
                className="rounded accent-amber-500"
              />
              ওজন
            </label>
            <label className="inline-flex items-center gap-1.5 text-amber-300/90 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={showPrice}
                onChange={(e) => setShowPrice(e.target.checked)}
                className="rounded accent-amber-500"
              />
              মূল্য
            </label>
          </div>
        </div>

        {/* Multi-Product Selector if multiple products exist - Hidden on Print */}
        {products.length > 1 && (
          <div className="bg-[#12110c] px-4 py-2 border-b border-amber-900/30 flex items-center justify-between text-xs print:hidden overflow-x-auto gap-2">
            <span className="text-amber-400/80 whitespace-nowrap">
              নির্বাচিত পণ্য: <strong className="text-amber-200">{selectedProducts.length}</strong> / {products.length}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={selectAll}
                className="px-2 py-0.5 rounded bg-neutral-800 text-amber-300 hover:bg-neutral-700 text-[11px]"
              >
                সব সিলেক্ট
              </button>
              <button
                type="button"
                onClick={() => setSelectedProductIds(initialSelectedId ? [initialSelectedId] : [products[0]?.id])}
                className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:bg-neutral-700 text-[11px]"
              >
                শুধু একটি
              </button>
            </div>
          </div>
        )}

        {/* Labels Preview & Print Area */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-neutral-950 print:bg-white print:p-0 print:m-0 print:overflow-visible">
          {labelsToRender.length === 0 ? (
            <div className="text-center py-12 text-neutral-500">
              কোনো পণ্য নির্বাচিত করা হয়নি। দয়া করে অন্তত একটি পণ্য নির্বাচন করুন।
            </div>
          ) : (
            <div
              className={`barcode-print-container flex flex-wrap gap-3 justify-center print:block print:p-0 print:m-0 ${
                labelSize === 'sheet-a4' ? 'print:grid print:grid-cols-3 print:gap-2' : ''
              }`}
            >
              {labelsToRender.map((prod, idx) => (
                <div
                  key={`${prod.id}-${idx}`}
                  className={`barcode-tag-item bg-white text-neutral-900 border-2 border-dashed border-neutral-300 rounded-md flex flex-col justify-between shadow-sm overflow-hidden break-inside-avoid print:border print:border-neutral-800 print:shadow-none print:break-inside-avoid print:mb-2 print:mx-auto ${sizeStyle.container}`}
                  style={{
                    pageBreakInside: 'avoid',
                  }}
                >
                  {/* Shop Branding Header */}
                  <div className="text-center border-b border-neutral-200 pb-0.5 leading-tight">
                    <span className="font-extrabold text-[9px] sm:text-[10px] text-neutral-900 tracking-tight block truncate">
                      {shopName}
                    </span>
                  </div>

                  {/* Product Details Header */}
                  <div className="my-1 flex items-start justify-between gap-1 leading-tight">
                    <div className="overflow-hidden">
                      <div className="font-bold text-[10px] text-neutral-900 truncate">
                        {prod.name}
                      </div>
                      <div className="font-mono text-[9px] text-neutral-600 font-semibold">
                        কোড: {prod.code}
                      </div>
                    </div>

                    {showKarat && (
                      <span className="shrink-0 bg-neutral-900 text-white font-bold text-[9px] px-1 py-0.2 rounded font-mono">
                        {prod.karat}
                      </span>
                    )}
                  </div>

                  {/* Weight and Price */}
                  {(showWeight || showPrice) && (
                    <div className="my-0.5 py-0.5 border-y border-neutral-100 flex items-center justify-between text-[9px] font-medium text-neutral-800">
                      {showWeight && (
                        <div className="leading-tight">
                          <span className="font-semibold">{formatWeightPartsBn(prod.weightParts)}</span>
                          <span className="text-[8px] text-neutral-500 block font-mono">({toBengaliNumber(prod.weightGrams)}g)</span>
                        </div>
                      )}
                      {showPrice && (
                        <div className="text-right leading-tight">
                          <span className="font-bold font-mono text-[10px] text-neutral-900">
                            {formatTaka(prod.sellingPrice)}
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Barcode SVG */}
                  <div className="mt-1 flex flex-col items-center justify-center">
                    <BarcodeRenderer
                      code={prod.barcode}
                      height={sizeStyle.barcodeHeight}
                      unitWidth={sizeStyle.barcodeUnit}
                      showText={true}
                      className="border-none shadow-none p-0 w-full"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer info - Hidden on Print */}
        <div className="p-3 border-t border-amber-900/40 bg-[#12110c] flex flex-col sm:flex-row items-center justify-between text-xs text-amber-400/80 gap-2 print:hidden">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
            <span>প্রিন্টারের কাগজ অনুযায়ী ট্যাগ স্বয়ংক্রিয়ভাবে কাট-মার্ক ও সাইজে ফিট হবে।</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
            >
              বন্ধ করুন
            </button>
            <button
              onClick={handlePrint}
              disabled={labelsToRender.length === 0}
              className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              প্রিন্ট করুন
            </button>
          </div>
        </div>

      </div>

      {/* Embedded Print CSS */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .barcode-print-container, .barcode-print-container * {
            visibility: visible;
          }
          .barcode-print-container {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 0;
          }
          @page {
            size: auto;
            margin: 3mm;
          }
          .barcode-tag-item {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }
        }
      `}</style>
    </div>
  );
};
