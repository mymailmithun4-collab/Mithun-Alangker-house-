/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

// Code 128 Patterns (Table B)
// Each pattern specifies widths of [bar, space, bar, space, bar, space]
const CODE128_PATTERNS: string[] = [
  "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
  "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
  "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
  "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
  "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
  "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
  "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
  "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
  "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
  "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
  "114131", "311141", "411131", "211412", "211214", "211232", "2331112"
];

const START_B = 104;
const STOP = 106;

/**
 * Generate standard Code 128 (Set B) bars sequence
 */
export function encodeCode128(text: string): { width: number; isBlack: boolean }[] {
  const safeText = text || '000000';
  const codes: number[] = [START_B];

  let checksum = START_B;
  for (let i = 0; i < safeText.length; i++) {
    const codePoint = safeText.charCodeAt(i);
    // Code 128 Set B covers ASCII 32 to 127
    const val = (codePoint >= 32 && codePoint <= 126) ? (codePoint - 32) : 0;
    codes.push(val);
    checksum += val * (i + 1);
  }

  const checkDigit = checksum % 103;
  codes.push(checkDigit);
  codes.push(STOP);

  // Convert pattern strings to bars
  const bars: { width: number; isBlack: boolean }[] = [];
  
  // Add a quiet zone at start (10 units)
  bars.push({ width: 10, isBlack: false });

  codes.forEach((codeIdx) => {
    const pattern = CODE128_PATTERNS[codeIdx] || "212222";
    for (let p = 0; p < pattern.length; p++) {
      const w = parseInt(pattern[p], 10);
      const isBlack = (p % 2 === 0);
      bars.push({ width: w, isBlack });
    }
  });

  // Quiet zone at end
  bars.push({ width: 10, isBlack: false });

  return bars;
}

interface BarcodeRendererProps {
  code: string;
  height?: number;
  showText?: boolean;
  className?: string;
  svgClassName?: string;
  unitWidth?: number;
}

export const BarcodeRenderer: React.FC<BarcodeRendererProps> = ({
  code,
  height = 42,
  showText = true,
  className = '',
  svgClassName = '',
  unitWidth = 1.6,
}) => {
  const cleanCode = (code || '000000').trim();
  const bars = encodeCode128(cleanCode);
  const totalUnits = bars.reduce((acc, b) => acc + b.width, 0);

  let currentX = 0;

  return (
    <div className={`inline-flex flex-col items-center bg-white p-1.5 rounded border border-neutral-300 shadow-sm print:border-none print:shadow-none print:p-0 ${className}`}>
      <svg
        width={totalUnits * unitWidth}
        height={height}
        viewBox={`0 0 ${totalUnits} ${height}`}
        className={`w-full max-w-[220px] print:max-w-none ${svgClassName}`}
        shapeRendering="crispEdges"
      >
        {bars.map((bar, idx) => {
          const x = currentX;
          currentX += bar.width;
          if (!bar.isBlack) return null;
          return (
            <rect
              key={idx}
              x={x}
              y={0}
              width={bar.width}
              height={height}
              fill="#000000"
            />
          );
        })}
      </svg>
      {showText && (
        <span className="font-mono text-[11px] tracking-widest text-neutral-900 font-bold mt-0.5 print:text-[10px]">
          {cleanCode}
        </span>
      )}
    </div>
  );
};
