/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  X,
  Download,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Share2,
  Copy
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface AndroidGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidGuideModal: React.FC<AndroidGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useApp();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  // Capture PWA install prompt
  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  if (!isOpen) return null;

  const appUrl = "https://ais-pre-qydm7drrhc67amxzfbl2dc-221081158606.asia-northeast1.run.app";
  const pwaBuilderUrl = `https://www.pwabuilder.com/?site=${encodeURIComponent(appUrl)}`;

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        showToast('অ্যাপটি আপনার ফোনে ইনস্টল হচ্ছে!');
        setDeferredPrompt(null);
        setIsInstallable(false);
      }
    } else {
      alert('আপনার মোবাইলের Chrome ব্রাউজারের উপরে তিনটি ডট (⋮) মেনুতে গিয়ে "Add to Home screen" বা "Install App" এ চাপ দিন।');
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    showToast('অ্যাপ লিংক কপি হয়েছে! যেকোনো অ্যান্ড্রয়েড ফোনে পাঠিয়ে দিন।');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-[#14120e] border-2 border-amber-500/60 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:px-6 bg-gradient-to-r from-amber-950 via-[#1c1912] to-amber-950 border-b border-amber-800/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-black shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-amber-200">
                অ্যান্ড্রয়েড APK ও মোবাইল অ্যাপ ইনস্টলেশন
              </h3>
              <p className="text-[11px] text-amber-400/80">
                মেসার্স মিঠুন অলংকার হাউজ - জুয়েলারি পিওএস
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs text-neutral-300">
          {/* Direct 1-Click Action Card for APK */}
          <div className="bg-gradient-to-r from-amber-500/20 via-amber-900/30 to-black p-5 rounded-2xl border-2 border-amber-400 shadow-xl space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-black bg-amber-400 px-2 py-0.5 rounded font-mono">
                  সরাসরি APK তৈরি করুন
                </span>
                <h4 className="font-extrabold text-base sm:text-lg text-amber-100 mt-1">
                  PWABuilder দিয়ে ১-ক্লিকে রেডিমেড .APK ডাউনলোড
                </h4>
              </div>
              <Sparkles className="w-6 h-6 text-amber-400 animate-pulse flex-shrink-0" />
            </div>

            <p className="text-xs text-amber-200/90 leading-relaxed">
              মাইক্রোসফট এর অফিশিয়াল টুল দিয়ে আপনার এই জুয়েলারি পিওএস অ্যাপটির সম্পূর্ণ সাইন করা অ্যান্ড্রয়েড <code className="text-amber-300 font-bold font-mono">.apk</code> ফাইল তৈরি করুন:
            </p>

            <div className="pt-1 flex flex-col sm:flex-row gap-2">
              <a
                href={pwaBuilderUrl}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 text-center"
              >
                <Download className="w-4 h-4" />
                PWABuilder এ সরাসরি APK তৈরি করুন &rarr;
              </a>
              <button
                type="button"
                onClick={handleCopyLink}
                className="py-3 px-3 rounded-xl bg-neutral-900 border border-amber-600/50 hover:bg-neutral-800 text-amber-300 font-semibold text-xs flex items-center justify-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                অ্যাপ লিংক কপি
              </button>
            </div>

            <div className="bg-black/60 p-2.5 rounded-lg border border-amber-800/40 text-[11px] text-amber-300/80 space-y-1">
              <p className="font-bold text-amber-200">কীভাবে করবেন (সহজ ৩টি ধাপ):</p>
              <p>১. উপরের <strong>"PWABuilder এ সরাসরি APK তৈরি করুন"</strong> বাটনে ক্লিক করুন।</p>
              <p>২. পেজ খুললে <strong>"Package for Android"</strong> বাটনে চাপ দিন।</p>
              <p>৩. এরপর <strong>"Download Package / APK"</strong> বাটনে চাপলেই আপনার ফোনে <code className="font-mono text-amber-300">.apk</code> ফাইলটি সেভ হয়ে যাবে!</p>
            </div>
          </div>

          {/* Instant 1-Click Native Install Card (PWA) */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/40 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-amber-200 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                তাত্ক্ষণিক মোবাইল অ্যাপ হিসেবে ব্যবহার (PWA Install):
              </h4>
              <span className="text-[10px] text-emerald-300 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-700/50">
                কোনো APK ফাইল ডাউনলোড ছাড়া
              </span>
            </div>

            <p className="text-[11px] text-neutral-300 leading-relaxed">
              আপনার অ্যান্ড্রয়েড ফোনে গুগল ক্রোম ব্রাউজার এই অ্যাপটিকে স্বয়ংক্রিয়ভাবে একটি ফুলস্ক্রিন নেটিভ অ্যাপে রূপান্তর করে ফেলে:
            </p>

            <button
              type="button"
              onClick={handleInstallPWA}
              className="w-full py-2.5 px-4 rounded-xl bg-neutral-900 border border-amber-500/60 hover:bg-amber-950/40 text-amber-300 font-bold text-xs flex items-center justify-center gap-2"
            >
              <Smartphone className="w-4 h-4 text-amber-400" />
              ফোনের হোম স্ক্রিনে অ্যাপটি ইনস্টল করুন
            </button>

            <div className="bg-neutral-950 p-2.5 rounded text-[11px] text-neutral-400 space-y-1">
              <p>• ক্রোম ব্রাউজারের উপরে ডান কোণায় <strong>তিনটি ডট (⋮)</strong> মেনুতে ট্যাপ করুন।</p>
              <p>• <strong>"Add to Home screen" (হোম স্ক্রিনে যোগ করুন)</strong> বা <strong>"Install app"</strong> চাপুন।</p>
              <p>• আপনার মোবাইলের স্ক্রিনে <strong>মিঠুন অলংকার</strong> এর সোনার লোগোসহ অ্যাপ আইকন চলে আসবে।</p>
            </div>
          </div>

          {/* Capacitor Native APK Guide for Developers */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-800/40 space-y-2">
            <h4 className="font-bold text-xs text-amber-300">
              অ্যান্ড্রয়েড স্টুডিও (Android Studio) দিয়ে নিজস্ব APK বানাতে চাইলে:
            </h4>
            <pre className="bg-black p-2.5 rounded border border-amber-900/40 text-[11px] font-mono text-amber-300 overflow-x-auto">
{`npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Mithun Jewelry POS" com.mithunalankar.pos --web-dir dist
npm run build
npx cap add android
npx cap open android`}
            </pre>
          </div>
        </div>

        <div className="p-4 bg-[#14120e] border-t border-amber-800/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs shadow"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
