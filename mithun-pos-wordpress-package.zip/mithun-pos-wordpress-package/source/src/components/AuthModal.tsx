/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  LogIn,
  UserPlus,
  X,
  Mail,
  Lock,
  User,
  ShieldCheck,
  AlertCircle,
  Gem,
  Sparkles
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { loginWithEmail, registerWithEmail, loginDemo, shopProfile } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    if (mode === 'login') {
      const res = await loginWithEmail(email, password);
      setLoading(false);
      if (!res.success) {
        setErrorMsg(res.error || 'লগইন ব্যর্থ হয়েছে।');
      }
    } else {
      const res = await registerWithEmail(email, password, name);
      setLoading(false);
      if (!res.success) {
        setErrorMsg(res.error || 'রেজিস্ট্রেশন ব্যর্থ হয়েছে।');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-800/40 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-950/80 border border-amber-700/50 text-amber-400">
              <Gem className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-200">
                {shopProfile.name}
              </h3>
              <p className="text-[11px] text-amber-400/70">
                {mode === 'login' ? 'নিরাপদ অ্যাকাউন্ট সাইন ইন' : 'নতুন কর্মচারী / এডমিন রেজিস্ট্রেশন'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex rounded-xl bg-neutral-900 p-1 border border-amber-900/40">
          <button
            type="button"
            onClick={() => { setMode('login'); setErrorMsg(null); }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              mode === 'login'
                ? 'bg-amber-500 text-black shadow'
                : 'text-amber-300/70 hover:text-amber-200'
            }`}
          >
            লগইন (Sign In)
          </button>
          <button
            type="button"
            onClick={() => { setMode('register'); setErrorMsg(null); }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              mode === 'register'
                ? 'bg-amber-500 text-black shadow'
                : 'text-amber-300/70 hover:text-amber-200'
            }`}
          >
            রেজিস্ট্রেশন (Sign Up)
          </button>
        </div>

        {errorMsg && (
          <div className="p-2.5 rounded-lg bg-red-950/60 border border-red-800/50 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === 'register' && (
            <div>
              <label className="block text-xs text-amber-300/80 mb-1">পূর্ণ নাম *</label>
              <div className="relative">
                <User className="w-4 h-4 text-amber-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  placeholder="আপনার নাম"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-9 pr-3 py-1.5 text-xs text-amber-100 focus:outline-none"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs text-amber-300/80 mb-1">ইমেইল ঠিকানা *</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-amber-500 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                placeholder="admin@mithunpos.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-9 pr-3 py-1.5 text-xs font-mono text-amber-100 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-amber-300/80 mb-1">গোপন পাসওয়ার্ড *</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-amber-500 absolute left-3 top-2.5" />
              <input
                type="password"
                required
                minLength={6}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-9 pr-3 py-1.5 text-xs font-mono text-amber-100 focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
          >
            {mode === 'login' ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            {loading ? 'যাচাই করা হচ্ছে...' : mode === 'login' ? 'ফায়ারবেসে লগইন করুন' : 'অ্যাকাউন্ট তৈরি করুন'}
          </button>
        </form>

        {/* 1-Click Demo Login Button */}
        <div className="pt-2 border-t border-amber-900/40 text-center space-y-2">
          <p className="text-[11px] text-neutral-400">
            Firebase কনফিগার না করা থাকলেও তাত্ক্ষণিক ডেমো দেখতে চান?
          </p>
          <button
            type="button"
            onClick={loginDemo}
            className="w-full py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-amber-700/50 text-amber-300 text-xs font-semibold flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            ডেমো এডমিন হিসেবে ১-ক্লিকে প্রবেশ করুন (অফলাইন মোড)
          </button>
        </div>
      </div>
    </div>
  );
};
