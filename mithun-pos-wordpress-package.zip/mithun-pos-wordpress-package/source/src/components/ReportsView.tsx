/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatTaka, toBengaliNumber, formatWeightPartsBn } from '../utils/goldCalculator';
import {
  BarChart3,
  TrendingUp,
  ArrowDownLeft,
  Gem,
  Users,
  Calendar,
  Filter,
  Printer,
  FileSpreadsheet
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { invoices, purchases, products, customers } = useApp();

  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'month'>('all');
  const [activeReportTab, setActiveReportTab] = useState<'sales' | 'purchases' | 'stock' | 'dues'>('sales');

  const todayStr = new Date().toISOString().split('T')[0];
  const thisMonthStr = todayStr.slice(0, 7);

  // Filtered Invoices
  const filteredInvoices = invoices.filter(inv => {
    if (dateFilter === 'today') return inv.date.startsWith(todayStr);
    if (dateFilter === 'month') return inv.date.startsWith(thisMonthStr);
    return true;
  });

  // Filtered Purchases
  const filteredPurchases = purchases.filter(p => {
    if (dateFilter === 'today') return p.date.startsWith(todayStr);
    if (dateFilter === 'month') return p.date.startsWith(thisMonthStr);
    return true;
  });

  // Aggregates
  const totalSales = filteredInvoices.reduce((acc, i) => acc + i.grandTotal, 0);
  const totalSalesWeight = filteredInvoices.reduce((acc, i) => acc + i.totalWeightGrams, 0);
  const totalCashIn = filteredInvoices.reduce((acc, i) => acc + i.paidAmount, 0);
  const totalSalesDue = filteredInvoices.reduce((acc, i) => acc + i.dueAmount, 0);

  const totalPurchasesCost = filteredPurchases.reduce((acc, p) => acc + p.totalPrice, 0);
  const totalPurchasedWeight = filteredPurchases.reduce((acc, p) => acc + p.netWeightGrams, 0);

  const totalStockGrams = Math.round(products.reduce((acc, p) => acc + (p.weightGrams * p.stockQuantity), 0) * 1000) / 1000;
  const totalStockValue = products.reduce((acc, p) => acc + (p.sellingPrice * p.stockQuantity), 0);
  const totalOutstandingDue = customers.reduce((acc, c) => acc + c.currentDue, 0);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-800/30 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-amber-400" />
            হিসাব ও ব্যবসায়িক প্রতিবেদন (Reports & Analytics)
          </h2>
          <p className="text-xs text-amber-400/70">
            বিক্রয়, স্বর্ণ ক্রয়, মজুদ মূল্যায়ন ও বকেয়া আদায়ের সমন্বিত রিপোর্ট
          </p>
        </div>

        {/* Date Filter Buttons */}
        <div className="flex items-center gap-1 bg-[#12110c] p-1 rounded-xl border border-amber-800/40">
          <button
            onClick={() => setDateFilter('today')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              dateFilter === 'today' ? 'bg-amber-500 text-black' : 'text-amber-300/80 hover:bg-neutral-800'
            }`}
          >
            আজকের হিসাব
          </button>
          <button
            onClick={() => setDateFilter('month')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              dateFilter === 'month' ? 'bg-amber-500 text-black' : 'text-amber-300/80 hover:bg-neutral-800'
            }`}
          >
            চলতি মাস
          </button>
          <button
            onClick={() => setDateFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              dateFilter === 'all' ? 'bg-amber-500 text-black' : 'text-amber-300/80 hover:bg-neutral-800'
            }`}
          >
            সর্বমোট
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <p className="text-xs text-amber-400/80">মোট বিক্রয়</p>
          <p className="text-xl font-bold font-mono text-amber-200 mt-1">{formatTaka(totalSales)}</p>
          <p className="text-[11px] text-amber-400/70 mt-1">স্বর্ণের ওজন: {toBengaliNumber(totalSalesWeight.toFixed(2))}g</p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <p className="text-xs text-amber-400/80">মোট স্বর্ণ ক্রয়/এক্সচেঞ্জ</p>
          <p className="text-xl font-bold font-mono text-amber-200 mt-1">{formatTaka(totalPurchasesCost)}</p>
          <p className="text-[11px] text-amber-400/70 mt-1">ক্রয়কৃত ওজন: {toBengaliNumber(totalPurchasedWeight.toFixed(2))}g</p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <p className="text-xs text-amber-400/80">বর্তমান স্টক মূল্যায়ন</p>
          <p className="text-xl font-bold font-mono text-amber-200 mt-1">{formatTaka(totalStockValue)}</p>
          <p className="text-[11px] text-amber-400/70 mt-1">স্টক ওজন: {toBengaliNumber(totalStockGrams)}g</p>
        </div>

        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30">
          <p className="text-xs text-red-400">সর্বমোট বকেয়া পাওনা</p>
          <p className="text-xl font-bold font-mono text-red-300 mt-1">{formatTaka(totalOutstandingDue)}</p>
          <p className="text-[11px] text-neutral-400 mt-1">গ্রাহক সংখ্যা: {toBengaliNumber(customers.filter(c => c.currentDue > 0).length)} জন</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-amber-800/40 gap-2">
        <button
          onClick={() => setActiveReportTab('sales')}
          className={`pb-2 px-3 text-xs font-bold border-b-2 transition-all ${
            activeReportTab === 'sales' ? 'border-amber-400 text-amber-300' : 'border-transparent text-amber-400/60'
          }`}
        >
          বিক্রয় রিপোর্ট ({toBengaliNumber(filteredInvoices.length)})
        </button>
        <button
          onClick={() => setActiveReportTab('purchases')}
          className={`pb-2 px-3 text-xs font-bold border-b-2 transition-all ${
            activeReportTab === 'purchases' ? 'border-amber-400 text-amber-300' : 'border-transparent text-amber-400/60'
          }`}
        >
          স্বর্ণ ক্রয় রিপোর্ট ({toBengaliNumber(filteredPurchases.length)})
        </button>
        <button
          onClick={() => setActiveReportTab('stock')}
          className={`pb-2 px-3 text-xs font-bold border-b-2 transition-all ${
            activeReportTab === 'stock' ? 'border-amber-400 text-amber-300' : 'border-transparent text-amber-400/60'
          }`}
        >
          স্টক ইনভেন্টরি রিপোর্ট
        </button>
        <button
          onClick={() => setActiveReportTab('dues')}
          className={`pb-2 px-3 text-xs font-bold border-b-2 transition-all ${
            activeReportTab === 'dues' ? 'border-amber-400 text-amber-300' : 'border-transparent text-amber-400/60'
          }`}
        >
          বকেয়া তালিকা রিপোর্ট
        </button>
      </div>

      {/* Report Tables */}
      <div className="bg-[#12110c] rounded-2xl border border-amber-800/40 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          {activeReportTab === 'sales' && (
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-amber-950/40 text-amber-300/90 border-b border-amber-800/30">
                <tr>
                  <th className="p-3">মেমো নং</th>
                  <th className="p-3">তারিখ</th>
                  <th className="p-3">ক্রেতা</th>
                  <th className="p-3">ওজন (গ্রাম)</th>
                  <th className="p-3 text-right">সর্বমোট (৳)</th>
                  <th className="p-3 text-right">নগদ জমা (৳)</th>
                  <th className="p-3 text-right">বকেয়া (৳)</th>
                  <th className="p-3 text-center">মাধ্যম</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-950/60 text-amber-100">
                {filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-amber-950/20">
                    <td className="p-3 font-mono font-bold text-amber-300">{inv.memoNumber}</td>
                    <td className="p-3 font-mono text-neutral-400">{new Date(inv.date).toLocaleDateString('bn-BD')}</td>
                    <td className="p-3 font-medium">{inv.customerName}</td>
                    <td className="p-3 font-mono">{toBengaliNumber(inv.totalWeightGrams)}g</td>
                    <td className="p-3 text-right font-mono font-bold">{formatTaka(inv.grandTotal)}</td>
                    <td className="p-3 text-right font-mono text-emerald-400">{formatTaka(inv.paidAmount)}</td>
                    <td className={`p-3 text-right font-mono font-bold ${inv.dueAmount > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {formatTaka(inv.dueAmount)}
                    </td>
                    <td className="p-3 text-center">
                      <span className="text-[10px] bg-neutral-800 px-2 py-0.5 rounded text-neutral-300 border border-neutral-700">
                        {inv.paymentMethod}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'purchases' && (
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-amber-950/40 text-amber-300/90 border-b border-amber-800/30">
                <tr>
                  <th className="p-3">ভাউচার নং</th>
                  <th className="p-3">তারিখ</th>
                  <th className="p-3">বিক্রেতা</th>
                  <th className="p-3">বিবরণ</th>
                  <th className="p-3">নিট ওজন</th>
                  <th className="p-3 text-right">দর (টাকা/ভরি)</th>
                  <th className="p-3 text-right">মূল্য (৳)</th>
                  <th className="p-3 text-right">পরিশোধ (৳)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-950/60 text-amber-100">
                {filteredPurchases.map((p) => (
                  <tr key={p.id} className="hover:bg-amber-950/20">
                    <td className="p-3 font-mono font-bold text-amber-300">{p.voucherNumber}</td>
                    <td className="p-3 font-mono text-neutral-400">{new Date(p.date).toLocaleDateString('bn-BD')}</td>
                    <td className="p-3 font-semibold">{p.sellerName}</td>
                    <td className="p-3">{p.itemName} ({p.karat})</td>
                    <td className="p-3 font-mono">{toBengaliNumber(p.netWeightGrams)}g</td>
                    <td className="p-3 text-right font-mono text-neutral-300">
                      ৳{toBengaliNumber(p.ratePerBhori.toLocaleString('en-IN'))}
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-amber-300">{formatTaka(p.totalPrice)}</td>
                    <td className="p-3 text-right font-mono text-emerald-400 font-bold">{formatTaka(p.paidAmount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'stock' && (
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-amber-950/40 text-amber-300/90 border-b border-amber-800/30">
                <tr>
                  <th className="p-3">প্রোডাক্ট কোড</th>
                  <th className="p-3">গহনার নাম</th>
                  <th className="p-3">ক্যারেট</th>
                  <th className="p-3">প্রতিটির ওজন</th>
                  <th className="p-3 text-center">মজুদ সংখ্যা</th>
                  <th className="p-3 text-right">প্রতিটির মূল্য</th>
                  <th className="p-3 text-right">মোট মজুদ মূল্য</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-950/60 text-amber-100">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-amber-950/20">
                    <td className="p-3 font-mono font-bold text-amber-300">{p.code}</td>
                    <td className="p-3 font-semibold text-amber-200">{p.name}</td>
                    <td className="p-3 font-bold">{p.karat}</td>
                    <td className="p-3 font-mono">{toBengaliNumber(p.weightGrams)} গ্রাম</td>
                    <td className="p-3 text-center font-mono font-bold">{toBengaliNumber(p.stockQuantity)} টি</td>
                    <td className="p-3 text-right font-mono">{formatTaka(p.sellingPrice)}</td>
                    <td className="p-3 text-right font-mono font-bold text-amber-300">
                      {formatTaka(p.sellingPrice * p.stockQuantity)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'dues' && (
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-amber-950/40 text-amber-300/90 border-b border-amber-800/30">
                <tr>
                  <th className="p-3">গ্রাহকের নাম</th>
                  <th className="p-3">মোবাইল</th>
                  <th className="p-3">ঠিকানা</th>
                  <th className="p-3 text-right">মোট কেনাকাটা</th>
                  <th className="p-3 text-right">মোট পরিশোধ</th>
                  <th className="p-3 text-right">বর্তমান বকেয়া (৳)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-950/60 text-amber-100">
                {customers.filter(c => c.currentDue > 0).map((c) => (
                  <tr key={c.id} className="hover:bg-amber-950/20">
                    <td className="p-3 font-bold text-amber-200">{c.name}</td>
                    <td className="p-3 font-mono text-neutral-300">{c.phone}</td>
                    <td className="p-3 text-neutral-400">{c.address}</td>
                    <td className="p-3 text-right font-mono">{formatTaka(c.totalSpent)}</td>
                    <td className="p-3 text-right font-mono text-emerald-400">{formatTaka(c.totalPaid)}</td>
                    <td className="p-3 text-right font-mono font-bold text-red-400 text-sm">{formatTaka(c.currentDue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
