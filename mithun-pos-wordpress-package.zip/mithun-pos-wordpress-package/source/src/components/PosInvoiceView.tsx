/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Product,
  InvoiceItem,
  PaymentMethod,
  KaratType,
  GoldWeightParts,
  Invoice
} from '../types';
import {
  calculateGoldPrice,
  formatTaka,
  toBengaliNumber,
  formatWeightPartsBn,
} from '../utils/goldCalculator';
import {
  ReceiptText,
  Plus,
  Trash2,
  Printer,
  Search,
  UserCheck,
  Gem,
  Sparkles,
  ShoppingBag,
  Camera,
  Barcode,
  X,
  CheckCircle2,
  AlertTriangle,
  Volume2
} from 'lucide-react';

export const PosInvoiceView: React.FC = () => {
  const {
    products,
    customers,
    rates,
    createInvoice,
    calculatorTransferItem,
    clearCalculatorTransferItem,
    user
  } = useApp();

  // Customer info
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  // Invoice Items
  const [items, setItems] = useState<InvoiceItem[]>([]);

  // Barcode Scanning State
  const [barcodeSearch, setBarcodeSearch] = useState<string>('');
  const barcodeInputRef = useRef<HTMLInputElement | null>(null);
  const [scanNotification, setScanNotification] = useState<{
    type: 'success' | 'warning' | 'error';
    message: string;
  } | null>(null);

  // Camera Barcode Scanner State
  const [isCameraScannerOpen, setIsCameraScannerOpen] = useState(false);
  const scannerVideoRef = useRef<HTMLVideoElement | null>(null);
  const scannerStreamRef = useRef<MediaStream | null>(null);
  const scanIntervalRef = useRef<number | null>(null);

  // Custom Item Drawer/Fields
  const [customItemName, setCustomItemName] = useState('২২ ক্যারেট সোনার গহনা');
  const [customKarat, setCustomKarat] = useState<KaratType>('22K');
  const [customBhori, setCustomBhori] = useState('0');
  const [customAna, setCustomAna] = useState('8');
  const [customRoti, setCustomRoti] = useState('0');
  const [customPoint, setCustomPoint] = useState('0');
  const [customMakingCharge, setCustomMakingCharge] = useState('2500');
  const [customStonePrice, setCustomStonePrice] = useState('0');

  // Overall Discount & Payment
  const [overallDiscount, setOverallDiscount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('নগদ');
  const [memoNotes, setMemoNotes] = useState('');

  // Auto-focus barcode input on view load
  useEffect(() => {
    barcodeInputRef.current?.focus();
  }, []);

  // Web Audio POS Beep
  const playScanBeep = () => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1900, ctx.currentTime);
      gain.gain.setValueAtTime(0.25, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } catch (e) {
      console.debug('Beep blocked or unsupported', e);
    }
  };

  // Auto-populate when transfer item comes from calculator
  useEffect(() => {
    if (calculatorTransferItem) {
      const newItem: InvoiceItem = {
        id: `calc-item-${Date.now()}`,
        productName: calculatorTransferItem.productName || 'কাস্টম অলংকার',
        productCode: calculatorTransferItem.productCode || `CST-${Date.now().toString().slice(-4)}`,
        karat: calculatorTransferItem.karat || '22K',
        metalType: calculatorTransferItem.metalType || 'স্বর্ণ',
        weightParts: calculatorTransferItem.weightParts || { bhori: 1, ana: 0, roti: 0, point: 0 },
        weightGrams: calculatorTransferItem.weightGrams || 11.664,
        ratePerBhori: calculatorTransferItem.ratePerBhori || rates['22K'] || 130000,
        goldBasePrice: calculatorTransferItem.goldBasePrice || 130000,
        makingCharge: calculatorTransferItem.makingCharge || 3500,
        stonePrice: calculatorTransferItem.stonePrice || 0,
        itemTotal: calculatorTransferItem.itemTotal || 133500,
        quantity: 1,
      };
      setItems(prev => [newItem, ...prev]);
      clearCalculatorTransferItem();
    }
  }, [calculatorTransferItem, clearCalculatorTransferItem, rates]);

  // Handle phone auto-complete matching customer
  const handlePhoneChange = (val: string) => {
    setCustomerPhone(val);
    const matched = customers.find(c => c.phone.trim() === val.trim());
    if (matched) {
      setCustomerName(matched.name);
      setCustomerAddress(matched.address);
    }
  };

  // Add stock product to cart
  const handleAddStockProduct = (product: Product, triggeredByScan = false) => {
    const existing = items.find(i => i.productId === product.id);
    if (existing) {
      setItems(items.map(i => i.productId === product.id ? { ...i, quantity: i.quantity + 1, itemTotal: i.itemTotal + product.sellingPrice } : i));
    } else {
      const item: InvoiceItem = {
        id: `inv-item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        productId: product.id,
        imageUrl: product.imageUrl,
        productName: product.name,
        productCode: product.code,
        karat: product.karat,
        metalType: product.metalType || 'স্বর্ণ',
        weightParts: product.weightParts,
        weightGrams: product.weightGrams,
        ratePerBhori: rates[product.karat] || 130000,
        goldBasePrice: Math.round(product.sellingPrice * 0.9),
        makingCharge: Math.round(product.sellingPrice * 0.1),
        stonePrice: 0,
        itemTotal: product.sellingPrice,
        quantity: 1,
      };
      setItems(prev => [item, ...prev]);
    }

    if (triggeredByScan) {
      playScanBeep();
      setScanNotification({
        type: 'success',
        message: `✓ "${product.name}" স্ক্যান করে মেমোতে যোগ করা হয়েছে!`,
      });
      setTimeout(() => setScanNotification(null), 3000);
    }
  };

  // Core Barcode Scanning Processor (Scanner gun or input)
  const processBarcodeScan = (codeToSearch: string) => {
    const clean = codeToSearch.trim();
    if (!clean) return;

    const matchedProduct = products.find(
      (p) =>
        p.barcode.trim() === clean ||
        p.barcode.toLowerCase() === clean.toLowerCase() ||
        p.code.toLowerCase() === clean.toLowerCase()
    );

    if (matchedProduct) {
      handleAddStockProduct(matchedProduct, true);
      setBarcodeSearch('');
      // Keep input focused for consecutive rapid scanning
      setTimeout(() => {
        barcodeInputRef.current?.focus();
      }, 50);
    } else {
      setScanNotification({
        type: 'error',
        message: `বারকোড "${clean}" এর কোনো অলংকার স্টকে পাওয়া যায়নি!`,
      });
      setTimeout(() => setScanNotification(null), 3500);
    }
  };

  // Form submit for barcode scanner (handles scanner gun "Enter")
  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    processBarcodeScan(barcodeSearch);
  };

  // Camera Barcode Scanner Lifecycle
  const stopCameraScanner = () => {
    if (scanIntervalRef.current) {
      window.clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    if (scannerStreamRef.current) {
      scannerStreamRef.current.getTracks().forEach(t => t.stop());
      scannerStreamRef.current = null;
    }
    setIsCameraScannerOpen(false);
  };

  const startCameraScanner = async () => {
    try {
      stopCameraScanner();
      setIsCameraScannerOpen(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      scannerStreamRef.current = stream;

      setTimeout(() => {
        if (scannerVideoRef.current) {
          scannerVideoRef.current.srcObject = stream;
          scannerVideoRef.current.play().catch(console.error);

          // Native BarcodeDetector if available
          const hasBarcodeDetector = 'BarcodeDetector' in window;
          if (hasBarcodeDetector) {
            try {
              const detector = new (window as any).BarcodeDetector({
                formats: ['code_128', 'code_39', 'ean_13', 'ean_8', 'qr_code']
              });

              scanIntervalRef.current = window.setInterval(async () => {
                if (scannerVideoRef.current && scannerVideoRef.current.readyState >= 2) {
                  try {
                    const detected = await detector.detect(scannerVideoRef.current);
                    if (detected && detected.length > 0) {
                      const detectedCode = detected[0].rawValue;
                      if (detectedCode) {
                        processBarcodeScan(detectedCode);
                        stopCameraScanner();
                      }
                    }
                  } catch (e) {
                    // ignore frame detection error
                  }
                }
              }, 300);
            } catch (err) {
              console.warn('BarcodeDetector instantiation error:', err);
            }
          }
        }
      }, 200);
    } catch (err) {
      console.warn('Camera barcode scanner error:', err);
      alert('ক্যামেরা চালু করা সম্ভব হয়নি। ডিভাইস পারমিশন চেক করুন অথবা বারকোড টাইপ/স্ক্যানার ব্যবহার করুন।');
      setIsCameraScannerOpen(false);
    }
  };

  useEffect(() => {
    return () => {
      stopCameraScanner();
    };
  }, []);

  // Add custom gold item
  const handleAddCustomItem = () => {
    const parts: GoldWeightParts = {
      bhori: parseFloat(customBhori) || 0,
      ana: parseFloat(customAna) || 0,
      roti: parseFloat(customRoti) || 0,
      point: parseFloat(customPoint) || 0,
    };
    const rate = rates[customKarat] || 130000;
    const calc = calculateGoldPrice({
      weightParts: parts,
      ratePerBhori: rate,
      makingChargeFixed: parseFloat(customMakingCharge) || 0,
      stonePrice: parseFloat(customStonePrice) || 0,
    });

    const newItem: InvoiceItem = {
      id: `custom-item-${Date.now()}`,
      productName: customItemName || `${customKarat} কাস্টম গহনা`,
      productCode: `CST-${customKarat}-${Math.floor(1000 + Math.random() * 9000)}`,
      karat: customKarat,
      metalType: 'স্বর্ণ',
      weightParts: parts,
      weightGrams: calc.totalGrams,
      ratePerBhori: rate,
      goldBasePrice: calc.goldBasePrice,
      makingCharge: calc.totalMakingCharge,
      stonePrice: calc.stonePrice,
      itemTotal: calc.grandTotal,
      quantity: 1,
    };

    setItems([newItem, ...items]);
    // Reset custom item fields
    setCustomItemName('২২ ক্যারেট সোনার গহনা');
    setCustomBhori('0');
    setCustomAna('8');
    setCustomRoti('0');
    setCustomPoint('0');
  };

  // Remove item
  const handleRemoveItem = (id: string) => {
    setItems(items.filter(i => i.id !== id));
  };

  // Totals calculation
  const subtotal = items.reduce((acc, i) => acc + i.itemTotal, 0);
  const totalWeightGrams = Math.round(items.reduce((acc, i) => acc + (i.weightGrams * i.quantity), 0) * 1000) / 1000;
  
  // Aggregate weight parts
  const totalBhoriParts: GoldWeightParts = {
    bhori: items.reduce((acc, i) => acc + (i.weightParts.bhori * i.quantity), 0),
    ana: items.reduce((acc, i) => acc + (i.weightParts.ana * i.quantity), 0),
    roti: items.reduce((acc, i) => acc + (i.weightParts.roti * i.quantity), 0),
    point: items.reduce((acc, i) => acc + (i.weightParts.point * i.quantity), 0),
  };

  const grandTotal = Math.max(0, subtotal - overallDiscount);
  const dueAmount = Math.max(0, grandTotal - paidAmount);

  // Auto set paid amount to grand total if not yet customized
  useEffect(() => {
    if (paidAmount === 0 && grandTotal > 0 && items.length > 0) {
      setPaidAmount(grandTotal);
    }
  }, [grandTotal]);

  // Submit Invoice
  const handleGenerateInvoice = () => {
    if (items.length === 0) {
      alert('দয়া করে অন্তত একটি পণ্য বা অলংকার ক্যাশ মেমোতে যোগ করুন।');
      return;
    }
    if (!customerName.trim()) {
      alert('দয়া করে ক্রেতার নাম লিখুন।');
      return;
    }

    const memoNumber = `MEMO-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(100 + Math.random() * 900))}`;

    const newInvoice: Invoice = {
      id: `inv-${Date.now()}`,
      memoNumber,
      date: new Date().toISOString(),
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }),
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim() || '০১৭xxxxxxxx',
      customerAddress: customerAddress.trim() || 'চালাকচর, মনোহরদী',
      items,
      totalWeightGrams,
      totalWeightParts: totalBhoriParts,
      subtotal,
      discount: overallDiscount,
      vatAmount: 0,
      grandTotal,
      paidAmount,
      dueAmount,
      paymentMethod,
      notes: memoNotes,
      createdBy: user?.displayName || 'মিঠুন কর্মকার',
      status: dueAmount === 0 ? 'পরিশোধিত' : paidAmount === 0 ? 'সম্পূর্ণ বকেয়া' : 'আংশিক বকেয়া',
    };

    createInvoice(newInvoice);

    // Reset Form
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    setItems([]);
    setOverallDiscount(0);
    setPaidAmount(0);
    setMemoNotes('');
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Scan Feedback Banner */}
      {scanNotification && (
        <div
          className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-between shadow-lg transition-all ${
            scanNotification.type === 'success'
              ? 'bg-emerald-950/90 border-emerald-500 text-emerald-200'
              : scanNotification.type === 'warning'
              ? 'bg-amber-950/90 border-amber-500 text-amber-200'
              : 'bg-red-950/90 border-red-500 text-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {scanNotification.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            ) : scanNotification.type === 'warning' ? (
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            ) : (
              <X className="w-5 h-5 text-red-400" />
            )}
            <span>{scanNotification.message}</span>
          </div>
          <button
            onClick={() => setScanNotification(null)}
            className="text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* View Header with Instant Barcode Scanner Integration */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-amber-800/30 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <ReceiptText className="w-6 h-6 text-amber-400" />
            বিক্রয় ক্যাশ মেমো (POS Billing)
          </h2>
          <p className="text-xs text-amber-400/70">
            ঝটপট বারকোড স্ক্যান, অটো-সেলস অ্যাড, স্বর্ণের হিসাব, স্টক সমন্বয় ও গ্রাহক বকেয়া হিসাব
          </p>
        </div>

        {/* Quick Barcode Scanner Form */}
        <div className="w-full md:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <form onSubmit={handleBarcodeSubmit} className="flex items-center gap-2">
            <div className="relative flex-1 sm:w-72">
              <Barcode className="w-4 h-4 text-amber-400 absolute left-3 top-2.5" />
              <input
                ref={barcodeInputRef}
                type="text"
                placeholder="বারকোড স্ক্যানার গান দিয়ে স্ক্যান করুন..."
                value={barcodeSearch}
                onChange={(e) => setBarcodeSearch(e.target.value)}
                className="w-full bg-[#12110c] border-2 border-amber-500/70 rounded-xl pl-9 pr-3 py-1.5 text-xs text-amber-100 placeholder-amber-400/50 focus:border-amber-400 focus:outline-none focus:ring-1 focus:ring-amber-400/40 font-mono shadow-inner"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs flex items-center gap-1 shadow active:scale-95 whitespace-nowrap"
            >
              যোগ করুন
            </button>
          </form>

          {/* Camera Barcode Scanner Trigger */}
          <button
            type="button"
            onClick={startCameraScanner}
            className="px-3 py-1.5 rounded-xl bg-neutral-900 border border-amber-500/60 hover:bg-amber-950/40 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 shadow active:scale-95"
            title="মোবাইল বা পিসির ক্যামেরা দিয়ে বারকোড স্ক্যান করুন"
          >
            <Camera className="w-3.5 h-3.5 text-amber-400" />
            <span>ক্যামেরা স্ক্যান</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Customer & Item Selection */}
        <div className="lg:col-span-7 space-y-5">
          {/* Customer Details Card */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-amber-400" />
                ক্রেতার তথ্য (Customer Info)
              </h3>
              <span className="text-[11px] text-amber-400/70">মোবাইল দিলে পূর্বের হিসাব চলে আসবে</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-amber-400/80 mb-1">মোবাইল নম্বর *</label>
                <input
                  type="text"
                  placeholder="০১৭১১xxxxxx"
                  value={customerPhone}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100 font-mono focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] text-amber-400/80 mb-1">ক্রেতার নাম *</label>
                <input
                  type="text"
                  placeholder="নাম লিখুন"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] text-amber-400/80 mb-1">ঠিকানা / এলাকা</label>
                <input
                  type="text"
                  placeholder="ঠিকানা"
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg px-3 py-1.5 text-xs text-amber-100 focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Stock Product Selector with Photo Preview */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <ShoppingBag className="w-4 h-4 text-amber-400" />
                মজুদ গহনা থেকে সরাসরি নির্বাচন করুন:
              </h3>
              <span className="text-[10px] text-amber-400/70 font-mono">
                ক্লিক করলে সরাসরি মেমোতে যোগ হবে
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
              {products.filter(p => p.stockQuantity > 0).map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => handleAddStockProduct(prod, false)}
                  className="p-2 rounded-lg bg-neutral-900/80 border border-amber-900/50 hover:border-amber-500/80 hover:bg-amber-950/30 cursor-pointer flex items-center justify-between transition-all group"
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    {/* Thumbnail Image */}
                    {prod.imageUrl ? (
                      <div className="w-10 h-10 rounded-md overflow-hidden bg-black shrink-0 border border-amber-500/40">
                        <img
                          src={prod.imageUrl}
                          alt={prod.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>
                    ) : (
                      <div className="w-10 h-10 rounded-md bg-neutral-800 border border-amber-900/40 flex items-center justify-center shrink-0 text-amber-500/60">
                        <Gem className="w-4 h-4" />
                      </div>
                    )}

                    <div className="overflow-hidden">
                      <p className="text-xs font-semibold text-amber-200 truncate">{prod.name}</p>
                      <p className="text-[10px] text-amber-400/70 font-mono">
                        {prod.karat} | {toBengaliNumber(prod.weightGrams)}g | স্টক: {toBengaliNumber(prod.stockQuantity)}টি
                      </p>
                    </div>
                  </div>

                  <div className="text-right pl-2 shrink-0">
                    <p className="text-xs font-bold font-mono text-amber-300">{formatTaka(prod.sellingPrice)}</p>
                    <span className="text-[10px] text-amber-400 bg-amber-950/80 px-1.5 py-0.5 rounded border border-amber-700/40 inline-flex items-center gap-0.5">
                      <Plus className="w-2.5 h-2.5" /> যোগ
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Gold Item Add Form */}
          <div className="bg-[#12110c] p-4 rounded-xl border border-amber-700/30 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                কাস্টম অর্ডার / নতুন গহনা যোগ করুন
              </h3>
              <span className="text-[10px] text-amber-400/80">স্টকে না থাকলেও সরাসরি মেমোতে যোগ হবে</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
              <div className="sm:col-span-5">
                <label className="block text-[10px] text-amber-400/70">গহনার নাম / বিবরণ</label>
                <input
                  type="text"
                  value={customItemName}
                  onChange={(e) => setCustomItemName(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-amber-100"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-[10px] text-amber-400/70">ক্যারেট</label>
                <select
                  value={customKarat}
                  onChange={(e) => setCustomKarat(e.target.value as KaratType)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-amber-100"
                >
                  <option value="24K">24K</option>
                  <option value="22K">22K</option>
                  <option value="21K">21K</option>
                  <option value="18K">18K</option>
                  <option value="সনাতন">সনাতন</option>
                </select>
              </div>

              <div className="sm:col-span-4">
                <label className="block text-[10px] text-amber-400/70">মজুরি (৳)</label>
                <input
                  type="number"
                  value={customMakingCharge}
                  onChange={(e) => setCustomMakingCharge(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-amber-100 font-mono"
                />
              </div>
            </div>

            {/* Custom Weight inputs */}
            <div className="grid grid-cols-4 gap-2 pt-1">
              <div>
                <label className="block text-[10px] text-amber-400/70">ভরি:</label>
                <input
                  type="number"
                  min="0"
                  value={customBhori}
                  onChange={(e) => setCustomBhori(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-center text-amber-100 font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] text-amber-400/70">আনা:</label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  value={customAna}
                  onChange={(e) => setCustomAna(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-center text-amber-100 font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] text-amber-400/70">রতি:</label>
                <input
                  type="number"
                  min="0"
                  max="5"
                  value={customRoti}
                  onChange={(e) => setCustomRoti(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-center text-amber-100 font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] text-amber-400/70">পয়েন্ট:</label>
                <input
                  type="number"
                  min="0"
                  value={customPoint}
                  onChange={(e) => setCustomPoint(e.target.value)}
                  className="w-full bg-neutral-900 border border-amber-600/40 rounded px-2 py-1 text-xs text-center text-amber-100 font-mono"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={handleAddCustomItem}
              className="w-full py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-300 font-medium text-xs flex items-center justify-center gap-1.5 border border-amber-700/40"
            >
              <Plus className="w-3.5 h-3.5" />
              কাস্টম অলংকার মেমোতে যোগ করুন
            </button>
          </div>
        </div>

        {/* Right Column: Invoice Cart & Checkout */}
        <div className="lg:col-span-5 bg-gradient-to-br from-[#18150e] via-[#12110c] to-[#0c0a08] p-5 rounded-2xl border-2 border-amber-500/40 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-amber-700/40 pb-3">
            <h3 className="font-bold text-base text-amber-200 flex items-center gap-2">
              <ReceiptText className="w-5 h-5 text-amber-400" />
              মেমোর পণ্য তালিকা ({toBengaliNumber(items.length)})
            </h3>
            <span className="text-xs text-amber-400 font-mono font-bold">
              মোট ওজন: {toBengaliNumber(totalWeightGrams)} গ্রাম
            </span>
          </div>

          {/* Items List */}
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {items.length === 0 ? (
              <div className="text-center py-8 text-neutral-500 text-xs border border-dashed border-amber-900/40 rounded-xl space-y-1">
                <p>কোনো পণ্য যোগ করা হয়নি।</p>
                <p className="text-[11px] text-amber-400/60">
                  বারকোড স্ক্যানার গান দিয়ে স্ক্যান করলেই স্বয়ংক্রিয়ভাবে এখানে চলে আসবে!
                </p>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  className="p-2.5 rounded-lg bg-neutral-900/90 border border-amber-900/60 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    {/* Item photo if available */}
                    {item.imageUrl ? (
                      <div className="w-9 h-9 rounded overflow-hidden bg-black shrink-0 border border-amber-500/40">
                        <img
                          src={item.imageUrl}
                          alt={item.productName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : null}

                    <div className="overflow-hidden">
                      <p className="text-xs font-bold text-amber-200 truncate">
                        {item.productName}
                        {item.quantity > 1 && (
                          <span className="ml-1.5 px-1.5 py-0.2 bg-amber-500 text-black text-[10px] font-bold rounded">
                            × {toBengaliNumber(item.quantity)}
                          </span>
                        )}
                      </p>
                      <p className="text-[10px] text-amber-400/80 flex items-center gap-1">
                        {item.metalType === 'রূপা' ? (
                          <span className="bg-slate-700 text-slate-200 px-1 py-0.2 rounded text-[9px] font-bold">রূপা</span>
                        ) : (
                          <span className="bg-amber-900/80 text-amber-300 px-1 py-0.2 rounded text-[9px] font-bold">স্বর্ণ</span>
                        )}
                        <span>{item.karat} | {formatWeightPartsBn(item.weightParts)} ({toBengaliNumber(item.weightGrams)}g)</span>
                      </p>
                      <p className="text-[10px] text-neutral-400">
                        মজুরি: {formatTaka(item.makingCharge)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="font-mono text-xs font-bold text-amber-300">
                      {formatTaka(item.itemTotal)}
                    </span>
                    <button
                      onClick={() => handleRemoveItem(item.id)}
                      aria-label="মুছে ফেলুন"
                      className="p-1 rounded text-red-400 hover:text-red-300 hover:bg-red-950/40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Pricing Breakdown */}
          <div className="space-y-2 pt-2 border-t border-amber-800/40 text-xs">
            <div className="flex justify-between text-amber-300/80">
              <span>উপমোট (Subtotal):</span>
              <span className="font-mono font-semibold">{formatTaka(subtotal)}</span>
            </div>

            <div className="flex items-center justify-between gap-2">
              <span className="text-amber-300/80">বিশেষ ছাড় (Discount ৳):</span>
              <input
                type="number"
                min="0"
                value={overallDiscount}
                onChange={(e) => setOverallDiscount(parseFloat(e.target.value) || 0)}
                className="w-24 bg-neutral-900 border border-amber-600/40 rounded px-2 py-0.5 text-right font-mono text-emerald-400 focus:outline-none"
              />
            </div>

            <div className="flex justify-between text-amber-200 font-bold text-sm pt-1 border-t border-amber-900/50">
              <span>সর্বমোট প্রদেয় মূল্য:</span>
              <span className="font-mono text-amber-300 text-base">{formatTaka(grandTotal)}</span>
            </div>

            {/* Payment & Dues */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="block text-[11px] text-emerald-400 font-semibold mb-1">
                  নগদ জমা / পেইড (৳):
                </label>
                <input
                  type="number"
                  min="0"
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-900 border border-emerald-600/50 rounded-lg px-2.5 py-1 text-sm font-mono text-emerald-300 font-bold focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] text-red-400 font-semibold mb-1">
                  বকেয়া পাওনা (৳):
                </label>
                <div className="w-full bg-neutral-950 border border-red-800/50 rounded-lg px-2.5 py-1 text-sm font-mono text-red-300 font-bold">
                  {formatTaka(dueAmount)}
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="pt-2">
              <label className="block text-[11px] text-amber-300 font-semibold mb-1">
                পেমেন্ট মাধ্যম:
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['নগদ', 'বিকাশ', 'নগদ/রকেট', 'ব্যাংক ট্রান্সফার', 'কার্ড'] as PaymentMethod[]).slice(0, 3).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setPaymentMethod(m)}
                    className={`py-1 px-2 rounded text-xs font-semibold border ${
                      paymentMethod === m
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'bg-neutral-900 text-amber-200 border-amber-900/50 hover:bg-neutral-800'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Memo Note */}
            <div>
              <input
                type="text"
                placeholder="মেমোর বিশেষ মন্তব্য বা নোট..."
                value={memoNotes}
                onChange={(e) => setMemoNotes(e.target.value)}
                className="w-full bg-neutral-900 border border-amber-800/30 rounded px-2.5 py-1 text-xs text-amber-200 placeholder-neutral-500"
              />
            </div>
          </div>

          {/* Action Button: Create and Print Memo */}
          <button
            type="button"
            onClick={handleGenerateInvoice}
            disabled={items.length === 0}
            className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xl transition-all ${
              items.length > 0
                ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black cursor-pointer shadow-amber-950/60 active:scale-[0.98]'
                : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
            }`}
          >
            <Printer className="w-5 h-5" />
            ক্যাশ মেমো সম্পন্ন ও প্রিন্ট করুন
          </button>
        </div>
      </div>

      {/* Camera Barcode Scanner Modal */}
      {isCameraScannerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="bg-[#14120e] border border-amber-500/70 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-2">
              <h4 className="font-bold text-sm text-amber-200 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-amber-400" />
                বারকোড স্ক্যানার (লাইভ ক্যামেরা)
              </h4>
              <button
                onClick={stopCameraScanner}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative rounded-xl overflow-hidden bg-black aspect-square flex items-center justify-center border-2 border-amber-500/50">
              <video
                ref={scannerVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              {/* Aiming Reticle */}
              <div className="absolute inset-8 border-2 border-amber-400/80 rounded-lg pointer-events-none flex items-center justify-center">
                <div className="w-full h-0.5 bg-red-500/80 animate-pulse"></div>
              </div>
            </div>

            <p className="text-center text-[11px] text-amber-400/80">
              অলংকারের বারকোডটি লাল লাইনের সামনে ধরুন। স্ক্যান হওয়ার সাথে সাথে মেমোতে যোগ হবে।
            </p>

            <button
              type="button"
              onClick={stopCameraScanner}
              className="w-full py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
