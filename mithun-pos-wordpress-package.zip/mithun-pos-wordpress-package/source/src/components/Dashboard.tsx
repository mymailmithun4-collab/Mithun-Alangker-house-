/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  TrendingUp,
  ShoppingBag,
  Coins,
  Users,
  ReceiptText,
  Calculator,
  PlusCircle,
  ArrowDownLeft,
  Calendar,
  Gem,
  ArrowUpRight,
  Smartphone,
  ShieldCheck,
  Printer,
  Sparkles,
  Clock,
  RotateCcw,
  AlertCircle
} from 'lucide-react';
import {
  formatTaka,
  toBengaliNumber,
  formatWeightPartsBn,
  GoldWeightParts
} from '../utils/goldCalculator';

export const Dashboard: React.FC = () => {
  const {
    invoices,
    purchases,
    products,
    customers,
    orders,
    mortgages,
    rates,
    updateRates,
    setActiveTab,
    setInvoiceToPrint,
    setIsPrintModalOpen,
    setIsAndroidModalOpen,
    clearAllShopData,
    shopProfile
  } = useApp();

  // Live dynamic clock updating every second
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const banglaDate = currentTime.toLocaleDateString('bn-BD', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const banglaTime = currentTime.toLocaleTimeString('bn-BD', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  // State for quick rate edit modal / drawer
  const [isEditingRates, setIsEditingRates] = useState(false);
  const [tempRates, setTempRates] = useState({ ...rates });

  // Calculate Today's metrics
  const todayStr = currentTime.toISOString().split('T')[0];

  const todaysInvoices = invoices.filter(inv => inv.date.startsWith(todayStr));
  const todaysSalesAmount = todaysInvoices.reduce((acc, inv) => acc + inv.grandTotal, 0);
  const todaysCashCollected = todaysInvoices.reduce((acc, inv) => acc + inv.paidAmount, 0);

  const todaysPurchases = purchases.filter(p => p.date.startsWith(todayStr));
  const todaysPurchaseAmount = todaysPurchases.reduce((acc, p) => acc + p.totalPrice, 0);

  // Stock inventory metrics
  const totalStockCount = products.reduce((acc, p) => acc + p.stockQuantity, 0);
  const totalStockGrams = Math.round(products.reduce((acc, p) => acc + (p.weightGrams * p.stockQuantity), 0) * 1000) / 1000;

  // Aggregate bhori
  const totalStockBhori = (totalStockGrams / 11.664).toFixed(2);

  // Orders and Mortgages count
  const activeOrdersCount = orders.filter(o => o.status !== 'ডেলিভারি সম্পন্ন' && o.status !== 'বাতিল').length;
  const activeMortgagesCount = mortgages.filter(m => m.status === 'চলমান').length;
  const totalMortgageLoan = mortgages.filter(m => m.status === 'চলমান').reduce((sum, m) => sum + m.loanAmount, 0);

  // Total outstanding dues from customers
  const totalOutstandingDue = customers.reduce((acc, c) => acc + c.currentDue, 0);
  const customersWithDueCount = customers.filter(c => c.currentDue > 0).length;

  const handleSaveRates = (e: React.FormEvent) => {
    e.preventDefault();
    updateRates(tempRates);
    setIsEditingRates(false);
  };

  const handleResetDataClick = () => {
    if (window.confirm('আপনি কি নিশ্চিত যে সকল ডেমো মেমো, পণ্য ও কাস্টমার মুছে সম্পূর্ণ নতুন ফ্রেশ ডাটাবেজে শুরু করতে চান?')) {
      clearAllShopData();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Top Welcome & Real-Time Live Clock Banner */}
      <div className="bg-gradient-to-r from-[#1f190f] via-[#16130b] to-[#0c0b08] p-4 sm:p-6 rounded-2xl border border-amber-600/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          {/* Real-time Live Date and Time */}
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="text-xs bg-amber-500/20 text-amber-300 font-bold px-2.5 py-0.5 rounded border border-amber-600/30 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <span>{banglaDate}</span>
            </span>

            <span className="text-xs bg-neutral-900 text-amber-200 font-mono font-bold px-2.5 py-0.5 rounded border border-amber-600/30 flex items-center gap-1.5 shadow-inner">
              <Clock className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>সময়: {banglaTime}</span>
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-amber-100">
            {shopProfile.name}
          </h2>
          <p className="text-xs text-amber-300/70 mt-0.5">
            স্বর্ণ ও রূপা ব্যবসা ব্যবস্থাপনা, ডিজিটাল ক্যাশ মেমো, কাস্টমার অর্ডার বুক ও বন্ধকী হিসাব
          </p>
        </div>

        {/* Quick Rate Update & Config Trigger */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setTempRates({ ...rates });
              setIsEditingRates(true);
            }}
            className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Coins className="w-4 h-4 text-amber-400" />
            স্বর্ণের দর পরিবর্তন
          </button>

          <button
            onClick={() => setIsAndroidModalOpen(true)}
            className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-amber-700/40 text-amber-300 hover:bg-neutral-800 text-xs flex items-center gap-1.5"
          >
            <Smartphone className="w-4 h-4 text-amber-400" />
            মোবাইল APK
          </button>

          <button
            onClick={handleResetDataClick}
            title="সব ডেমো মেমো ও স্টক ক্লিয়ার করে একদম নতুন শুরু করুন"
            className="px-3 py-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-800/50 text-red-300 text-xs flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-red-400" />
            <span>ডাটা রিসেট</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1: Today's Sales */}
        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30 hover:border-amber-500/60 transition-all shadow-md">
          <div className="flex items-center justify-between text-amber-400/80 mb-2">
            <span className="text-xs font-semibold">আজকের মোট বিক্রি</span>
            <div className="p-1.5 rounded-lg bg-amber-950/80 text-amber-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-black font-mono text-amber-200">
            {formatTaka(todaysSalesAmount)}
          </p>
          <div className="flex items-center justify-between text-[11px] text-amber-400/70 mt-2 pt-2 border-t border-amber-950">
            <span>নগদ জমা: {formatTaka(todaysCashCollected)}</span>
            <span>{toBengaliNumber(todaysInvoices.length)}টি মেমো</span>
          </div>
        </div>

        {/* Metric 2: Custom Orders */}
        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30 hover:border-amber-500/60 transition-all shadow-md">
          <div className="flex items-center justify-between text-amber-400/80 mb-2">
            <span className="text-xs font-semibold">স্বর্ণ ও রূপার চলতি অর্ডার</span>
            <div className="p-1.5 rounded-lg bg-amber-950/80 text-amber-400">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-black font-mono text-amber-200">
            {toBengaliNumber(activeOrdersCount)} টি অর্ডার
          </p>
          <div className="flex items-center justify-between text-[11px] text-amber-400/70 mt-2 pt-2 border-t border-amber-950">
            <span>প্রক্রিয়াধীন কারিগর কাজ</span>
            <button
              onClick={() => setActiveTab('orders')}
              className="text-amber-300 underline"
            >
              দেখুন &rarr;
            </button>
          </div>
        </div>

        {/* Metric 3: Mortgages (বন্ধকী ঋণ) */}
        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30 hover:border-amber-500/60 transition-all shadow-md">
          <div className="flex items-center justify-between text-amber-400/80 mb-2">
            <span className="text-xs font-semibold">চলমান বন্ধকী ঋণ</span>
            <div className="p-1.5 rounded-lg bg-amber-950/80 text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-black font-mono text-amber-200">
            {formatTaka(totalMortgageLoan)}
          </p>
          <div className="flex items-center justify-between text-[11px] text-amber-400/70 mt-2 pt-2 border-t border-amber-950">
            <span>গ্রাহক: {toBengaliNumber(activeMortgagesCount)} জন</span>
            <button
              onClick={() => setActiveTab('mortgage')}
              className="text-amber-300 underline"
            >
              খতিয়ান &rarr;
            </button>
          </div>
        </div>

        {/* Metric 4: Total Outstanding Due */}
        <div className="bg-[#12110c] p-4 rounded-xl border border-amber-600/30 hover:border-amber-500/60 transition-all shadow-md">
          <div className="flex items-center justify-between text-amber-400/80 mb-2">
            <span className="text-xs font-semibold">মোট বকেয়া পাওনা</span>
            <div className="p-1.5 rounded-lg bg-red-950/80 text-red-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-black font-mono text-red-300">
            {formatTaka(totalOutstandingDue)}
          </p>
          <div className="flex items-center justify-between text-[11px] text-red-400/70 mt-2 pt-2 border-t border-amber-950">
            <span>বকেয়াদার: {toBengaliNumber(customersWithDueCount)} জন</span>
            <button
              onClick={() => setActiveTab('customers')}
              className="underline hover:text-amber-300"
            >
              আদায় করুন &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Quick Touch Action Buttons Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          onClick={() => setActiveTab('pos')}
          className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg transition-transform active:scale-95"
        >
          <ReceiptText className="w-4 h-4" />
          মেমো / বিক্রি
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className="p-3.5 rounded-xl bg-amber-950/60 border border-amber-500/60 hover:bg-amber-900/60 text-amber-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-transform active:scale-95 shadow-md"
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          স্বর্ণ ও রূপার অর্ডার
        </button>

        <button
          onClick={() => setActiveTab('mortgage')}
          className="p-3.5 rounded-xl bg-neutral-900 border border-amber-600/50 hover:bg-neutral-800 text-amber-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-transform active:scale-95 shadow-md"
        >
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          বন্ধকী হিসাব
        </button>

        <button
          onClick={() => setActiveTab('calculator')}
          className="p-3.5 rounded-xl bg-neutral-900 border border-amber-600/50 hover:bg-neutral-800 text-amber-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-transform active:scale-95"
        >
          <Calculator className="w-4 h-4 text-amber-400" />
          স্বর্ণ ক্যালকুলেটর
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className="p-3.5 rounded-xl bg-neutral-900 border border-amber-600/50 hover:bg-neutral-800 text-amber-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-transform active:scale-95"
        >
          <PlusCircle className="w-4 h-4 text-amber-400" />
          গহনা স্টক
        </button>

        <button
          onClick={() => setActiveTab('purchases')}
          className="p-3.5 rounded-xl bg-neutral-900 border border-amber-600/50 hover:bg-neutral-800 text-amber-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-transform active:scale-95"
        >
          <ArrowDownLeft className="w-4 h-4 text-amber-400" />
          পুরাতন স্বর্ণ ক্রয়
        </button>
      </div>

      {/* Recent Sales Table */}
      <div className="bg-[#12110c] rounded-2xl border border-amber-800/40 p-4 sm:p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-amber-900/40 pb-3">
          <div className="flex items-center gap-2">
            <ReceiptText className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base text-amber-200">সাম্প্রতিক ক্যাশ মেমো ও বিক্রি তালিকা</h3>
          </div>
          <button
            onClick={() => setActiveTab('reports')}
            className="text-xs text-amber-400 hover:underline flex items-center gap-1"
          >
            সকল রিপোর্ট দেখুন <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-amber-950/40 text-amber-300/80 border-b border-amber-800/30">
              <tr>
                <th className="p-3">মেমো নং</th>
                <th className="p-3">তারিখ ও সময়</th>
                <th className="p-3">ক্রেতার নাম</th>
                <th className="p-3">ওজন (গ্রাম)</th>
                <th className="p-3 text-right">মোট মূল্য</th>
                <th className="p-3 text-right">জমা</th>
                <th className="p-3 text-right">বকেয়া</th>
                <th className="p-3 text-center">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-950/60 text-amber-100">
              {invoices.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-8 text-neutral-500">
                    বর্তমানে কোনো ক্যাশ মেমো নেই। নতুন বিক্রির জন্য উপরে "মেমো / বিক্রি" বাটনে ক্লিক করুন।
                  </td>
                </tr>
              ) : (
                invoices.slice(0, 5).map((inv) => (
                  <tr key={inv.id} className="hover:bg-amber-950/20">
                    <td className="p-3 font-mono font-bold text-amber-300">{inv.memoNumber}</td>
                    <td className="p-3 text-amber-400/80 font-mono">
                      <div>{new Date(inv.date).toLocaleDateString('bn-BD')}</div>
                      <div className="text-[10px] text-amber-500/80">{inv.time || new Date(inv.date).toLocaleTimeString('bn-BD')}</div>
                    </td>
                    <td className="p-3 font-semibold">{inv.customerName}</td>
                    <td className="p-3 font-mono">{toBengaliNumber(inv.totalWeightGrams)}g</td>
                    <td className="p-3 text-right font-mono font-bold">{formatTaka(inv.grandTotal)}</td>
                    <td className="p-3 text-right font-mono text-emerald-400">{formatTaka(inv.paidAmount)}</td>
                    <td className={`p-3 text-right font-mono font-bold ${inv.dueAmount > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {formatTaka(inv.dueAmount)}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => {
                          setInvoiceToPrint(inv);
                          setIsPrintModalOpen(true);
                        }}
                        className="px-2 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-600/30 inline-flex items-center gap-1 text-[11px]"
                      >
                        <Printer className="w-3 h-3" /> মেমো
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Gold Rate Edit Modal */}
      {isEditingRates && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#14120e] border border-amber-600/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="font-bold text-lg text-amber-200 flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-400" />
              আজকের স্বর্ণের বাজার দর (টাকা/ভরি)
            </h3>
            <p className="text-xs text-amber-400/70">
              বাংলাদেশ জুয়েলার্স অ্যাসোসিয়েশন (বাজুস) নির্ধারিত আজকের রেট হালনাগাদ করুন
            </p>

            <form onSubmit={handleSaveRates} className="space-y-3">
              {(['24K', '22K', '21K', '18K', 'সনাতন'] as const).map((k) => (
                <div key={k} className="flex items-center justify-between gap-4">
                  <label className="text-xs font-semibold text-amber-300 w-24">{k} রেট:</label>
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-2 text-amber-500 text-xs font-bold">৳</span>
                    <input
                      type="number"
                      value={tempRates[k]}
                      onChange={(e) => setTempRates({ ...tempRates, [k]: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-neutral-900 border border-amber-600/40 rounded-lg pl-7 pr-3 py-1.5 text-xs text-amber-100 font-mono focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>
              ))}

              <div className="flex justify-end gap-2 pt-3 border-t border-amber-900/40">
                <button
                  type="button"
                  onClick={() => setIsEditingRates(false)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs shadow"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
