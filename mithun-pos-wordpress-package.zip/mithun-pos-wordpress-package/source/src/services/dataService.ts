/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Product,
  Invoice,
  PurchaseRecord,
  Customer,
  DuePayment,
  GoldRateSetting,
  SilverRateSetting,
  ShopProfile,
  UserSession,
  CustomerOrder,
  MortgageRecord
} from '../types';
import {
  initializeFirebaseServices,
  isFirebaseConfigured,
  collection,
  doc,
  getDocs,
  setDoc,
  runTransaction
} from '../firebase/config';

// Keys for local storage
const STORAGE_KEYS = {
  PRODUCTS: 'mithun_pos_products_v2',
  INVOICES: 'mithun_pos_invoices_v2',
  PURCHASES: 'mithun_pos_purchases_v2',
  CUSTOMERS: 'mithun_pos_customers_v2',
  DUE_PAYMENTS: 'mithun_pos_due_payments_v2',
  ORDERS: 'mithun_pos_orders_v2',
  MORTGAGES: 'mithun_pos_mortgages_v2',
  RATES: 'mithun_pos_rates',
  SILVER_RATES: 'mithun_pos_silver_rates',
  PROFILE: 'mithun_pos_shop_profile',
  SESSION: 'mithun_pos_user_session',
  CLEARED_FLAG: 'mithun_pos_demo_cleared_fresh_v2',
};

export const INITIAL_RATES: GoldRateSetting = {
  '24K': 142000,
  '22K': 130000,
  '21K': 124000,
  '18K': 106000,
  'সনাতন': 88000,
  updatedAt: new Date().toISOString(),
};

export const INITIAL_SILVER_RATES: SilverRateSetting = {
  '22K': 2100,
  '21K': 2000,
  '18K': 1700,
  'সনাতন': 1280,
  updatedAt: new Date().toISOString(),
};

export const INITIAL_PROFILE: ShopProfile = {
  name: 'মেসার্স মিঠুন অলংকার হাউজ',
  proprietor: 'শ্রী মিঠুন কর্মকার',
  address: 'চালাকচর বাজার, স্বর্ণপট্টি, মনোহরদী, নরসিংদী।',
  phone: '০১৬২১৮৯৫৫৯০, ০১৭১৬১৪০৯৭২',
  email: 'mithun.jewelry@gmail.com',
  vatRegistrationNo: 'BIN: 004829104-0102',
  slogan: '১০০% হলমার্কযুক্ত ও ক্যাডমিয়াম স্বর্ণালংকারের বিশ্বস্ত প্রতিষ্ঠান',
};

// Pure blank seeds as requested by user for fresh official shop launch
export const SEED_PRODUCTS: Product[] = [];
export const SEED_INVOICES: Invoice[] = [];
export const SEED_PURCHASES: PurchaseRecord[] = [];
export const SEED_CUSTOMERS: Customer[] = [];
export const SEED_ORDERS: CustomerOrder[] = [];
export const SEED_MORTGAGES: MortgageRecord[] = [];

export class DataService {
  // Clear all demo data so user starts completely fresh
  static ensureFreshLaunch(): void {
    try {
      const hasCleaned = localStorage.getItem(STORAGE_KEYS.CLEARED_FLAG);
      if (!hasCleaned) {
        // Remove old demo data keys
        localStorage.removeItem('mithun_pos_products');
        localStorage.removeItem('mithun_pos_invoices');
        localStorage.removeItem('mithun_pos_purchases');
        localStorage.removeItem('mithun_pos_customers');
        localStorage.removeItem('mithun_pos_due_payments');
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify([]));
        localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify([]));
        localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify([]));
        localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify([]));
        localStorage.setItem(STORAGE_KEYS.DUE_PAYMENTS, JSON.stringify([]));
        localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify([]));
        localStorage.setItem(STORAGE_KEYS.MORTGAGES, JSON.stringify([]));
        localStorage.setItem(STORAGE_KEYS.CLEARED_FLAG, 'true');
      }
    } catch (e) {
      console.warn('Could not initialize clean launch storage:', e);
    }
  }

  // Reset all transactional and product data
  static clearAllData(): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.DUE_PAYMENTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.MORTGAGES, JSON.stringify([]));
    } catch (e) {
      console.error('Error clearing data:', e);
    }
  }

  // Helper to get from local storage
  private static getLocal<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.warn(`Error reading localStorage for ${key}:`, e);
    }
    return defaultValue;
  }

  // Helper to set into local storage
  private static setLocal<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Error saving localStorage for ${key}:`, e);
    }
  }

  // Get active session
  static getSession(): UserSession | null {
    return this.getLocal<UserSession | null>(STORAGE_KEYS.SESSION, {
      uid: 'admin-mithun',
      email: 'mithun@alankarhouse.com',
      displayName: 'শ্রী মিঠুন কর্মকার (মালিক)',
      role: 'মালিক / এডমিন',
      isDemo: true,
    });
  }

  static setSession(session: UserSession | null): void {
    if (session) {
      this.setLocal(STORAGE_KEYS.SESSION, session);
    } else {
      localStorage.removeItem(STORAGE_KEYS.SESSION);
    }
  }

  // Load shop profile
  static getShopProfile(): ShopProfile {
    const profile = this.getLocal<ShopProfile>(STORAGE_KEYS.PROFILE, INITIAL_PROFILE);
    if (!profile.phone.includes('০১৬২১৮৯৫৫৯০')) {
      const updated: ShopProfile = {
        ...profile,
        address: 'চালাকচর বাজার, স্বর্ণপট্টি, মনোহরদী, নরসিংদী।',
        phone: '০১৬২১৮৯৫৫৯০, ০১৭১৬১৪০৯৭২',
      };
      this.saveShopProfile(updated);
      return updated;
    }
    return profile;
  }

  static saveShopProfile(profile: ShopProfile): void {
    this.setLocal(STORAGE_KEYS.PROFILE, profile);
  }

  // Load gold rates
  static getGoldRates(): GoldRateSetting {
    return this.getLocal<GoldRateSetting>(STORAGE_KEYS.RATES, INITIAL_RATES);
  }

  static saveGoldRates(rates: GoldRateSetting): void {
    this.setLocal(STORAGE_KEYS.RATES, rates);
  }

  // Load silver rates
  static getSilverRates(): SilverRateSetting {
    return this.getLocal<SilverRateSetting>(STORAGE_KEYS.SILVER_RATES, INITIAL_SILVER_RATES);
  }

  static saveSilverRates(rates: SilverRateSetting): void {
    this.setLocal(STORAGE_KEYS.SILVER_RATES, rates);
  }

  // Products / Stock (supports both Gold & Silver)
  static getProducts(): Product[] {
    this.ensureFreshLaunch();
    return this.getLocal<Product[]>(STORAGE_KEYS.PRODUCTS, SEED_PRODUCTS);
  }

  static saveProduct(product: Product): Product[] {
    const list = this.getProducts();
    const existingIndex = list.findIndex(p => p.id === product.id);
    let updated: Product[];
    if (existingIndex >= 0) {
      updated = [...list];
      updated[existingIndex] = product;
    } else {
      updated = [product, ...list];
    }
    this.setLocal(STORAGE_KEYS.PRODUCTS, updated);

    const { db, configured } = initializeFirebaseServices();
    if (configured && db) {
      setDoc(doc(db, 'products', product.id), product).catch(err => {
        console.warn('Firebase product sync error:', err);
      });
    }

    return updated;
  }

  static deleteProduct(productId: string): Product[] {
    const list = this.getProducts();
    const filtered = list.filter(p => p.id !== productId);
    this.setLocal(STORAGE_KEYS.PRODUCTS, filtered);
    return filtered;
  }

  // Invoices & Atomic Stock Adjustment
  static getInvoices(): Invoice[] {
    this.ensureFreshLaunch();
    return this.getLocal<Invoice[]>(STORAGE_KEYS.INVOICES, SEED_INVOICES);
  }

  static createInvoice(invoice: Invoice): { invoices: Invoice[]; products: Product[]; customers: Customer[] } {
    const invoices = [invoice, ...this.getInvoices()];
    this.setLocal(STORAGE_KEYS.INVOICES, invoices);

    // Atomically decrement stock
    const products = [...this.getProducts()];
    invoice.items.forEach(item => {
      if (item.productId) {
        const prodIndex = products.findIndex(p => p.id === item.productId);
        if (prodIndex >= 0) {
          const newQty = Math.max(0, products[prodIndex].stockQuantity - (item.quantity || 1));
          products[prodIndex] = {
            ...products[prodIndex],
            stockQuantity: newQty,
          };
        }
      }
    });
    this.setLocal(STORAGE_KEYS.PRODUCTS, products);

    // Atomically update or create Customer record
    const customers = [...this.getCustomers()];
    const custIndex = customers.findIndex(c => c.phone && invoice.customerPhone && c.phone.trim() === invoice.customerPhone.trim());
    if (custIndex >= 0) {
      const existing = customers[custIndex];
      customers[custIndex] = {
        ...existing,
        name: invoice.customerName || existing.name,
        address: invoice.customerAddress || existing.address,
        totalPurchasesCount: existing.totalPurchasesCount + 1,
        totalSpent: existing.totalSpent + invoice.grandTotal,
        totalPaid: existing.totalPaid + invoice.paidAmount,
        currentDue: existing.currentDue + invoice.dueAmount,
        lastPurchaseDate: invoice.date,
      };
    } else if (invoice.customerPhone || invoice.customerName) {
      customers.unshift({
        id: `cust-${Date.now()}`,
        name: invoice.customerName || 'খুচরা ক্রেতা',
        phone: invoice.customerPhone || '',
        address: invoice.customerAddress || '',
        totalPurchasesCount: 1,
        totalSpent: invoice.grandTotal,
        totalPaid: invoice.paidAmount,
        currentDue: invoice.dueAmount,
        lastPurchaseDate: invoice.date,
        createdAt: new Date().toISOString(),
      });
    }
    this.setLocal(STORAGE_KEYS.CUSTOMERS, customers);

    const { db, configured } = initializeFirebaseServices();
    if (configured && db) {
      try {
        runTransaction(db, async (transaction) => {
          const invRef = doc(db, 'invoices', invoice.id);
          transaction.set(invRef, invoice);
        }).catch(err => {
          console.warn('Firebase transaction sync notice:', err);
        });
      } catch (err) {
        console.warn('Firebase transaction error:', err);
      }
    }

    return { invoices, products, customers };
  }

  // Purchases
  static getPurchases(): PurchaseRecord[] {
    this.ensureFreshLaunch();
    return this.getLocal<PurchaseRecord[]>(STORAGE_KEYS.PURCHASES, SEED_PURCHASES);
  }

  static createPurchase(purchase: PurchaseRecord): PurchaseRecord[] {
    const list = [purchase, ...this.getPurchases()];
    this.setLocal(STORAGE_KEYS.PURCHASES, list);
    return list;
  }

  // Customers & Dues
  static getCustomers(): Customer[] {
    this.ensureFreshLaunch();
    return this.getLocal<Customer[]>(STORAGE_KEYS.CUSTOMERS, SEED_CUSTOMERS);
  }

  static saveCustomer(customer: Customer): Customer[] {
    const list = this.getCustomers();
    const idx = list.findIndex(c => c.id === customer.id);
    let updated: Customer[];
    if (idx >= 0) {
      updated = [...list];
      updated[idx] = customer;
    } else {
      updated = [customer, ...list];
    }
    this.setLocal(STORAGE_KEYS.CUSTOMERS, updated);
    return updated;
  }

  // Due Collection Payment
  static getDuePayments(): DuePayment[] {
    return this.getLocal<DuePayment[]>(STORAGE_KEYS.DUE_PAYMENTS, []);
  }

  static collectDuePayment(payment: DuePayment): { customers: Customer[]; duePayments: DuePayment[] } {
    const payments = [payment, ...this.getDuePayments()];
    this.setLocal(STORAGE_KEYS.DUE_PAYMENTS, payments);

    const customers = [...this.getCustomers()];
    const custIdx = customers.findIndex(c => c.id === payment.customerId);
    if (custIdx >= 0) {
      const cust = customers[custIdx];
      const newDue = Math.max(0, cust.currentDue - payment.amount);
      const newPaid = cust.totalPaid + payment.amount;
      customers[custIdx] = {
        ...cust,
        currentDue: newDue,
        totalPaid: newPaid,
      };
    }
    this.setLocal(STORAGE_KEYS.CUSTOMERS, customers);
    return { customers, duePayments: payments };
  }

  // Customer Custom Orders (Gold & Silver)
  static getOrders(): CustomerOrder[] {
    this.ensureFreshLaunch();
    return this.getLocal<CustomerOrder[]>(STORAGE_KEYS.ORDERS, SEED_ORDERS);
  }

  static saveOrder(order: CustomerOrder): CustomerOrder[] {
    const list = this.getOrders();
    const idx = list.findIndex(o => o.id === order.id);
    let updated: CustomerOrder[];
    if (idx >= 0) {
      updated = [...list];
      updated[idx] = order;
    } else {
      updated = [order, ...list];
    }
    this.setLocal(STORAGE_KEYS.ORDERS, updated);
    return updated;
  }

  static deleteOrder(id: string): CustomerOrder[] {
    const list = this.getOrders();
    const filtered = list.filter(o => o.id !== id);
    this.setLocal(STORAGE_KEYS.ORDERS, filtered);
    return filtered;
  }

  // Mortgages (Pawn / Girvi Loans)
  static getMortgages(): MortgageRecord[] {
    this.ensureFreshLaunch();
    return this.getLocal<MortgageRecord[]>(STORAGE_KEYS.MORTGAGES, SEED_MORTGAGES);
  }

  static saveMortgage(mortgage: MortgageRecord): MortgageRecord[] {
    const list = this.getMortgages();
    const idx = list.findIndex(m => m.id === mortgage.id);
    let updated: MortgageRecord[];
    if (idx >= 0) {
      updated = [...list];
      updated[idx] = mortgage;
    } else {
      updated = [mortgage, ...list];
    }
    this.setLocal(STORAGE_KEYS.MORTGAGES, updated);
    return updated;
  }

  static deleteMortgage(id: string): MortgageRecord[] {
    const list = this.getMortgages();
    const filtered = list.filter(m => m.id !== id);
    this.setLocal(STORAGE_KEYS.MORTGAGES, filtered);
    return filtered;
  }

  // Data Backup & Export
  static exportCompleteBackupJson(): string {
    const backup = {
      version: '2.0',
      exportDate: new Date().toISOString(),
      shopProfile: this.getShopProfile(),
      goldRates: this.getGoldRates(),
      silverRates: this.getSilverRates(),
      products: this.getProducts(),
      invoices: this.getInvoices(),
      purchases: this.getPurchases(),
      customers: this.getCustomers(),
      duePayments: this.getDuePayments(),
      orders: this.getOrders(),
      mortgages: this.getMortgages(),
    };
    return JSON.stringify(backup, null, 2);
  }

  static restoreFromBackupJson(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.products && Array.isArray(data.products)) {
        this.setLocal(STORAGE_KEYS.PRODUCTS, data.products);
      }
      if (data.invoices && Array.isArray(data.invoices)) {
        this.setLocal(STORAGE_KEYS.INVOICES, data.invoices);
      }
      if (data.purchases && Array.isArray(data.purchases)) {
        this.setLocal(STORAGE_KEYS.PURCHASES, data.purchases);
      }
      if (data.customers && Array.isArray(data.customers)) {
        this.setLocal(STORAGE_KEYS.CUSTOMERS, data.customers);
      }
      if (data.duePayments && Array.isArray(data.duePayments)) {
        this.setLocal(STORAGE_KEYS.DUE_PAYMENTS, data.duePayments);
      }
      if (data.orders && Array.isArray(data.orders)) {
        this.setLocal(STORAGE_KEYS.ORDERS, data.orders);
      }
      if (data.mortgages && Array.isArray(data.mortgages)) {
        this.setLocal(STORAGE_KEYS.MORTGAGES, data.mortgages);
      }
      if (data.goldRates) {
        this.setLocal(STORAGE_KEYS.RATES, data.goldRates);
      }
      if (data.silverRates) {
        this.setLocal(STORAGE_KEYS.SILVER_RATES, data.silverRates);
      }
      if (data.shopProfile) {
        this.setLocal(STORAGE_KEYS.PROFILE, data.shopProfile);
      }
      return true;
    } catch (e) {
      console.error('Backup restoration failed:', e);
      return false;
    }
  }

  static exportCsv(type: 'sales' | 'products' | 'customers' | 'dues' | 'orders' | 'mortgages'): string {
    if (type === 'sales') {
      const invoices = this.getInvoices();
      const headers = ['মেমো নং', 'তারিখ', 'সময়', 'গ্রাহকের নাম', 'মোবাইল', 'মোট ওজন (গ্রাম)', 'সর্বমোট মূল্য (৳)', 'জমা (৳)', 'বকেয়া (৳)', 'পেমেন্ট মাধ্যম', 'স্ট্যাটাস'];
      const rows = invoices.map(inv => [
        `"${inv.memoNumber}"`,
        `"${new Date(inv.date).toLocaleDateString('bn-BD')}"`,
        `"${inv.time || ''}"`,
        `"${inv.customerName}"`,
        `"${inv.customerPhone}"`,
        inv.totalWeightGrams,
        inv.grandTotal,
        inv.paidAmount,
        inv.dueAmount,
        `"${inv.paymentMethod}"`,
        `"${inv.status}"`,
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (type === 'products') {
      const products = this.getProducts();
      const headers = ['কোড', 'ধাতু', 'পণ্যের নাম', 'ক্যাটাগরি', 'ক্যারেট', 'ওজন (গ্রাম)', 'বিক্রয়মূল্য (৳)', 'মজুদ সংখ্যা'];
      const rows = products.map(p => [
        `"${p.code}"`,
        `"${p.metalType || 'স্বর্ণ'}"`,
        `"${p.name}"`,
        `"${p.category}"`,
        `"${p.karat}"`,
        p.weightGrams,
        p.sellingPrice,
        p.stockQuantity,
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (type === 'customers' || type === 'dues') {
      const customers = this.getCustomers();
      const headers = ['গ্রাহকের নাম', 'মোবাইল', 'ঠিকানা', 'মোট কেনাকাটা', 'মোট পরিশোধ', 'বর্তমান বকেয়া'];
      const rows = customers.map(c => [
        `"${c.name}"`,
        `"${c.phone}"`,
        `"${c.address}"`,
        c.totalSpent,
        c.totalPaid,
        c.currentDue,
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (type === 'orders') {
      const orders = this.getOrders();
      const headers = ['অর্ডার নং', 'তারিখ', 'ডেলিভারির তারিখ', 'গ্রাহকের নাম', 'মোবাইল', 'ধাতু', 'পণ্যের নাম', 'ওজন (গ্রাম)', 'মোট মূল্য', 'অগ্রিম জমা', 'বকেয়া', 'স্ট্যাটাস'];
      const rows = orders.map(o => [
        `"${o.orderNumber}"`,
        `"${new Date(o.date).toLocaleDateString('bn-BD')}"`,
        `"${o.deliveryDate}"`,
        `"${o.customerName}"`,
        `"${o.customerPhone}"`,
        `"${o.metalType}"`,
        `"${o.itemName}"`,
        o.weightGrams,
        o.totalPrice,
        o.advancePaid,
        o.dueAmount,
        `"${o.status}"`
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    if (type === 'mortgages') {
      const mortgages = this.getMortgages();
      const headers = ['বন্ধক নং', 'তারিখ', 'গ্রাহকের নাম', 'মোবাইল', 'ধাতু', 'অলংকারের নাম', 'খাঁটি ওজন (গ্রাম)', 'প্রদত্ত ঋণ (৳)', 'মাসিক সুদ (%)', 'মেয়াদ (মাস)', 'স্ট্যাটাস'];
      const rows = mortgages.map(m => [
        `"${m.mortgageNumber}"`,
        `"${new Date(m.date).toLocaleDateString('bn-BD')}"`,
        `"${m.customerName}"`,
        `"${m.customerPhone}"`,
        `"${m.metalType}"`,
        `"${m.itemName}"`,
        m.netWeightGrams,
        m.loanAmount,
        m.monthlyInterestRatePercent,
        m.durationMonths,
        `"${m.status}"`
      ]);
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    return '';
  }
}
