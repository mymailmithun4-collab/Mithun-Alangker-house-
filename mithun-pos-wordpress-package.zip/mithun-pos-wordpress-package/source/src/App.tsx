/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { PosInvoiceView } from './components/PosInvoiceView';
import { GoldCalculatorView } from './components/GoldCalculatorView';
import { ProductManagementView } from './components/ProductManagementView';
import { PurchaseManagementView } from './components/PurchaseManagementView';
import { CustomerLedgerView } from './components/CustomerLedgerView';
import { CustomerOrderView } from './components/CustomerOrderView';
import { MortgageView } from './components/MortgageView';
import { ReportsView } from './components/ReportsView';
import { BackupExportView } from './components/BackupExportView';

// Modals
import { PrintInvoiceModal } from './components/PrintInvoiceModal';
import { FirebaseConfigModal } from './components/FirebaseConfigModal';
import { AndroidGuideModal } from './components/AndroidGuideModal';
import { AuthModal } from './components/AuthModal';

import { CheckCircle2, AlertCircle, Info, Heart, Gem } from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    activeTab,
    toast,
    isAuthModalOpen,
    setIsAuthModalOpen,
    isFirebaseModalOpen,
    setIsFirebaseModalOpen,
    isAndroidModalOpen,
    setIsAndroidModalOpen,
    isPrintModalOpen,
    setIsPrintModalOpen,
    invoiceToPrint,
    shopProfile
  } = useApp();

  return (
    <div className="min-h-screen bg-[#0b0a08] text-amber-50 flex flex-col font-['Hind_Siliguri',sans-serif]">
      {/* Navigation */}
      <Navbar />

      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-14 right-4 z-50 animate-bounce">
          <div
            className={`px-4 py-2.5 rounded-xl shadow-2xl border text-xs font-semibold flex items-center gap-2 ${
              toast.type === 'error'
                ? 'bg-red-950 text-red-200 border-red-700'
                : toast.type === 'info'
                ? 'bg-blue-950 text-blue-200 border-blue-700'
                : 'bg-emerald-950 text-emerald-200 border-emerald-600'
            }`}
          >
            {toast.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-red-400" />
            ) : toast.type === 'info' ? (
              <Info className="w-4 h-4 text-blue-400" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Main Body Content */}
      <main className="flex-1 pb-20 md:pb-8">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'pos' && <PosInvoiceView />}
        {activeTab === 'orders' && <CustomerOrderView />}
        {activeTab === 'mortgage' && <MortgageView />}
        {activeTab === 'calculator' && <GoldCalculatorView />}
        {activeTab === 'products' && <ProductManagementView />}
        {activeTab === 'purchases' && <PurchaseManagementView />}
        {activeTab === 'customers' && <CustomerLedgerView />}
        {activeTab === 'reports' && <ReportsView />}
        {activeTab === 'backup' && <BackupExportView />}
      </main>

      {/* Footer (Desktop & Tablet) */}
      <footer className="no-print hidden md:block bg-[#080705] border-t border-amber-900/30 text-amber-400/70 text-xs py-4 px-6 text-center">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="flex items-center gap-1.5 justify-center">
            <Gem className="w-3.5 h-3.5 text-amber-500" />
            <span>{shopProfile.name} &copy; {new Date().getFullYear()}</span>
            <span>|</span>
            <span>{shopProfile.address}</span>
          </p>
          <p className="text-[11px] text-amber-500/60">
            ১ ভরি = ১৬ আনা = ৯৬০ পয়েন্ট = ১১.৬৬৪ গ্রাম | ফোন: {shopProfile.phone}
          </p>
        </div>
      </footer>

      {/* Modals */}
      <PrintInvoiceModal
        invoice={invoiceToPrint}
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
      />

      <FirebaseConfigModal
        isOpen={isFirebaseModalOpen}
        onClose={() => setIsFirebaseModalOpen(false)}
      />

      <AndroidGuideModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
