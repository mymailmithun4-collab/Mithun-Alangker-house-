/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoldWeightParts, KaratType } from '../utils/goldCalculator';

export type { GoldWeightParts, KaratType };

export type SilverKaratType = '22K' | '21K' | '18K' | 'সনাতন';

export type MetalType = 'স্বর্ণ' | 'রূপা';

export interface SilverRateSetting {
  '22K': number;
  '21K': number;
  '18K': number;
  'সনাতন': number;
  updatedAt: string;
}

export type ActiveTab =
  | 'dashboard'
  | 'pos'
  | 'calculator'
  | 'orders'
  | 'mortgage'
  | 'products'
  | 'purchases'
  | 'customers'
  | 'reports'
  | 'backup';

export interface Product {
  id: string;
  name: string;
  code: string;
  barcode: string;
  category: string;
  metalType: MetalType;
  karat: KaratType;
  weightParts: GoldWeightParts;
  weightGrams: number;
  purchasePrice: number;
  sellingPrice: number;
  stockQuantity: number;
  imageUrl?: string;
  notes?: string;
  createdAt: string;
}

export interface InvoiceItem {
  id: string;
  productId?: string;
  imageUrl?: string;
  metalType?: MetalType;
  productName: string;
  productCode: string;
  karat: KaratType;
  weightParts: GoldWeightParts;
  weightGrams: number;
  ratePerBhori: number;
  goldBasePrice: number;
  makingCharge: number;
  stonePrice: number;
  itemTotal: number;
  quantity: number;
}

export type PaymentMethod = 'নগদ' | 'বিকাশ' | 'নগদ/রকেট' | 'ব্যাংক ট্রান্সফার' | 'কার্ড';

export interface Invoice {
  id: string;
  memoNumber: string;
  date: string;
  time?: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  items: InvoiceItem[];
  totalWeightGrams: number;
  totalWeightParts: GoldWeightParts;
  subtotal: number;
  discount: number;
  vatAmount: number;
  grandTotal: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
  createdBy: string;
  status: 'পরিশোধিত' | 'আংশিক বকেয়া' | 'সম্পূর্ণ বকেয়া';
}

export interface PurchaseRecord {
  id: string;
  voucherNumber: string;
  date: string;
  time?: string;
  sellerName: string;
  sellerPhone: string;
  sellerAddress?: string;
  purchaseType: 'পুরাতন স্বর্ণ ক্রয়' | 'পুরাতন রূপা ক্রয়' | 'মহাজন হতে ক্রয়' | 'বিনিময়/এক্সচেঞ্জ';
  metalType?: MetalType;
  itemName: string;
  karat: KaratType;
  grossWeightParts: GoldWeightParts;
  wastePoints: number;
  netWeightParts: GoldWeightParts;
  netWeightGrams: number;
  ratePerBhori: number;
  totalPrice: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
}

export type OrderStatus = 'অর্ডার গৃহীত' | 'তৈরি হচ্ছে' | 'ডেলিভারির জন্য প্রস্তুত' | 'ডেলিভারি সম্পন্ন' | 'বাতিল';

export interface CustomerOrder {
  id: string;
  orderNumber: string;
  date: string;
  time?: string;
  deliveryDate: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  metalType: MetalType;
  itemName: string;
  karat: KaratType;
  weightParts: GoldWeightParts;
  weightGrams: number;
  ratePerBhori: number;
  metalPrice: number;
  makingCharge: number;
  stonePrice: number;
  totalPrice: number;
  advancePaid: number;
  dueAmount: number;
  customerGoldGiven?: {
    description: string;
    weightParts: GoldWeightParts;
    weightGrams: number;
    estimatedValue: number;
  };
  sampleImageUrl?: string;
  notes?: string;
  status: OrderStatus;
  createdAt: string;
}

export type MortgageStatus = 'চলমান' | 'খালাসকৃত' | 'মেয়াদোত্তীর্ণ';

export interface MortgageInterestPayment {
  id: string;
  date: string;
  time?: string;
  amount: number;
  monthsCount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
}

export interface MortgageRecord {
  id: string;
  mortgageNumber: string;
  date: string;
  time?: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  nidOrIdNumber?: string;
  metalType: MetalType;
  itemName: string;
  karat: KaratType;
  grossWeightParts: GoldWeightParts;
  grossWeightGrams: number;
  netWeightParts: GoldWeightParts;
  netWeightGrams: number;
  estimatedItemValue: number;
  loanAmount: number;
  monthlyInterestRatePercent: number;
  durationMonths: number;
  expiryDate: string;
  itemImageUrl?: string;
  status: MortgageStatus;
  interestPayments: MortgageInterestPayment[];
  redeemedDate?: string;
  redeemedAmount?: number;
  notes?: string;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  totalPurchasesCount: number;
  totalSpent: number;
  totalPaid: number;
  currentDue: number;
  lastPurchaseDate?: string;
  createdAt: string;
}

export interface DuePayment {
  id: string;
  receiptNo: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  amount: number;
  date: string;
  time?: string;
  paymentMethod: PaymentMethod;
  previousDue: number;
  remainingDue: number;
  notes?: string;
}

export interface GoldRateSetting {
  '24K': number;
  '22K': number;
  '21K': number;
  '18K': number;
  'সনাতন': number;
  updatedAt: string;
}

export interface ShopProfile {
  name: string;
  proprietor: string;
  address: string;
  phone: string;
  email: string;
  vatRegistrationNo: string;
  slogan: string;
}

export interface UserSession {
  uid: string;
  email: string;
  displayName: string;
  role: 'মালিক / এডমিন' | 'বিক্রয় প্রতিনিধি';
  isDemo: boolean;
}
