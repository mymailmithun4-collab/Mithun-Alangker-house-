/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Invoice,
  PurchaseRecord,
  Customer,
  DuePayment,
  GoldRateSetting,
  SilverRateSetting,
  ShopProfile,
  UserSession,
  InvoiceItem,
  ActiveTab,
  CustomerOrder,
  MortgageRecord
} from '../types';
import { DataService } from '../services/dataService';
import {
  isFirebaseConfigured,
  initializeFirebaseServices,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as fbSignOut,
  onAuthStateChanged
} from '../firebase/config';

export type { ActiveTab };

interface AppContextType {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  user: UserSession | null;
  firebaseStatus: 'connected' | 'demo_offline' | 'needs_config';
  rates: GoldRateSetting;
  updateRates: (rates: GoldRateSetting) => void;
  silverRates: SilverRateSetting;
  updateSilverRates: (rates: SilverRateSetting) => void;
  shopProfile: ShopProfile;
  updateShopProfile: (profile: ShopProfile) => void;
  products: Product[];
  saveProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  invoices: Invoice[];
  createInvoice: (invoice: Invoice) => void;
  purchases: PurchaseRecord[];
  createPurchase: (purchase: PurchaseRecord) => void;
  customers: Customer[];
  saveCustomer: (customer: Customer) => void;
  duePayments: DuePayment[];
  collectDuePayment: (payment: DuePayment) => void;

  // Custom Orders (Gold & Silver)
  orders: CustomerOrder[];
  saveOrder: (order: CustomerOrder) => void;
  deleteOrder: (id: string) => void;
  orderToPrint: CustomerOrder | null;
  setOrderToPrint: (order: CustomerOrder | null) => void;
  isOrderPrintModalOpen: boolean;
  setIsOrderPrintModalOpen: (open: boolean) => void;

  // Mortgage / Girvi Loans
  mortgages: MortgageRecord[];
  saveMortgage: (mortgage: MortgageRecord) => void;
  deleteMortgage: (id: string) => void;
  mortgageToPrint: MortgageRecord | null;
  setMortgageToPrint: (mortgage: MortgageRecord | null) => void;
  isMortgagePrintModalOpen: boolean;
  setIsMortgagePrintModalOpen: (open: boolean) => void;

  // Modals & Flows
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isFirebaseModalOpen: boolean;
  setIsFirebaseModalOpen: (open: boolean) => void;
  isAndroidModalOpen: boolean;
  setIsAndroidModalOpen: (open: boolean) => void;
  isPrintModalOpen: boolean;
  setIsPrintModalOpen: (open: boolean) => void;
  invoiceToPrint: Invoice | null;
  setInvoiceToPrint: (invoice: Invoice | null) => void;

  // Calculator to POS transfer
  calculatorTransferItem: Partial<InvoiceItem> | null;
  transferCalculatorItemToPos: (item: Partial<InvoiceItem>) => void;
  clearCalculatorTransferItem: () => void;

  // Auth actions
  loginDemo: () => void;
  loginWithEmail: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  registerWithEmail: (email: string, pass: string, name: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;

  // Toast
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;

  // Reset & Refresh
  refreshData: () => void;
  clearAllShopData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [user, setUser] = useState<UserSession | null>(DataService.getSession());
  const [rates, setRates] = useState<GoldRateSetting>(DataService.getGoldRates());
  const [silverRates, setSilverRates] = useState<SilverRateSetting>(DataService.getSilverRates());
  const [shopProfile, setShopProfile] = useState<ShopProfile>(DataService.getShopProfile());
  const [products, setProducts] = useState<Product[]>(DataService.getProducts());
  const [invoices, setInvoices] = useState<Invoice[]>(DataService.getInvoices());
  const [purchases, setPurchases] = useState<PurchaseRecord[]>(DataService.getPurchases());
  const [customers, setCustomers] = useState<Customer[]>(DataService.getCustomers());
  const [duePayments, setDuePayments] = useState<DuePayment[]>(DataService.getDuePayments());
  const [orders, setOrders] = useState<CustomerOrder[]>(DataService.getOrders());
  const [mortgages, setMortgages] = useState<MortgageRecord[]>(DataService.getMortgages());

  const [firebaseStatus, setFirebaseStatus] = useState<'connected' | 'demo_offline' | 'needs_config'>('demo_offline');

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isFirebaseModalOpen, setIsFirebaseModalOpen] = useState(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [invoiceToPrint, setInvoiceToPrint] = useState<Invoice | null>(null);

  const [orderToPrint, setOrderToPrint] = useState<CustomerOrder | null>(null);
  const [isOrderPrintModalOpen, setIsOrderPrintModalOpen] = useState(false);

  const [mortgageToPrint, setMortgageToPrint] = useState<MortgageRecord | null>(null);
  const [isMortgagePrintModalOpen, setIsMortgagePrintModalOpen] = useState(false);

  const [calculatorTransferItem, setCalculatorTransferItem] = useState<Partial<InvoiceItem> | null>(null);

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(prev => (prev?.message === message ? null : prev));
    }, 4000);
  };

  // Check Firebase setup on mount
  useEffect(() => {
    const configured = isFirebaseConfigured();
    if (configured) {
      const { auth } = initializeFirebaseServices();
      if (auth) {
        setFirebaseStatus('connected');
        const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
          if (firebaseUser) {
            const session: UserSession = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || 'user@mithunpos.com',
              displayName: firebaseUser.displayName || 'দোকানদার / প্রতিনিধি',
              role: 'মালিক / এডমিন',
              isDemo: false,
            };
            setUser(session);
            DataService.setSession(session);
          }
        });
        return () => unsubscribe();
      }
    } else {
      setFirebaseStatus('demo_offline');
    }
  }, []);

  const refreshData = () => {
    setProducts(DataService.getProducts());
    setInvoices(DataService.getInvoices());
    setPurchases(DataService.getPurchases());
    setCustomers(DataService.getCustomers());
    setDuePayments(DataService.getDuePayments());
    setOrders(DataService.getOrders());
    setMortgages(DataService.getMortgages());
    setRates(DataService.getGoldRates());
    setSilverRates(DataService.getSilverRates());
    setShopProfile(DataService.getShopProfile());
  };

  const clearAllShopData = () => {
    DataService.clearAllData();
    setProducts([]);
    setInvoices([]);
    setPurchases([]);
    setCustomers([]);
    setDuePayments([]);
    setOrders([]);
    setMortgages([]);
    showToast('সব ডেমো ও পূর্বের ডাটা সফলভাবে মুছে ফেলা হয়েছে। আপনি সম্পূর্ণ নতুনভাবে স্টক ও হিসাব শুরু করতে পারেন।');
  };

  const updateRates = (newRates: GoldRateSetting) => {
    setRates(newRates);
    DataService.saveGoldRates(newRates);
    showToast('স্বর্ণের আজকের বাজার দর সফলভাবে আপডেট করা হয়েছে।');
  };

  const updateSilverRates = (newRates: SilverRateSetting) => {
    setSilverRates(newRates);
    DataService.saveSilverRates(newRates);
    showToast('রূপার আজকের বাজার দর সফলভাবে আপডেট করা হয়েছে।');
  };

  const updateShopProfile = (newProfile: ShopProfile) => {
    setShopProfile(newProfile);
    DataService.saveShopProfile(newProfile);
    showToast('দোকানের তথ্য ও প্রোফাইল আপডেট হয়েছে।');
  };

  const saveProduct = (product: Product) => {
    const updated = DataService.saveProduct(product);
    setProducts(updated);
    showToast(`"${product.name}" সফলভাবে স্টকে সংরক্ষণ করা হয়েছে।`);
  };

  const deleteProduct = (id: string) => {
    const updated = DataService.deleteProduct(id);
    setProducts(updated);
    showToast('পণ্যটি স্টক থেকে মুছে ফেলা হয়েছে।', 'info');
  };

  const createInvoice = (invoice: Invoice) => {
    const result = DataService.createInvoice(invoice);
    setInvoices(result.invoices);
    setProducts(result.products);
    setCustomers(result.customers);
    setInvoiceToPrint(invoice);
    setIsPrintModalOpen(true);
    showToast(`ক্যাশ মেমো #${invoice.memoNumber} সফলভাবে তৈরি ও স্টক সমন্বয় হয়েছে!`);
  };

  const createPurchase = (purchase: PurchaseRecord) => {
    const updated = DataService.createPurchase(purchase);
    setPurchases(updated);
    showToast(`স্বর্ণ ক্রয়ের ভাউচার #${purchase.voucherNumber} সফলভাবে সম্পন্ন হয়েছে।`);
  };

  const saveCustomer = (customer: Customer) => {
    const updated = DataService.saveCustomer(customer);
    setCustomers(updated);
    showToast(`গ্রাহক "${customer.name}" এর তথ্য আপডেট হয়েছে।`);
  };

  const collectDuePayment = (payment: DuePayment) => {
    const result = DataService.collectDuePayment(payment);
    setCustomers(result.customers);
    setDuePayments(result.duePayments);
    showToast(`৳ ${payment.amount} বকেয়া কিস্তি সফলভাবে আদায় হয়েছে।`);
  };

  // Orders
  const saveOrder = (order: CustomerOrder) => {
    const updated = DataService.saveOrder(order);
    setOrders(updated);
    setOrderToPrint(order);
    showToast(`অর্ডার #${order.orderNumber} সফলভাবে সংরক্ষিত হয়েছে।`);
  };

  const deleteOrder = (id: string) => {
    const updated = DataService.deleteOrder(id);
    setOrders(updated);
    showToast('অর্ডারটি মুছে ফেলা হয়েছে।', 'info');
  };

  // Mortgages
  const saveMortgage = (mortgage: MortgageRecord) => {
    const updated = DataService.saveMortgage(mortgage);
    setMortgages(updated);
    setMortgageToPrint(mortgage);
    showToast(`বন্ধকী এন্ট্রি #${mortgage.mortgageNumber} সফলভাবে সংরক্ষিত হয়েছে।`);
  };

  const deleteMortgage = (id: string) => {
    const updated = DataService.deleteMortgage(id);
    setMortgages(updated);
    showToast('বন্ধকী রেকর্ড মুছে ফেলা হয়েছে।', 'info');
  };

  const transferCalculatorItemToPos = (item: Partial<InvoiceItem>) => {
    setCalculatorTransferItem(item);
    setActiveTab('pos');
    showToast('ক্যালকুলেটরের স্বর্ণের ওজন ও মূল্য বিক্রয় মেমোতে যোগ করা হয়েছে।');
  };

  const clearCalculatorTransferItem = () => {
    setCalculatorTransferItem(null);
  };

  // Auth functions
  const loginDemo = () => {
    const session: UserSession = {
      uid: 'admin-mithun',
      email: 'mithun@alankarhouse.com',
      displayName: 'শ্রী মিঠুন কর্মকার (মালিক)',
      role: 'মালিক / এডমিন',
      isDemo: true,
    };
    setUser(session);
    DataService.setSession(session);
    setIsAuthModalOpen(false);
    showToast('মালিক হিসেবে স্বাগতম!');
  };

  const loginWithEmail = async (email: string, pass: string): Promise<{ success: boolean; error?: string }> => {
    const { auth, configured } = initializeFirebaseServices();
    if (!configured || !auth) {
      return { success: false, error: 'ফায়ারবেস এখনো কনফিগার করা হয়নি।' };
    }
    try {
      const res = await signInWithEmailAndPassword(auth, email, pass);
      const session: UserSession = {
        uid: res.user.uid,
        email: res.user.email || email,
        displayName: res.user.displayName || email.split('@')[0],
        role: 'মালিক / এডমিন',
        isDemo: false,
      };
      setUser(session);
      DataService.setSession(session);
      setIsAuthModalOpen(false);
      showToast('ফায়ারবেসে সফলভাবে লগইন সম্পন্ন হয়েছে!');
      return { success: true };
    } catch (err: any) {
      let msg = 'লগইন ব্যর্থ হয়েছে।';
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
        msg = 'ভুল পাসওয়ার্ড অথবা ইমেইল।';
      } else if (err.code === 'auth/user-not-found') {
        msg = 'এই ইমেইলে কোনো একাউন্ট পাওয়া যায়নি। প্রথমে রেজিস্ট্রেশন করুন।';
      }
      return { success: false, error: msg };
    }
  };

  const registerWithEmail = async (email: string, pass: string, name: string): Promise<{ success: boolean; error?: string }> => {
    const { auth, configured } = initializeFirebaseServices();
    if (!configured || !auth) {
      return { success: false, error: 'ফায়ারবেস এখনো কনফিগার করা হয়নি।' };
    }
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      const session: UserSession = {
        uid: res.user.uid,
        email: res.user.email || email,
        displayName: name || email.split('@')[0],
        role: 'মালিক / এডমিন',
        isDemo: false,
      };
      setUser(session);
      DataService.setSession(session);
      setIsAuthModalOpen(false);
      showToast('নতুন ইউজার রেজিস্ট্রেশন সফল হয়েছে!');
      return { success: true };
    } catch (err: any) {
      let msg = 'রেজিস্ট্রেশন ব্যর্থ হয়েছে: ' + (err.message || 'অজানা ত্রুটি');
      return { success: false, error: msg };
    }
  };

  const logout = () => {
    const { auth } = initializeFirebaseServices();
    if (auth) {
      fbSignOut(auth).catch(() => {});
    }
    setUser(null);
    DataService.setSession(null);
    showToast('লগআউট সফল হয়েছে।', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        user,
        firebaseStatus,
        rates,
        updateRates,
        silverRates,
        updateSilverRates,
        shopProfile,
        updateShopProfile,
        products,
        saveProduct,
        deleteProduct,
        invoices,
        createInvoice,
        purchases,
        createPurchase,
        customers,
        saveCustomer,
        duePayments,
        collectDuePayment,
        orders,
        saveOrder,
        deleteOrder,
        orderToPrint,
        setOrderToPrint,
        isOrderPrintModalOpen,
        setIsOrderPrintModalOpen,
        mortgages,
        saveMortgage,
        deleteMortgage,
        mortgageToPrint,
        setMortgageToPrint,
        isMortgagePrintModalOpen,
        setIsMortgagePrintModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isFirebaseModalOpen,
        setIsFirebaseModalOpen,
        isAndroidModalOpen,
        setIsAndroidModalOpen,
        isPrintModalOpen,
        setIsPrintModalOpen,
        invoiceToPrint,
        setInvoiceToPrint,
        calculatorTransferItem,
        transferCalculatorItemToPos,
        clearCalculatorTransferItem,
        loginDemo,
        loginWithEmail,
        registerWithEmail,
        logout,
        toast,
        showToast,
        refreshData,
        clearAllShopData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
