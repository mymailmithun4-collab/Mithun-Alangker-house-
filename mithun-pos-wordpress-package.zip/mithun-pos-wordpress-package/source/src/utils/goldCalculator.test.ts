/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  partsToPoints,
  pointsToParts,
  partsToGrams,
  gramsToParts,
  toBengaliNumber,
  toEnglishNumber,
  calculateGoldPrice,
  calculatePaymentDue,
  formatWeightPartsBn,
  POINTS_PER_BHORI,
  BHORI_IN_GRAMS,
} from './goldCalculator.ts';

test('1 Bhori equals 960 Points and 16 Ana', () => {
  const points = partsToPoints({ bhori: 1, ana: 0, roti: 0, point: 0 });
  assert.equal(points, POINTS_PER_BHORI);
  assert.equal(points, 960);

  const parts = pointsToParts(960);
  assert.equal(parts.bhori, 1);
  assert.equal(parts.ana, 0);
  assert.equal(parts.roti, 0);
  assert.equal(parts.point, 0);
});

test('1 Ana equals 60 Points (6 Roti * 10 Points)', () => {
  const points = partsToPoints({ bhori: 0, ana: 1, roti: 0, point: 0 });
  assert.equal(points, 60);

  const fromRoti = partsToPoints({ bhori: 0, ana: 0, roti: 6, point: 0 });
  assert.equal(fromRoti, 60);
});

test('1 Bhori equals 11.664 Grams', () => {
  const grams = partsToGrams({ bhori: 1, ana: 0, roti: 0, point: 0 });
  assert.equal(grams, BHORI_IN_GRAMS);

  const parts = gramsToParts(11.664);
  assert.equal(parts.bhori, 1);
  assert.equal(parts.ana, 0);
  assert.equal(parts.roti, 0);
  assert.equal(parts.point, 0);
});

test('Fractional conversion handles arbitrary bhori-ana-roti-point', () => {
  // 1 bhori + 4 ana (240 pt) + 2 roti (20 pt) + 5 point = 960 + 240 + 20 + 5 = 1225 points
  const points = partsToPoints({ bhori: 1, ana: 4, roti: 2, point: 5 });
  assert.equal(points, 1225);

  const parts = pointsToParts(1225);
  assert.equal(parts.bhori, 1);
  assert.equal(parts.ana, 4);
  assert.equal(parts.roti, 2);
  assert.equal(parts.point, 5);

  const formatted = formatWeightPartsBn(parts);
  assert.equal(formatted.includes('১ ভরি'), true);
  assert.equal(formatted.includes('৪ আনা'), true);
});

test('Bengali digits converter converts bidirectional accurately', () => {
  assert.equal(toBengaliNumber('1234567890'), '১২৩৪৫৬৭৮৯০');
  assert.equal(toEnglishNumber('১২৩৪৫৬৭৮৯০'), '1234567890');
});

test('Gold price calculation accurately calculates base, making charge, discount, and VAT', () => {
  const result = calculateGoldPrice({
    weightParts: { bhori: 1, ana: 0, roti: 0, point: 0 },
    ratePerBhori: 120000,
    makingChargeFixed: 5000,
    discount: 2000,
    vatPercent: 5,
  });

  // Base: 120,000 + Making: 5,000 = Subtotal: 125,000
  // Discount: 2,000 -> After Discount: 123,000
  // 5% VAT on 123,000 = 6,150
  // Grand total: 129,150
  assert.equal(result.goldBasePrice, 120000);
  assert.equal(result.totalMakingCharge, 5000);
  assert.equal(result.subtotal, 125000);
  assert.equal(result.discount, 2000);
  assert.equal(result.vatAmount, 6150);
  assert.equal(result.grandTotal, 129150);
});

test('Payment and due calculation is bounded correctly', () => {
  const { paid, due } = calculatePaymentDue(100000, 70000);
  assert.equal(paid, 70000);
  assert.equal(due, 30000);

  const fullPaid = calculatePaymentDue(50000, 60000); // cannot pay more than total into due
  assert.equal(fullPaid.paid, 50000);
  assert.equal(fullPaid.due, 0);
});
