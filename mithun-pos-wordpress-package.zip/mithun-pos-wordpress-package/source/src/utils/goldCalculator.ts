/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Traditional Bangladeshi Gold Weight & Price Calculator
 * 
 * Rules:
 * 1 Bhori (ভরি) = 16 Ana (আনা)
 * 1 Ana = 6 Roti (রতি)
 * 1 Roti = 10 Points (পয়েন্ট)
 * 1 Bhori = 16 * 6 * 10 = 960 Points
 * 1 Bhori = 11.664 Grams
 */

export interface GoldWeightParts {
  bhori: number;
  ana: number;
  roti: number;
  point: number;
}

export type KaratType = '24K' | '22K' | '21K' | '18K' | 'সনাতন';

export const KARAT_INFO: Record<KaratType, { name: string; purity: number; description: string }> = {
  '24K': { name: '২৪ ক্যারেট (পাকা সোনা / গোল্ড বার)', purity: 0.999, description: '১০০% খাঁটি পাকা স্বর্ণ' },
  '22K': { name: '২২ ক্যারেট (ক্যাডমিয়াম / হলমার্ক)', purity: 0.916, description: '৯১.৬% খাঁটি স্বর্ণ (সর্বাধিক প্রচলিত)' },
  '21K': { name: '২১ ক্যারেট (হলমার্ক)', purity: 0.875, description: '৮৭.৫% খাঁটি স্বর্ণ' },
  '18K': { name: '১৮ ক্যারেট (হলমার্ক)', purity: 0.750, description: '৭৫.০% খাঁটি স্বর্ণ' },
  'সনাতন': { name: 'সনাতন পদ্ধতি (পুরাতন সোনা)', purity: 0.650, description: 'সনাতন ঐতিহ্যের স্বর্ণ' },
};

export const BHORI_IN_GRAMS = 11.664;
export const POINTS_PER_BHORI = 960;
export const POINTS_PER_ANA = 60; // 6 * 10
export const POINTS_PER_ROTI = 10;

/**
 * Converts English digits to Bengali numerals
 */
export function toBengaliNumber(num: number | string | undefined | null): string {
  if (num === undefined || num === null) return '০';
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return num.toString().replace(/\d/g, (d) => bnDigits[parseInt(d, 10)]);
}

/**
 * Converts Bengali numerals to English digits
 */
export function toEnglishNumber(str: string): string {
  if (!str) return '0';
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let result = str;
  bnDigits.forEach((bn, idx) => {
    result = result.split(bn).join(idx.toString());
  });
  return result;
}

/**
 * Formats a currency amount into Taka with Bengali format
 */
export function formatTaka(amount: number): string {
  const rounded = Math.round(amount);
  const formattedEn = rounded.toLocaleString('en-IN');
  return `৳ ${toBengaliNumber(formattedEn)}`;
}

/**
 * Converts (Bhori, Ana, Roti, Point) into Total Points
 */
export function partsToPoints(parts?: Partial<GoldWeightParts> | null): number {
  if (!parts) return 0;
  const bhori = Math.max(0, Number(parts.bhori) || 0);
  const ana = Math.max(0, Number(parts.ana) || 0);
  const roti = Math.max(0, Number(parts.roti) || 0);
  const point = Math.max(0, Number(parts.point) || 0);

  const total = (bhori * POINTS_PER_BHORI) + (ana * POINTS_PER_ANA) + (roti * POINTS_PER_ROTI) + point;
  return Math.round(total * 100) / 100;
}

/**
 * Converts Total Points into normalized (Bhori, Ana, Roti, Point)
 */
export function pointsToParts(totalPoints: number): GoldWeightParts {
  const safePoints = Math.max(0, totalPoints);
  const bhori = Math.floor(safePoints / POINTS_PER_BHORI);
  let remainder = safePoints - (bhori * POINTS_PER_BHORI);

  const ana = Math.floor(remainder / POINTS_PER_ANA);
  remainder = remainder - (ana * POINTS_PER_ANA);

  const roti = Math.floor(remainder / POINTS_PER_ROTI);
  remainder = remainder - (roti * POINTS_PER_ROTI);

  const point = Math.round(remainder * 100) / 100;

  return { bhori, ana, roti, point };
}

/**
 * Converts (Bhori, Ana, Roti, Point) to Grams
 */
export function partsToGrams(parts?: Partial<GoldWeightParts> | null): number {
  const totalPoints = partsToPoints(parts);
  const grams = (totalPoints / POINTS_PER_BHORI) * BHORI_IN_GRAMS;
  return Math.round(grams * 1000) / 1000;
}

/**
 * Converts Grams to (Bhori, Ana, Roti, Point)
 */
export function gramsToParts(grams: number): GoldWeightParts {
  const safeGrams = Math.max(0, Number(grams) || 0);
  const totalPoints = (safeGrams / BHORI_IN_GRAMS) * POINTS_PER_BHORI;
  return pointsToParts(Math.round(totalPoints * 100) / 100);
}

/**
 * Formats weight parts into a readable Bengali text
 * e.g. "১ ভরি ৪ আনা ২ রতি ৩ পয়েন্ট"
 */
export function formatWeightPartsBn(parts?: Partial<GoldWeightParts> | null): string {
  const normalized = pointsToParts(partsToPoints(parts));
  const segments: string[] = [];

  if (normalized.bhori > 0) segments.push(`${toBengaliNumber(normalized.bhori)} ভরি`);
  if (normalized.ana > 0) segments.push(`${toBengaliNumber(normalized.ana)} আনা`);
  if (normalized.roti > 0) segments.push(`${toBengaliNumber(normalized.roti)} রতি`);
  if (normalized.point > 0 || segments.length === 0) segments.push(`${toBengaliNumber(normalized.point)} পয়েন্ট`);

  return segments.join(' ');
}

/**
 * Computes exact gold price
 */
export interface GoldPriceCalculationParams {
  weightParts: GoldWeightParts;
  ratePerBhori: number;
  makingChargePerBhori?: number;
  makingChargeFixed?: number;
  stonePrice?: number;
  discount?: number;
  vatPercent?: number; // e.g. 5%
}

export interface GoldPriceCalculationResult {
  totalPoints: number;
  totalBhori: number;
  totalGrams: number;
  goldBasePrice: number;
  pureGoldPrice?: number;
  totalMakingCharge: number;
  stonePrice: number;
  subtotal: number;
  discount: number;
  vatAmount: number;
  grandTotal: number;
  totalPrice?: number;
}

export function calculateGoldPrice(params: GoldPriceCalculationParams): GoldPriceCalculationResult {
  const safeParts = params?.weightParts || { bhori: 0, ana: 0, roti: 0, point: 0 };
  const totalPoints = partsToPoints(safeParts);
  const totalBhori = totalPoints / POINTS_PER_BHORI;
  const totalGrams = (totalPoints / POINTS_PER_BHORI) * BHORI_IN_GRAMS;

  const rate = Math.max(0, Number(params?.ratePerBhori) || 0);
  const goldBasePrice = Math.round(totalBhori * rate);

  const makingChargePerBhori = Math.max(0, Number(params?.makingChargePerBhori) || 0);
  const makingChargeFixed = Math.max(0, Number(params?.makingChargeFixed) || 0);
  const totalMakingCharge = Math.round((totalBhori * makingChargePerBhori) + makingChargeFixed);

  const stonePrice = Math.max(0, Number(params?.stonePrice) || 0);
  const subtotal = goldBasePrice + totalMakingCharge + stonePrice;

  const discount = Math.min(subtotal, Math.max(0, Number(params?.discount) || 0));
  const afterDiscount = subtotal - discount;

  const vatPercent = Math.max(0, Number(params?.vatPercent) || 0);
  const vatAmount = Math.round((afterDiscount * vatPercent) / 100);

  const grandTotal = afterDiscount + vatAmount;

  return {
    totalPoints: Math.round(totalPoints * 100) / 100,
    totalBhori: Math.round(totalBhori * 10000) / 10000,
    totalGrams: Math.round(totalGrams * 1000) / 1000,
    goldBasePrice,
    pureGoldPrice: goldBasePrice,
    totalMakingCharge,
    stonePrice,
    subtotal,
    discount,
    vatAmount,
    grandTotal,
    totalPrice: grandTotal,
  };
}

/**
 * Calculates stock balance and dues atomically
 */
export function calculatePaymentDue(grandTotal: number, paidAmount: number): { paid: number; due: number } {
  const total = Math.max(0, grandTotal);
  const paid = Math.min(total, Math.max(0, paidAmount));
  const due = Math.max(0, total - paid);
  return { paid, due };
}
