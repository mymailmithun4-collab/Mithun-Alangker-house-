# মেসার্স মিঠুন অলংকার হাউজ POS — WordPress সেটআপ (বাংলা)

## গুরুত্বপূর্ণ
এটি React + TypeScript + Vite অ্যাপ; `index.html` একা সম্পূর্ণ অ্যাপ নয়। POS চালাতে পুরো প্রজেক্ট build করতে হবে। এই প্যাকেজে মূল সোর্স কোড ও WordPress embed plugin আছে। এই পরিবেশে npm dependency ডাউনলোডের সময়সীমা শেষ হওয়ায় তৈরি করা `dist` build অন্তর্ভুক্ত করা যায়নি।

## A. অ্যাপ build করুন
1. ZIP-এর `source/` ফোল্ডারের ফাইলগুলো কম্পিউটারে রাখুন।
2. Node.js LTS ইনস্টল করুন।
3. Terminal/Command Prompt-এ source ফোল্ডারে গিয়ে চালান:
   ```bash
   npm install
   npm run build
   ```
4. সফল হলে `dist/` ফোল্ডার তৈরি হবে।

## B. WordPress হোস্টিংয়ে অ্যাপ আপলোড করুন
1. Hosting File Manager → ওয়েবসাইটের document root (সাধারণত `public_html`) খুলুন।
2. `pos-app` নামে ফোল্ডার তৈরি করুন।
3. `dist/` ফোল্ডারের **ভেতরের সব ফাইল/ফোল্ডার** `public_html/pos-app/`-এ আপলোড করুন। `index.html` যেন `public_html/pos-app/index.html` হয়।
4. `https://আপনার-ডোমেইন/pos-app/` খুলে অ্যাপ লোড হয় কি না পরীক্ষা করুন।

## C. WordPress-এ দেখান
1. `wordpress-integration/mithun-pos-embed.php` ফাইলটি ZIP করুন যেন ZIP-এর root-এ `mithun-pos-embed.php` থাকে, অথবা সরাসরি `wp-content/plugins/mithun-pos-embed/` ফোল্ডারে রাখুন।
2. WordPress Admin → Plugins-এ গিয়ে **Mithun Jewelry POS Embed** Activate করুন।
3. Settings → Mithun POS Embed-এ POS URL দিন, যেমন `https://আপনার-ডোমেইন/pos-app/`।
4. একটি WordPress Page তৈরি করে এই shortcode দিন:
   ```text
   [mithun_pos]
   ```
5. পেজটি Publish করুন।

## D. Firebase সেটআপ অবশ্যই করুন
1. Firebase Console-এ নিজের project তৈরি করুন।
2. Authentication → Sign-in method-এ Email/Password চালু করুন।
3. Firestore Database তৈরি করুন।
4. মূল source-এর `firestore.rules` ফাইল দেখে নিরাপদ rules publish করুন। Production-এর আগে rules নিজে যাচাই করুন।
5. POS চালু করে Firebase সেটিংস স্ক্রিনে আপনার **নিজের Firebase Web App config** দিন। ZIP-এ থাকা config placeholder/উদাহরণ মান; সেটি আপনার আসল project config নয়।
6. Firebase Authentication-এ admin user তৈরি করুন এবং শুধু অনুমোদিত ব্যবহারকারীদের অ্যাক্সেস দিন।

Firebase Web config browser-এ দেখা যায়—এটি স্বাভাবিক; নিরাপত্তা Firestore Rules ও Authentication-এর মাধ্যমে নিশ্চিত করতে হবে। Gemini/API secret বা service-account private key কখনো frontend-এ রাখবেন না।

## সীমাবদ্ধতা ও যাচাই
- WordPress shortcode অ্যাপটিকে iframe-এ দেখায়; এটি React-কে WordPress PHP-তে রূপান্তর করে না।
- Firebase config না দিলে cloud login/database কাজ করবে না।
- Build-এর পর মোবাইল/ডেস্কটপে login, customer/product CRUD, invoice print, purchase, mortgage, reports, backup/restore এবং Firebase permissions পরীক্ষা করুন।
- শুধু HTTPS ব্যবহার করুন।
